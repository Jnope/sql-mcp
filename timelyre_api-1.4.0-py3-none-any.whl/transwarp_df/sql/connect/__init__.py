#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""Spark Connect client"""
import os
import time
import atexit

SETUP_HIGH_TIME_FUNC_DEBUG = os.environ.get('SETUP_HIGH_TIME_FUNC_DEBUG', 'false') == 'true'
HIGH_TIME_FUNC_T = float(os.environ.get('HIGH_TIME_FUNC_T', '0.001'))
CONFIG_OPT_ENABLED = os.environ.get('CONFIG_OPT_ENABLED', 'true') == 'true'
CONFIG_USE_LOCAL = os.environ.get('CONFIG_USE_LOCAL', 'true') == 'true'

global_time_dict = {}
global_count_dict = {}


def report():
    print('rpc perf')
    for k, v in global_count_dict.items():
        print(f'fname: {k}, count: {v}, time: {global_time_dict.get(k)}')


if SETUP_HIGH_TIME_FUNC_DEBUG:
    atexit.register(report)


def time_func(fname):
    """
    func decorator, 用来标记一个可能开销比较高的函数(如RPC)
    :param fname: 函数描述
    :return:
    """

    def xx(func):
        def wrapper(*args, **kwargs):
            t1 = time.time()
            try:
                return func(*args, **kwargs)
            except Exception as e:
                raise e
            finally:
                t2 = time.time()
                global_time_dict[fname] = global_time_dict.get(fname, 0) + (t2 - t1)
                global_count_dict[fname] = global_count_dict.get(fname, 0) + 1
                if t2 - t1 >= HIGH_TIME_FUNC_T:
                    print(f'high tf {fname}', t2 - t1)

        if SETUP_HIGH_TIME_FUNC_DEBUG:
            return wrapper
        else:
            return func

    return xx

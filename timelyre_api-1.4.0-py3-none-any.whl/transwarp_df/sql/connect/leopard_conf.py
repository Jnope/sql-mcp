import os

LEOPARD_COMPILE_LOCAL_OPTIMIZATION = ("leopard_compile_local_optimization", "True")
LEOPARD_COMPILE_LOCAL_SCHEMA_OPTIMIZATION = ('leopard_compile_local_schema_optimization', "True")
LEOPARD_COMPILE_SCHEMA_CHECK = ("leopard_compile_schema_check", "False")
LEOPARD_IS_UT_RUNTIME = ("leopard_is_ut_runtime", "False")
LEOPARD_PROGRESS_TRACER_ENABLED = ("leopard_progress_tracer_enabled", "True")
LEOPARD_PROGRESS_TRACER_PERIOD = ("leopard_progress_tracer_period", "0.3")
LEOPARD_DISABLE_WARNING = ("leopard_disable_warning", "True")
LEOPARD_USE_TQDM_AUTO = ("leopard_use_tqdm_auto", "True")

if os.environ.get('leopard_is_ut_runtime', 'False') == 'True':
    print("Show leopard environment variables:")
    for k, v in os.environ.items():
        if k.startswith("leopard_"):
            print(k, v)


def session_get(session, conf_item: tuple) -> str:
    if conf_item[0] in os.environ or session is None:
        return os.environ.get(conf_item[0], conf_item[1])
    return session.local_conf.get(conf_item[0], conf_item[1])


def get_conf(conf_item: tuple) -> str:
    return os.environ.get(conf_item[0], conf_item[1])


def get_bool_conf(conf_item: tuple) -> bool:
    return bool(get_conf(conf_item))


def get_float_conf(conf_item: tuple) -> float:
    return float(get_conf(conf_item))

import warnings

from transwarp_df.sql.connect.analysis_helper import missing_expr
from transwarp_df.sql.connect.expressions import UnresolvedFunction, Expression, CaseWhen, LiteralExpression, \
    DistributedSequenceID, ColumnAlias, ColumnReference, CastExpression, WindowExpression
from transwarp_df.sql.types import StructField, BooleanType, StructType, LongType, DataType, ByteType, ShortType, \
    IntegerType, FloatType, DoubleType, DateType, NullType, TimestampType, DayTimeIntervalType

# NumericTypes
numericPrecedence = [ByteType, ShortType, IntegerType, LongType, FloatType, DoubleType]
integral_types = {ByteType, ShortType, IntegerType, LongType}


def __is_integral_type(dt: DataType) -> bool:
    """
    判断一个类型是否为整数类型
    :param dt:
    :return:
    """
    return dt.__class__ in integral_types


def __index_list(o, l):
    for idx in range(len(l)):
        if l[idx] is o:
            return idx
    return -1


def _numeric_type_common_type(a: DataType, b: DataType) -> DataType:
    """
    找到两个数字类型的公共类型，逻辑与server端要保持一致
    :param a:
    :param b:
    :return:
    """
    ii = __index_list(a.__class__, numericPrecedence)
    jj = __index_list(b.__class__, numericPrecedence)
    if ii == -1 or jj == -1:
        return None
    else:
        if jj > ii:
            return b
        else:
            return a


def _norm_name(n: str):
    if n.startswith('`') and n.endswith('`'):
        return n[1:-1]
    else:
        return n


def _resolve_func(uf: UnresolvedFunction, child_schema) -> StructField:
    """
    解析函数的类型
    :param uf:
    :param child_schema:
    :return:
    """
    if uf._name in ('>', '<', 'and', 'or', '==', '!=', '<>', '>=', '<='):
        return StructField(name=str(uf), dataType=BooleanType(), nullable=True)
    elif uf._name == 'monotonically_increasing_id':
        return StructField(name=str(uf), dataType=LongType(), nullable=False)
    elif uf._name in ('+', '-', '*'):
        left = uf._args[0]
        right = uf._args[1]
        l = resolve_expr_type(left, child_schema)
        r = resolve_expr_type(right, child_schema)
        # TODO: 当前只处理类型相等的情况，因此复用_merge_types
        xx = _merge_types([l, r])
        if isinstance(xx.dataType, TimestampType) and uf._name == '-':
            xx.dataType = DayTimeIntervalType(0, 3)
        return xx
    elif uf._name == '/':
        left = uf._args[0]
        right = uf._args[1]
        l = resolve_expr_type(left, child_schema)
        r = resolve_expr_type(right, child_schema)
        # TODO: 这里只简单处理了double/double的情况，server端的处理比较复杂，主要是有TypeCoersion还有一些cast rule
        if isinstance(l.dataType, DoubleType) and l.dataType == r.dataType:
            return StructField(name=str(uf), dataType=DoubleType(), nullable=True)
        elif isinstance(l.dataType, IntegerType) and l.dataType == r.dataType:
            return StructField(name=str(uf), dataType=IntegerType(), nullable=True)
        return missing_expr(uf)
    elif uf._name == 'count':
        return StructField(name=str(uf), dataType=LongType(), nullable=False)
    elif uf._name in ('stddev', 'percentile', 'percentile_approx'):
        # 固定返回Double类型
        return StructField(name=str(uf), dataType=DoubleType(), nullable=True)
    elif uf._name == 'sum':
        arg_tp = resolve_expr_type(uf._args[0], child_schema)
        if arg_tp is None:
            return None
        if __is_integral_type(arg_tp.dataType):
            return StructField(name=str(uf), dataType=LongType(), nullable=True)
        elif isinstance(arg_tp.dataType, DoubleType):
            return StructField(name=str(uf), dataType=DoubleType(), nullable=True)
        else:
            return missing_expr(uf)
    elif uf._name == 'to_date':
        return StructField(name=str(uf), dataType=DateType(), nullable=True)
    elif uf._name == 'nanvl':
        # XXX: 根据nanvl本身的output/input type逻辑，以及FunctionArgumentConversion的隐式参数转换的逻辑
        left_tp = resolve_expr_type(uf._args[0], child_schema)
        right_tp = resolve_expr_type(uf._args[1], child_schema)
        if left_tp is None or right_tp is None:
            return None
        if isinstance(right_tp.dataType, NullType):
            return StructField(name=str(uf), dataType=left_tp.dataType, nullable=left_tp.nullable)
        else:
            return StructField(name=str(uf), dataType=DoubleType(), nullable=left_tp.nullable | right_tp.nullable)
    elif uf._name in ('lag', 'lead', 'min', 'max', 'first', 'last'):
        # lag是选择当前行的前n行,lead是选择当前行的后n行
        left_tp = resolve_expr_type(uf._args[0], child_schema)
        return StructField(name=str(uf), dataType=left_tp.dataType, nullable=left_tp.nullable)
    else:
        #warnings.warn(f"{uf._name} is not implemented by _resolve_func")
        return missing_expr(uf)


def _merge_types(fields: list) -> StructField:
    if len(fields) == 0:
        raise RuntimeError("should not happen")
    dt = fields[0].dataType
    nullable = fields[0].nullable
    for x in fields[1:]:
        if x.dataType == dt and x.nullable == nullable:
            pass
        elif x.dataType == dt:
            nullable = True
        else:
            c = _numeric_type_common_type(x.dataType, dt)
            if c is None:
                return None
            dt = c
            nullable = nullable | x.nullable
    return StructField(name="*N/A*", dataType=dt, nullable=nullable)


def resolve_expr_type(e: Expression, child_schema: StructType) -> StructField:
    """
    解析表达式的类型
    :param e:
    :param child_schema:
    :return:
    """
    if isinstance(e, DistributedSequenceID):
        return StructField(name=str(e), dataType=LongType(), nullable=False)
    elif isinstance(e, ColumnAlias):
        f = resolve_expr_type(e._parent, child_schema)
        if f is None:
            return None
        return StructField(name=_norm_name(e._alias[0]), dataType=f.dataType, nullable=f.nullable)
    elif isinstance(e, ColumnReference):
        n = _norm_name(e.name())
        if n in child_schema.names:
            return child_schema[n]
        else:
            return missing_expr(e)
    elif isinstance(e, UnresolvedFunction):
        f = _resolve_func(e, child_schema)
        return f
    if isinstance(e, CaseWhen):
        xx = [resolve_expr_type(value, child_schema) for cond, value in e._branches]
        yy = [resolve_expr_type(e._else_value, child_schema)]
        c = xx + yy
        if None in c:
            return missing_expr(e)
        mt = _merge_types(c)
        if mt is None:
            return missing_expr(e)
        return StructField(name=str(e), dataType=mt.dataType, nullable=mt.nullable)
    elif isinstance(e, LiteralExpression):
        return StructField(name=str(e), dataType=e._dataType, nullable=False)
    elif isinstance(e, CastExpression):
        return StructField(name=str(e), dataType=e._data_type, nullable=True)
    elif isinstance(e, WindowExpression):
        window_func = e._windowFunction
        return resolve_expr_type(window_func, child_schema)
    else:
        return missing_expr(e)

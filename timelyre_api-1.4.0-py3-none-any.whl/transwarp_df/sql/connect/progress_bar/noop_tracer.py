class NoopTracer:
    def __enter__(self):
        # 无操作
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # 无操作
        pass

    def set_error(self, error_happen):
        pass

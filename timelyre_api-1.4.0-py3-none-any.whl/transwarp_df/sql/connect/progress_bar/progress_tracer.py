import threading
import time
import warnings

from transwarp_df.sql.connect.progress_bar.stage_progress import StageProgress

global_error = None


class ProgressTracer:
    def __init__(self, connector_client, req, period=0.3):
        self.stop_event = threading.Event()
        self.background_thread = threading.Thread(target=self.run)
        self.connector_client = connector_client
        self.period = period
        self.req = req
        self.stage_progress_map = {}
        self.error_happen = False

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # 先结束后台线程
        self.stop()
        if not self.error_happen:
            try:
                self.doCheck()  # 再检查一下是否有新的job或者stage
                for _, existing_stage in list(self.stage_progress_map.items()):
                    existing_stage.finish()
            except Exception:
                pass

    def set_error(self, error_happen):
        self.error_happen = error_happen

    def doCheck(self):
        progress_str = self.connector_client.get_progress(self.req)
        stage_strings = progress_str.replace("'", "").split(";")
        for s in stage_strings:
            if len(s) > 0:
                # 接受到了新的状态
                job_id, stage_id, finished_tasks, total_tasks = StageProgress.from_string(s)
                existing_progress = self.stage_progress_map.get(stage_id)
                if existing_progress:
                    existing_progress.update_num(finished_tasks - existing_progress.finished_tasks)
                else:
                    stage_progress = StageProgress(job_id, stage_id, finished_tasks, total_tasks)
                    self.stage_progress_map[stage_id] = stage_progress

    def run(self):
        while not self.stop_event.is_set():
            try:
                self.doCheck()
                time.sleep(self.period)
            except Exception:
                warnings.warn(f"tracer got exception, maybe the leopard version is not supported for tracer")
                self.stop_event.set()

    def start(self):
        self.background_thread.start()

    def stop(self):
        self.stop_event.set()
        self.background_thread.join()

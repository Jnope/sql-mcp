import time
import warnings

import transwarp_df.sql.connect.plan as plan
from transwarp.timelyre.timelyre_logger import getLogger
from transwarp_df.sql.connect import time_func
from transwarp_df.sql.connect.analysis_helper import missing_plan
from transwarp_df.sql.connect.column import Column
from transwarp_df.sql.connect.expression_helper import resolve_expr_type, _merge_types
from transwarp_df.sql.connect.expressions import Expression, ColumnAlias, ColumnReference, DistributedSequenceID, \
    UnresolvedFunction

from transwarp_df.sql.connect.leopard_conf import LEOPARD_COMPILE_LOCAL_OPTIMIZATION, session_get
from transwarp_df.sql.types import StructType, StructField, LongType, UnknownType, DataType, IntegerType, TimestampType, \
    StringType, DoubleType, BooleanType


def norm_name(n: str):
    """
    本地分析的时候可能有一些名字是quoted，因此要标准化成无quoted的名字
    :param n:
    :return:
    """
    if n.startswith('`') and n.endswith('`'):
        return n[1:-1]
    else:
        return n
def norm_col_names(names: list) -> list:
    if names is None:
        return None
    ret = []
    for x in names:
        ret.append(norm_name(x))
    return ret

def __resolve_columns_or_names(columns: list, p: plan.LogicalPlan, session):
    ret = []
    for x in columns:
        if isinstance(x, Column):
            n = get_expression_name(x._expr)
            if n is None:
                return missing_plan(p)
            else:
                ret.append(n)
        elif isinstance(x, str):
            if x == "*":
                names = __get_plan_columns(p._child, session)
                if names is None:
                    return None
                ret.extend(names)
            elif x.startswith("__"):
                ret.append(x)
            else:
                return missing_plan(p)
        else:
            return missing_plan(p)
    return ret

def __resolve_columns_expressions(columns: list, p: plan.LogicalPlan, session, child_schema):
    """
    解析一些columns里的列选择，如果包含任何非直接的列选择，比如 (a + 1) as b这种，当前都处理不了，返回None
    :param columns:
    :param p:
    :param session:
    :return:
    """
    ret = []
    for x in columns:
        if isinstance(x, Column):
            e = x._expr
            sf = resolve_expr_type(e, child_schema)
            if sf is None:
                return None
            ret.append(sf)
        elif isinstance(x, str):
            st = __get_plan_schema(p._child, session)
            if st is None:
                return None
            if x == "*":
                for n in st.fields[:]:
                    ret.append(n)
            elif x.startswith("__"):
                if x not in st.names:
                    raise RuntimeError(f"{x} not in child schema.")
                ret.append(st[x])
            else:
                return missing_plan(p)
        else:
            return missing_plan(p)
    return ret

def __get_plan_columns(p: plan.LogicalPlan, session) -> list:
    if p._plan_columns is not None:
        return p._plan_columns[:]

    if isinstance(p, plan.WithColumns):
        clist = __get_plan_columns(p._child, session)
        if clist is None:
            return None
        else:
            clist.extend(p._columnNames)
            return clist
    elif isinstance(p, plan.Project):
        ret = __resolve_columns_or_names(p._columns, p, session)
        return ret
    elif isinstance(p, plan.Limit) or isinstance(p, plan.NADrop) or isinstance(p, plan.Sort) or isinstance(p, plan.Filter):
        return __get_plan_columns(p._child, session)
    elif isinstance(p, plan.Aggregate):
        gcols = __resolve_columns_or_names(p._grouping_cols, p, session)
        acols = __resolve_columns_or_names(p._aggregate_cols, p, session)
        if acols is None or gcols is None:
            return None
        names = []
        names.extend(gcols)
        names.extend(acols)
        return names
    elif isinstance(p, plan.SetOperation):
        if not p.by_name and p.set_op == 'union':
            return __get_plan_columns(p._child, session)
        return missing_plan(p)
    elif isinstance(p, plan.Read):
        import json
        xx = json.loads(p.options['tableSchema'])
        names = [f['name'] for f in xx['fields']]
        return names
    elif isinstance(p, plan.Drop):
        names = __resolve_columns_or_names(p._columns, p, session)
        child_names = __get_plan_columns(p._child, session)
        if child_names is None:
            return None
        ret = []
        for x in child_names:
            if x not in names:
                ret.append(x)
        return ret
    else:
        return None

@time_func(fname='get_plan_columns')
def get_or_update_plan_columns(p: plan.LogicalPlan, session) -> list:
    use_local_opt = session_get(session, LEOPARD_COMPILE_LOCAL_OPTIMIZATION) == "True"
    if not use_local_opt:
        # 优化没有enable
        return None

    names = __get_plan_columns(p, session)
    if names is not None:
        ret = norm_col_names(names)
        if p._plan_columns is None:
            p._plan_columns = names
        return ret
    else:
        return None

def get_or_update_plan_schema(p: plan.LogicalPlan, session) -> StructType:
    """
    分析当前执行计划的输出schema，如果成功分析，则结果缓存在执行计划对象上。
    :param p: 要分析输出schema的执行计划
    :param session: 当前session环境
    :return: 执行计划的schema，如果分析不出来，则返回None
    """
    use_local_opt = session_get(session, LEOPARD_COMPILE_LOCAL_OPTIMIZATION) == "True"
    if not use_local_opt:
        # 优化没有enable
        return None

    schema = __get_plan_schema(p, session)
    if p._plan_schema is None:
        p._plan_schema = schema
        return schema
    else:
        return None

def get_expression_name(e: 'Expression') -> str:
    if isinstance(e, ColumnAlias):
        x = e._alias
        if len(x) == 1:
            return x[0]
        else:
            #TODO: 如何处理?
            return None
    elif isinstance(e, ColumnReference):
        return e.name()
    else:
        return None

def _tp_str_to_data_type(tp_str: str) -> DataType:
    if tp_str == 'integer':
        return IntegerType()
    elif tp_str == "long":
        return LongType()
    elif tp_str == "timestamp":
        return TimestampType()
    elif tp_str == "string":
        return StringType()
    elif tp_str == "double":
        return DoubleType()
    elif tp_str == "boolean":
        return BooleanType()
    else:
        raise NotImplementedError(f"cannot recognize {tp_str}")

def __get_plan_schema(p: plan.LogicalPlan, session) -> StructType:
    try:
        if p._plan_schema is not None:
            return p._plan_schema
        if isinstance(p, plan.WithColumns):
            child_schema = __get_plan_schema(p._child, session)
            if child_schema is None:
                return None
            else:
                new_st = StructType(child_schema.fields[:])
                for idx, x in enumerate(p._columnNames):
                    c = p._columns[idx]
                    cols = __resolve_columns_expressions([c], p, session, child_schema)
                    if cols is None:
                        return None
                    sf = cols[0]
                    new_st.add(StructField(name=norm_name(x), dataType=sf.dataType, nullable=sf.nullable))
                return new_st
        elif isinstance(p, plan.Project):
            child_schema = __get_plan_schema(p._child, session)
            if child_schema is None:
                return None
            ret = __resolve_columns_expressions(p._columns, p, session, child_schema)
            if ret is None:
                return None
            return StructType(ret)
        elif isinstance(p, plan.Limit) or isinstance(p, plan.NADrop) or isinstance(p, plan.Sort) or isinstance(p, plan.Filter) or isinstance(p, plan.Tail):
            return __get_plan_schema(p._child, session)
        elif isinstance(p, plan.Aggregate):
            child_schema = __get_plan_schema(p._child, session)
            if child_schema is None:
                return None
            gcols = __resolve_columns_expressions(p._grouping_cols, p, session, child_schema)
            if gcols is None:
                return None
            acols = __resolve_columns_expressions(p._aggregate_cols, p, session, child_schema)
            if acols is None:
                return None
            return StructType(gcols + acols)
        elif isinstance(p, plan.SetOperation):
            if not p.by_name and p.set_op == 'union':
                c = __get_plan_schema(p._child, session)
                o = __get_plan_schema(p.other, session)
                if c is None or o is None:
                    return None
                assert len(c) == len(o)
                fields = []
                for idx, _ in enumerate(c.fields):
                    tp1 = c.fields[idx]
                    tp2 = o.fields[idx]
                    tp3 = _merge_types([tp1, tp2])
                    if p._plan_columns is None:
                        name = tp1.name
                    else:
                        name = p._plan_columns[idx]
                    if tp3 is None:
                        return None
                    fields.append(StructField(name=norm_name(name), dataType=tp3.dataType, nullable=tp3.nullable))
                return StructType(fields)
            return None
        elif isinstance(p, plan.Read):
            import json
            xx = json.loads(p.options['tableSchema'])
            fields = []
            for f in xx['fields']:
                name = f['name']
                nullable = f['nullable']
                tp = f['type']
                fields.append(StructField(norm_name(name), dataType=_tp_str_to_data_type(tp), nullable=nullable))

            child_schema = StructType(fields)
            return child_schema
        elif isinstance(p, plan.Drop):
            child_schema = __get_plan_schema(p._child, session)
            if child_schema is None:
                return None
            fields = []
            for x in child_schema.names:
                if x in p._columns:
                    #drop col
                    pass
                else:
                    fields.append(child_schema[x])
            return StructType(fields)
        elif isinstance(p, plan.Join):
            cs1 = __get_plan_schema(p.left, session)
            cs2 = __get_plan_schema(p.right, session)
            if cs1 is None or cs2 is None:
                return None
            return StructType(cs1.fields[:] + cs2.fields[:])
        elif isinstance(p, plan.SubqueryAlias):
            child_schema = __get_plan_schema(p._child, session)
            return child_schema
        else:
            return None
    except Exception as e:
        getLogger().warn(f"__get_plan_schema got exception: {e}")
        return None

#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""
Important classes of Spark SQL and DataFrames:

    - :class:`pyspark.sql.SparkSession`
      Main entry point for :class:`DataFrame` and SQL functionality.
    - :class:`pyspark.sql.DataFrame`
      A distributed collection of data grouped into named columns.
    - :class:`pyspark.sql.Column`
      A column expression in a :class:`DataFrame`.
    - :class:`pyspark.sql.Row`
      A row of data in a :class:`DataFrame`.
    - :class:`pyspark.sql.GroupedData`
      Aggregation methods, returned by :func:`DataFrame.groupBy`.
    - :class:`pyspark.sql.DataFrameNaFunctions`
      Methods for handling missing data (null values).
    - :class:`pyspark.sql.DataFrameStatFunctions`
      Methods for statistics functionality.
    - :class:`pyspark.sql.functions`
      List of built-in functions available for :class:`DataFrame`.
    - :class:`pyspark.sql.types`
      List of data types available.
    - :class:`pyspark.sql.Window`
      For working with window functions.
"""
from transwarp_df.sql.types import Row
from transwarp_df.sql.context import SQLContext, HiveContext, UDFRegistration, UDTFRegistration
from transwarp_df.sql.session import SparkSession
from transwarp_df.sql.column import Column
from transwarp_df.sql.catalog import Catalog
from transwarp_df.sql.dataframe import DataFrame, DataFrameNaFunctions, DataFrameStatFunctions
from transwarp_df.sql.group import GroupedData
from transwarp_df.sql.observation import Observation
from transwarp_df.sql.readwriter import DataFrameReader, DataFrameWriter, DataFrameWriterV2
from transwarp_df.sql.window import Window, WindowSpec
from transwarp_df.sql.pandas.group_ops import PandasCogroupedOps


__all__ = [
    "SparkSession",
    "SQLContext",
    "HiveContext",
    "UDFRegistration",
    "UDTFRegistration",
    "DataFrame",
    "GroupedData",
    "Column",
    "Catalog",
    "Observation",
    "Row",
    "DataFrameNaFunctions",
    "DataFrameStatFunctions",
    "Window",
    "WindowSpec",
    "DataFrameReader",
    "DataFrameWriter",
    "DataFrameWriterV2",
    "PandasCogroupedOps",
]

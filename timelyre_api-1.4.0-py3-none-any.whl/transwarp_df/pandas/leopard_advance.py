# from pyspark.pandas import DataFrame
import builtins
import sys
import types

import transwarp_df
import transwarp_df.sql.connect.dataframe
import transwarp_df.pandas.internal
import transwarp_df.pandas.indexes

__all__ = [
    "disable_data_debug",
]

ignore_modules = {
    "pyspark.pandas.typedef",
    "pyspark.pandas.exceptions",
    "pyspark.sql.types",
    "pyspark.sql.connect.expressions",
    "pyspark.sql.pandas.serializers",
}

def fake__len__() -> int:
    return 0

class ReprRecover:
    """
    尝试替换掉__repr，提升开发debug时某些类型的varabile(如Series,DataFrame)不需要去远端取数据
    TODO(LTY): 但好像没搞定，不仅仅是__repr__，或者pycharm有一套特殊的机制，需要继续研究
    """
    def __init__(self):
        self.to_replace_classes = {}

    def _replace_repr_class(self, mod: types.ModuleType):
        if mod.__name__ in ignore_modules:
            return

        submodules = dict([(name, m) for name, m in mod.__dict__.items() if isinstance(m, types.ModuleType) and m.__name__.startswith(mod.__name__)])
        for n, m in submodules.items():
            self._replace_repr_class(m)

        x = dict([(name, cls) for name, cls in mod.__dict__.items() if isinstance(cls, type) and cls.__module__ == mod.__name__])
        for name, cls in x.items():
            if cls.__module__.startswith('pyspark') and cls.__repr__ is not object.__repr__:
                self.to_replace_classes[name] = cls

    def add_module(self, mod: types.ModuleType):
        self._replace_repr_class(mod)

    def do_recover(self):
        for k, v in self.to_replace_classes.items():
            v.__repr__ = object.__repr__
            # if hasattr(v, '__len__'):
            #     print(k, v)
            #     v.__len__ = fake__len__

def disable_data_debug():

    modules = [
        transwarp_df.pandas,
        transwarp_df.pandas.frame,
        transwarp_df.sql.connect.dataframe,
        transwarp_df.sql,
        transwarp_df.pandas.series,
        transwarp_df.pandas.internal,
        transwarp_df.pandas.indexes,
        transwarp_df.pandas.indexes.base,
    ]

    rr = ReprRecover()

    for m in modules:
        rr.add_module(m)

    rr.do_recover()
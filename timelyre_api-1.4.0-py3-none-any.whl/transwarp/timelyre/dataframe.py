import base64
import copy
import inspect
import json
import math
import os
import random
import sys
import time
import re
import uuid
import zlib
from datetime import timedelta
import datetime
from json import JSONDecodeError
import pandas as pd
from typing import Union, TypeVar, Callable
import cloudpickle
from enum import Enum
import itertools

from concurrent.futures import ThreadPoolExecutor
from itertools import repeat

from .timelyre_logger import getLogger
from .constants import *
from .timelyre_public import DatabaseConn
from .connection import Connection

class ColEval: pass
class RollingColEval: pass
class RollingAggColEval: pass
class DataFrame: pass
class GroupbyDataFrame: pass
class RollingDataFrame: pass
class MapDataFrame: pass

expand_cols = True


# 1. 用于判断是否能够切片
# 2. 用于判断是两表间的操作（两个字典都不包含）
udf_methods = {'ema': 1, 'shift': 3, 'sum_x': 1, 'cout_x': 1, 'mean_x': 1, 'min_x': 2, 'max_x': 2,
               'mad_x': 1, 'nunique_x': 2, 'any_x': 2, 'all_x': 2, 'abs': 0, 'ceil': 0, 'floor': 0, 'round': 1,
               'rank': 6, 'rank_x': 6, 'square': 0, 'cube': 0, 'root': 0, 'value_counts': 3,
               'exp': 0, 'ln': 0, 'sin': 0, 'cos': 0, 'tan': 0, 'asin': 0, 'acos': 0, 'atan': 0,
               'cumsum': 2, 'cumsum_x': 2, 'cumprod': 2, 'cumprod_x': 2, 'cummin': 2, 'cummin_x': 2,
               'cummax': 2, 'cummax_x': 2, 'interpolate': 0, 'sign': 0, 'negative': 0, 'pow': 1, 'log': 1, 'diff': 1,
               'srank': 7}

udaf_methods = {'sum': 1, 'count': 1, 'mean': 1, 'min': 2, 'max': 2, 'std': 2, 'first': 0, 'last': 0,
                'var': 2, 'value_counts': 4, 'kurt': 1, 'skew': 1, 'mad': 1, 'nunique': 2, 'any': 2, 'all': 2,
                'argmax': 0, 'corr': 2, 'cov': 1, 'prod': 2,'applyGroupByAggregation': 1,'applyRollingAggregation':1,'applyAggregation':1,
                'average': 2}

def result_data_to_list(obj):
    ret = []
    if not "rows" in obj["results"][0]:
        return ret, [], []

    schema = obj["results"][0]["schema"]["types"]
    names = obj["results"][0]["schema"]["names"]

    for x in obj["results"][0]["rows"]:
        elem = x["data"]
        # ret += elem
        ret.append(elem)
    return ret, schema, names

def format_result(obj):
    ret = []
    schema = []
    type = []
    names = []
    for index in range(len(obj)):
        row = obj[index]
        if index == 0:
            schema_info = row.split(",")
            for col_index in range(len(schema_info)):
                infos = schema_info[col_index].split(":")
                names.append(infos[0])
                type.append(infos[1])
        elif index == 1:
            for col_index in range(len(row)):
                if row[col_index] is not None:
                    schema.append(type_value_to_type_int(row[col_index], type[col_index]))
                else:
                    if type[col_index] == "string":
                        schema.append(3)
                    elif type[col_index] == "int":
                        schema.append(2)
                    elif type[col_index] == "bigint":
                        schema.append(2)
                    elif type[col_index] == "double":
                        schema.append(1)
                    elif type[col_index] == "boolean":
                        schema.append(4)
                    else:
                        raise RuntimeError(f"unsupport col type: {type[col_index]}")
        else:
            type_row = []
            for col_index in range(len(row)):
                if type[col_index] == "string":
                    if row[col_index] is not None:
                        type_row.append(row[col_index])
                    else:
                        type_row.append(None)
                elif type[col_index] == "int":
                    if row[col_index] is not None:
                        type_row.append(int(row[col_index]))
                    else:
                        type_row.append(None)
                elif type[col_index] == "bigint":
                    if row[col_index] is not None:
                        type_row.append(int(row[col_index]))
                    else:
                        type_row.append(None)
                elif type[col_index] == "double":
                    if row[col_index] is not None:
                        type_row.append(float(row[col_index]))
                    else:
                        type_row.append(None)
                elif type[col_index] == "boolean":
                    if row[col_index] is not None:
                        if row[col_index] == "true":
                            type_row.append(True)
                        else:
                            type_row.append(False)
                    else:
                        type_row.append(None)
                else:
                    raise RuntimeError(f"unsupport col type: {type[col_index]}")
            ret.append(type_row)
    # print(schema_info)

    return ret, schema, names

class PArgs:
    def __init__(self):
        return
    __NO_ARGS__ = [[[]]] #随意一个对象即可
    @staticmethod
    def NoArgs():
        return PArgs.__NO_ARGS__

    @staticmethod
    def IsNoArgs(args):
        return args is PArgs.__NO_ARGS__

def make_sql_args(args: list):
    assert len(args) != 0
    strColArgs = "" # args里面可能会有列
    strArgs = "\"_("

    for i in args:
        if i is None:
            strArgs += ("null,")
        else:
            if type(i) in [ColEval, RollingAggColEval, RollingColEval]:
                strColArgs += f"`{i.name}`" + ','
            else:
                strArgs += str(i) + ','
    if strArgs == "\"_(":
        strArgs = ""
        strColArgs = strColArgs[:-1]
    else:
        strArgs = strArgs[:-1] + ')_\"'
    return str(strColArgs + strArgs)


filter_map = {"__and__": "and", "__or__": "or", "isin": "in",
              "__gt__": ">", "__ge__": ">=", "__lt__": "<", "__le__": "<=", "__eq__": "==", "__ne__": "<>"}

# 生成下推到存储的filter语句
def generate_push_filter_sql(x):
    tmp = ""
    push = True  # 是否能下推

    if type(x) in [ColEval]:
        if x.op == "func":
            if x.func not in filter_map.keys():
                raise RuntimeError(f"invalid filter expr func: {x.func}")
            sql_func = filter_map[x.func]
            if x.func in ["__and__", "__or__"]:
                expr1, push1 = generate_push_filter_sql(x.args[0])
                expr2, push2 = generate_push_filter_sql(x.args[1])
                tmp = f"({expr1}) {sql_func} ({expr2})"
                push = push1 and push2

            elif x.func == "isin":
                # in操作下推
                expr1, _ = generate_push_filter_sql(x.args[0])
                tmp = expr1 + " in ("
                for x in x.args[1]:
                    tmp += f'"{x}",'
                tmp = tmp[:-1] + ")"

            else:
                if type(x.args[1]) != datetime.datetime:
                    push = False
                elif x.func == "__ne__":
                    push = False    # 存储不支持time列!=过滤下推
                else:
                    # 时间相关操作下推
                    expr1, push1 = generate_push_filter_sql(x.args[0])
                    expr2, push2 = generate_push_filter_sql(x.args[1])
                    tmp = f"{expr1} {sql_func} {expr2}"
            return tmp, push

        else:
            return "`" + str(x.name) + "`", push
    elif type(x) in [int, float]:
        return str(x), push
    elif type(x) == float:
        return str(x), push
    elif type(x) == str:
        return f'\'{x}\'', push
    elif type(x) == datetime.datetime:
        return f'\'{x}\'', push
    else:
        raise RuntimeError(f"invalid filter expr type: {type(x)}")


def generate(x, from_df):
    if x is None:
        return "null"
    elif type(x) in [ColEval, RollingAggColEval, RollingColEval]:
        return x.gen_from_df(from_df)
    elif type(x) in [DataFrame, GroupbyDataFrame, RollingDataFrame]:
        return x.gen()
    # 目前所有操作暴露在外面的操作都是针对全表的
    # df2["sfsfsfsfs"] = df2.max(1)
    elif type(x) == MapDataFrame:
        return x.gen2()
    elif type(x) == int:
        return str(x)
    elif type(x) == float:
        return str(x)
    elif type(x) == list:
        return make_sql_args(x)
    elif type(x) == str:
        return f'\'{x}\''
    elif type(x) == datetime.datetime:

        return f'\'{x}\''
    else:
        return str(x)

def check_default_args(func, start: int, end: int, *args):
    """
    检查函数的参数是否都符合默认值
    :param func: 要检查的方法
    :param start: 检查参数在默认参数列表的起始位置，左闭右开
    :param end: 检查参数在默认参数列表的结束位置，左闭右开
    :param args: 要检查的参数
    :return:（检查的参数是否都为默认值，返回的Error)
    """
    name = func.__name__
    default = func.__defaults__
    arg_names = func.__code__.co_varnames[start:end]
    if len(args) != len(arg_names):
        raise RuntimeError(f"unequal length! arg_names: {len(arg_names)}, args: {len(args)}")
    if len(args) > len(default):
        raise RuntimeError(f"the number of parameters to be checked: {len(args)} "
                           f"exceeds the default number: {len(default)}")
    for i in range(len(args)):
        if args[i] != default[i]:
            return False, RuntimeError(f"call {name} with unsupported {arg_names[i]}: {args[i]}")
    return True, None

def close_session_finally(func):
    """
    装饰器，装饰的函数会在finally模块中关闭session，防止连接泄漏
    """
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            raise e
        finally:
            if hasattr(args[0], 'conn'):
                conn = args[0].conn
                if hasattr(conn, 'close_connection') and hasattr(conn, 'auto_close'):
                    if conn.auto_close:
                        #print("===> close")
                        conn.close_connection()
    return wrapper


class ColEval:
    def __init__(self, op, *args):
        self.origin_name = None
        self.name = None
        self.func = None
        self.parent = None
        self.child = None
        self.args = None
        self.numeric = False    # 默认不认为是数值列
        self.op = op
        if op == "col":
            self.name = args[0]
            self.parent = args[1]
            args[1].child = self
            if isinstance(self.parent, ColEval):
                self.numeric = self.parent.numeric
        elif op == "func":
            self.func = args[0]
            self.args = args[1:]
            self.numeric = True     # 计算出来的列认为一定是数值列
        self.df = None  # 按列run时使用的dataframe

    def as_col_name(self):
        assert self.op == "col"
        return "`" + self.name + "`"

    # 选择多列进行groupby视为先建立新的表再groupby
    def groupby(self, by: Union[str, list]):
        raise RuntimeError("not supported temporarily")
        # 上层必须是dataframe类型
        assert isinstance(self.parent, DataFrame)
        new_cols = {}
        new_user_ref = {}
        new_parent_user_ref = {v: k for k, v in self.parent.user_ref.items()}
        # 从上层找对应列
        for i in self.name:
            if i in self.parent.current_all_internal_cols.keys():
                new_cols[i] = self.parent.current_all_internal_cols.get(i)
            else:
                raise RuntimeError(f"get cols error: {i} not exists")
            if i in new_parent_user_ref.keys():
                new_user_ref[new_parent_user_ref.get(i)] = i
            else:
                raise RuntimeError(f"get user_ref error: {i} not exists")
        gb_frame = GroupbyDataFrame(self.parent.conn, self.parent, new_cols, new_user_ref, by)
        df = MapDataFrame(self.parent.conn, gb_frame)
        return df

    # 支持x方向计算udaf
    def max(self, axis='index', skipna=True):
        func = 'max'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.max, 1, 3, axis, skipna)
        if is_default:
            args = PArgs.NoArgs()
        else:
            raise err
        return self._check_and_set_by_axis(func, args, axis)

    def min(self, axis='index', skipna=True):
        func = 'min'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.min, 1, 3, axis, skipna)
        if is_default:
            args = PArgs.NoArgs()
        else:
            raise err
        return self._check_and_set_by_axis(func, args, axis)

    def nunique(self, axis='index', dropna=True):
        func = 'nunique'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.nunique, 1, 3, axis, dropna)
        if is_default:
            args = PArgs.NoArgs()
        else:
            raise err
        return self._check_and_set_by_axis(func, args, axis)

    def any(self, axis='index', skipna=True):
        func = 'any'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.any, 1, 3, axis, skipna)
        if is_default:
            args = PArgs.NoArgs()
        else:
            raise err
        return self._check_and_set_by_axis(func, args, axis)

    def all(self, axis='index', skipna=True):
        func = 'all'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.all, 1, 3, axis, skipna)
        if is_default:
            args = PArgs.NoArgs()
        else:
            raise err
        return self._check_and_set_by_axis(func, args, axis)

    def count(self, axis='index'):
        func = 'count'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.count, 1, 2, axis)
        if is_default:
            args = PArgs.NoArgs()
        else:
            raise err
        return self._check_and_set_by_axis(func, args, axis)

    def sum(self, axis='index'):
        func = 'sum'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.sum, 1, 2, axis)
        if is_default:
            args = PArgs.NoArgs()
        else:
            raise err
        return self._check_and_set_by_axis(func, args, axis)

    def percentile(self, q: float):
        func = "percentile"
        return ColEval("func", f"{func}", self, q)

    def prod(self, axis='index', skipna=True):
        func = 'prod'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.prod, 1, 3, axis, skipna)
        if is_default:
            args = PArgs.NoArgs()
        else:
            raise err
        return self._check_and_set_by_axis(func, args, axis)

    def mean(self, axis='index'):
        func = 'mean'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.mean, 1, 2, axis)
        if is_default:
            args = PArgs.NoArgs()
        else:
            raise err
        return self._check_and_set_by_axis(func, args, axis)

    def mad(self, axis='index'):
        func = 'mad'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.mad, 1, 2, axis)
        if is_default:
            args = PArgs.NoArgs()
        else:
            raise err
        return self._check_and_set_by_axis(func, args, axis)

    # 必须x计算udaf
    def corr(self, other: ColEval, method='pearson'):
        func = 'corr'
        if type(other) not in [ColEval, RollingAggColEval, RollingColEval]:
            raise RuntimeError(f"call {func} with invalid type of other: {type(other)}, other: {other}")

        is_default, err = check_default_args(ColEval.corr, 2, 3, method)
        if not is_default:
            raise err
        args = [other, method]
        return self._check_and_set_by_axis(func, args)

    def corr_selector(self, method='pearson'):
        if method == 'pearson':
            return ColEval.corr_pearson
        else:
            raise RuntimeError(f"call corr with unsupported method: {method}")

    def corr_pearson(self, col: ColEval):
        return self.corr(col, 'pearson')

    def cov(self, other: ColEval, ddof=1):
        func = 'cov'
        if type(other) not in [ColEval, RollingAggColEval, RollingColEval]:
            raise RuntimeError(f"call {func} with invalid type of other: {type(other)}, other: {other}")

        is_default, err = check_default_args(ColEval.cov, 2, 3, ddof)
        if not is_default:
            raise err
        args = [other, ddof]
        return self._check_and_set_by_axis(func, args)

    def average(self, weights: ColEval=None, axis='index'):
        func = 'average'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.average, 1, 3, weights, axis)
        if not is_default and "weights" not in err.args[0]:
            raise err

        if type(weights) not in [ColEval, RollingAggColEval, RollingColEval, None]:
            raise RuntimeError(f"call {func} with invalid type of weights: {type(weights)}, weights: {weights}")
        args = [weights]

        return self._check_and_set_by_axis(func, args, axis)

    # 支持x方向计算udf
    def cumsum(self, axis='index', skipna=True):
        func = 'cumsum'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.cumsum, 1, 2, axis)
        if not is_default:
            raise err
        args = [axis, skipna]
        return self._check_and_set_by_axis(func, args, axis)

    def cumprod(self, axis='index', skipna=True):
        func = 'cumprod'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.cumprod, 1, 2, axis)
        if not is_default:
            raise err
        args = [axis, skipna]
        return self._check_and_set_by_axis(func, args, axis)

    def cummin(self, axis='index', skipna=True):
        func = 'cummin'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.cummin, 1, 2, axis)
        if not is_default:
            raise err
        args = [axis, skipna]
        return self._check_and_set_by_axis(func, args, axis)

    def cummax(self, axis='index', skipna=True):
        func = 'cummax'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.cummax, 1, 2, axis)
        if not is_default:
            raise err
        args = [axis, skipna]
        return self._check_and_set_by_axis(func, args, axis)

    def rank(self, axis='index', method='average', numeric_only=None, na_option='keep', ascending=True, pct=False):
        func = 'rank'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.rank, 1, 7, axis, method, numeric_only, na_option, ascending, pct)
        if not is_default and "ascending" not in err.args[0]:
            raise err
        args = [axis, method, numeric_only, na_option, ascending, pct]
        return self._check_and_set_by_axis(func, args, axis)

    # rank后进行组内重新排序
    def srank(self, axis='index', method='average', numeric_only=None, na_option='keep', ascending=True, pct=False, sort_ascending=True):
        func = 'srank'
        axis = 'index' if axis == 0 else axis
        is_default, err = check_default_args(ColEval.srank, 1, 8, axis, method, numeric_only, na_option, ascending, pct, sort_ascending)
        if not is_default and "ascending" not in err.args[0]:
            raise err
        args = [axis, method, numeric_only, na_option, ascending, pct, sort_ascending]
        return self._check_and_set_by_axis(func, args, axis)

    # 不支持x方向计算udaf
    def first(self):
        func = 'first'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def last(self):
        func = 'last'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def argmax(self):
        func = 'argmax'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def std(self, skipna=True, ddof=1):
        func = 'std'
        is_default, err = check_default_args(ColEval.std, 1, 3, skipna, ddof)
        if not is_default:
            raise err
        args = [skipna, ddof]
        return self._check_and_set_by_axis(func, args)

    def var(self, skipna=True, ddof=1):
        func = 'var'
        is_default, err = check_default_args(ColEval.var, 1, 3, skipna, ddof)
        if not is_default:
            raise err
        args = [skipna, ddof]
        return self._check_and_set_by_axis(func, args)

    def kurt(self, skipna=True):
        func = 'kurt'
        is_default, err = check_default_args(ColEval.kurt, 1, 2, skipna)
        if not is_default:
            raise err
        args = [skipna]
        return self._check_and_set_by_axis(func, args)

    def skew(self, skipna=True):
        func = 'skew'
        is_default, err = check_default_args(ColEval.skew, 1, 2, skipna)
        if not is_default:
            raise err
        args = [skipna]
        return self._check_and_set_by_axis(func, args)

    def apply(self, function):  # todo：参数检验标准？
        func = 'apply'
        id = str(uuid.uuid1())
        t = self
        while 1:
            if t.parent is None:
                break
            else:
                t = t.parent
        t.conn._register(id, t.table, str(cloudpickle.dumps(function)), "function")
        return self._check_and_set_by_axis(func, [id])

    # 不支持x方向计算udf
    def sign(self):
        func = 'sign'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def negative(self):
        func = 'negative'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def abs(self):
        func = 'abs'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def minute(self):
        func = "minute"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def hour(self):
        func = "hour"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def hour_idx(self):
        func = "hour_idx"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def hour_align(self):
        func = "hour_align_naive"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def hour_align_right(self):
        func = "hour_align_right_naive"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def flexible_minute_align(self, arg ):
        return ColEval("func", "flexible_minute_align", self, arg)

    def flexible_minute_align_right(self, arg):
        return ColEval("func", "flexible_minute_align_right", self, arg)

    def flexible_second_align(self, arg ):
        return ColEval("func", "flexible_second_align", self, arg)

    def flexible_second_align_right(self, arg ):
        return ColEval("func", "flexible_second_align_right", self, arg)


    def day_idx(self):
        func = "day_idx"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def day_align_naive(self):
        func = "day_align_naive"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def day_align_right_naive(self):
        func = "day_align_right_naive"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def day_align(self):
        func = "day_align_local"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def day_align_right(self):
        func = "day_align_right_local"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def week_align(self):
        func = "week_align_local"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def week_align_left(self):
        func = "week_align_left_local"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def month_align(self):
        func = "month_align_local"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def month_align_right(self):
        func = "month_align_right_local"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def quarter_align(self):
        func = "quarter_align_local"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def quarter_align_right(self):
        func = "quarter_align_right_local"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def year_align(self):
        func = "year_align_local"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def year_align_right(self):
        func = "year_align_right_local"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)


    def month_idx(self):
        func = "month_idx"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def year_idx(self):
        func = "year_idx"
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def square(self):
        func = 'square'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def cube(self):
        func = 'cube'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def root(self):
        func = 'root'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def exp(self):
        func = 'exp'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def ln(self):
        func = 'ln'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def sin(self):
        func = 'sin'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def cos(self):
        func = 'cos'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def tan(self):
        func = 'tan'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def asin(self):
        func = 'asin'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def acos(self):
        func = 'acos'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def atan(self):
        func = 'atan'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def astype(self, typeName: str):
        func = 'cast'
        tqlTypeName = ""
        if typeName == int.__name__:
            tqlTypeName = "int"
        elif typeName == float.__name__:
            tqlTypeName = "float"
        elif typeName == str.__name__ or typeName == "string":
            tqlTypeName = "string"
        elif typeName == "date":
            tqlTypeName = "date"
        elif typeName == "minute":
            tqlTypeName = "minute"
        else:
            raise RuntimeError("error type " + typeName)
        args = tqlTypeName
        return self._check_and_set_by_axis(func, args)

    def pow(self, arg):
        func = 'pow'
        if type(arg) not in [float, int]:
            raise RuntimeError(f"call {func} with invalid type of arg: {type(arg)}, arg: {arg}")
        args = arg
        return self._check_and_set_by_axis(func, args)

    def log(self, arg):
        func = 'log'
        if type(arg) not in [float, int]:
            raise RuntimeError(f"call {func} with invalid type of arg: {type(arg)}, arg: {arg}")
        if arg <=0 or arg == 1:
            raise RuntimeError(f"call {func} with invalid arg: {arg}, arg value range: arg > 0 and arg != 1")
        args = arg
        return self._check_and_set_by_axis(func, args)

    def diff(self, periods):
        func = 'diff'
        if type(periods) not in [int]:
            raise RuntimeError(f"call {func} with invalid type of periods: {type(periods)}, periods: {periods}")
        if periods <= 0:
            raise RuntimeError(f"{func} periods must greater than 0, periods: {periods}")
        args = [periods]
        return self._check_and_set_by_axis(func, args)

    def shift(self,
              periods: int,
              freq: Union[timedelta, str] = None,
              # timelyre增加
              on: str = None,
              ):
        """
        :param periods: 移动的周期数
        :param freq: 周期,没有指定时间，则按照行进行移动
        :param on: 时间列如果使用固定时间周期，需要指定以哪列为时间标准列
        :return:
        """
        func = 'shift'
        if type(periods) not in [int]:
            raise RuntimeError(f"call {func} with invalid type of periods: {type(periods)}, periods: {periods}")
        if periods < 0:
            raise RuntimeError(f"{func} periods must greater than or equal to 0, periods: {periods}")
        is_default, err = check_default_args(ColEval.shift, 2, 4, freq, on)
        if not is_default:
            raise err
        args = [periods, freq, on]
        return self._check_and_set_by_axis(func, args)

    def value_counts(self, normalize=False, sort=True, dropna=True):
        func = 'value_counts'
        is_default, err = check_default_args(ColEval.value_counts, 1, 4, normalize, sort, dropna)
        if not is_default:
            raise err
        args = [normalize, sort, dropna]
        return self._check_and_set_by_axis(func, args)

    def replace(self, to_replace=None, value=None):
        func = 'replace'
        if type(to_replace) not in [float]:
            raise RuntimeError(f"call {func} with unsupported type of to_replace: {type(to_replace)}, to_replace: {to_replace}")
        if type(value) not in [float]:
            raise RuntimeError(f"call {func} with unsupported type of value: {type(value)}, value: {value}")
        args = [to_replace, value]
        return self._check_and_set_by_axis(func, args)

    def drop_duplicates(self, subset=None, keep='first', inplace=False):
        func = 'drop_duplicates'
        # assert keep in ['first', 'last', False]
        is_default, err = check_default_args(ColEval.drop_duplicates, 1, 4, subset, keep, inplace)
        if not is_default:
            raise err
        args = [subset, keep, inplace]
        return self._check_and_set_by_axis(func, args)

    def interpolate(self):
        func = 'interpolate'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def fillna(self, value, inplace=False, limit=None): # todo: value检查
        func = 'fillna'
        is_default, err = check_default_args(ColEval.fillna, 2, 4, inplace, limit)
        if not is_default:
            raise err
        args = [value, inplace, limit]
        return self._check_and_set_by_axis(func, args)

    def ceil(self):
        func = 'ceil'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def floor(self, decimals=0):
        func = 'floor'
        args = PArgs.NoArgs()
        return self._check_and_set_by_axis(func, args)

    def round(self, decimals=0):
        func = 'round'
        if type(decimals) not in [int]:
            raise RuntimeError(f"call {func} with invalid type of decimals: {type(decimals)}, decimals: {decimals}")
        if decimals < 0:
            raise RuntimeError(f"call {func} must with decimals >= 0, current decimals: {decimals}")
        args = decimals
        return self._check_and_set_by_axis(func, args)

    def ema(self, arg):
        func = 'ema'
        # args = [arg]
        if type(arg) not in [int]:
            raise RuntimeError(f"call {func} with invalid type of arg: {type(arg)}, arg: {arg}")
        if arg < 1:
            raise RuntimeError(f"call {func} with invalid arg: {arg}, arg value range: arg >= 1")
        # return self._check_and_set_by_axis(func, args)
        return ColEval("func", "ema", self, arg)

    def __eq__(self, other):
        return ColEval("func", "__eq__", self, other)

    def isin(self, values: list):
        if type(values) is not list:
            raise RuntimeError(f"type values must be list, now is {type(values)}")
        return ColEval("func", "isin", self, values)

    def __ne__(self, other):
        return ColEval("func", "__ne__", self, other)

    def __sub__(self, other):
        return ColEval("func", "__sub__", self, other)

    def __rsub__(self, other):
        self = self.negative()
        return self.__add__(other)

    def __truediv__(self, other):
        return ColEval("func", "__truediv__", self, other)

    def __rtruediv__(self, other):
        return ColEval("func", "__truediv__", other, self)

    def __add__(self, other):
        return ColEval("func", "__add__", self, other)

    def __radd__(self, other):
        return self.__add__(other)

    def __mod__(self, other):
        return ColEval("func", "__mod__", self, other)

    def __rmod__(self, other):
        return ColEval("func", "__mod__", other, self)

    def __pow__(self, other):
        return ColEval("func", "__pow__", self, other)

    def __lt__(self, other):
        return ColEval("func", "__lt__", self, other)

    def __le__(self, other):
        return ColEval("func", "__le__", self, other)

    def __gt__(self, other):
        return ColEval("func", "__gt__", self, other)

    def __ge__(self, other):
        return ColEval("func", "__ge__", self, other)

    def __mul__(self, other):
        return ColEval("func", "__mul__", self, other)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __or__(self, other):
        return ColEval("func", "__or__", self, other)

    def __and__(self, other):
        return ColEval("func", "__and__", self, other)

    def __ror__(self, other):
        return self.__or__(other)

    def __setitem__(self, key, value):
        if self.op == "col":
            col_name = self.origin_name
            # case_when对照的user_ref从parent拿
            self.parent[col_name] = ColEval("func", "case_when", key, value, self)
            self.parent[col_name].numeric = self.numeric
            # return ColEval("func", "case when", key, value, self)
        else:
            raise RuntimeError(f"invalid op: {self.op}")

    def __getitem__(self, value):
        # df["adadada"] = df['code'][df["close"] >= 2] 情况
        if self.op == "col":
            return ColEval("func", "case_when", value, self)
        else:
            raise RuntimeError(f"invalid op: {self.op}")

    def rolling(self,
                window: int,
                # timelyre 增加
                freq: Union[timedelta, str] = None,
                on: str = None,
                # todo closed区间左右开闭
                # todo win_type窗函数，设置窗内数据权重
                # todo min_periods窗内最少有几个数据，否则为NaN
                ):

        """
        滑动窗口函数
        :param window:窗口大小
        :param freq:默认为None，如果不指定，则按照个数选择窗口大小
        :param on:如果freq按照时间确定窗口大小，需要使用on指定列
        :return:
        """
        # 只能跟在列后
        assert self.op == "col"
        if type(window) != int:
            raise RuntimeError(f"invalid rolling window type: {type(window)}, window: {window}")
        if window <= 0:
            raise RuntimeError(f"rolling window must greater than 0, window: {window}")
        is_default, err = check_default_args(ColEval.rolling, 2, 4, freq, on)
        if not is_default:
            raise err
        rolling_args = {'window': window, 'freq': freq, 'on': on}
        return RollingColEval(self.name,rolling_args, self.parent.conn, self.parent.table, self.parent)

    def _check_and_set_by_axis(self, func, args, axis='index'):
        assert axis in [0, 1, 'index', 'columns']
        # 区分x向和y向聚合
        if axis in [0, 'index']:
            # 没支持x计算的一律不支持df[list[cols]]
            # 函数前为其他的：
            #   1. 被 getitem 过滤，只有 col
            #   2. 跟在其他函数后面，递归保证得到一个 col
            if self.name is not None and type(self.name) is list:
                raise RuntimeError(f"{func} cannot calculate df[list[cols]], please split list[cols] and use df[col]")
            if PArgs.IsNoArgs(args):
                return ColEval("func", f"{func}", self)
            else:
                return ColEval("func", f"{func}", self, args)
        else:
            args[0] = 'columns'
            return ColEval("func", f"{func}_x", self, args)

    def gen_from_df(self, from_df):
        """
        DataFrame.gen()调用，生成子sql
        :param from_df: 源df
        :return: 子sql
        """
        if self.op == "col":
            return "`" + str(self.name) + "`"
            # if self.parent is None or self.parent is from_df:
            #     return str(self.name)
            # else:
            #     目前针对于df3['abc'] = df3.groupby(["code"])['close'].max()需要生成子查询
            #     assert isinstance(self.parent, DataFrame)
            #     # self(ColEval) -> self.parent(MapDataFrame) -> self.p.p(GroupbyDataFrame)
            #     self.parent.choose_necessary_cols([self.name])
            #     # 子查询
            #     tmp = f"select" + f" {str(self.name)} from (\n{self.parent.gen()})"
            #     return tmp
        elif self.op == "func":
            tmp = self.func + "("
            if len(self.args) == 0:
                pass
            elif len(self.args) >= 1:
                tmp += generate(self.args[0], from_df)
                if len(self.args) >= 2:
                    for x in self.args[1:]:
                        tmp += ", " + generate(x, from_df)
            tmp += ")"
            return tmp
        else:
            raise RuntimeError(f"cannot recognize ColEval type {self.op}")

    def find_dfs(self):
        """
        获取当前列parent中，最外层和最内层DataFrame（最外层指df最外面的parent）
        :return: 最外层df，最内层df
        """
        if type(self) == ColEval:
            df = self.args[0].parent        # 获取最外层dataframe
        elif type(self) == RollingAggColEval:
            df = self.rollingeval.parent    # 获取最外层dataframe
        else:
            raise RuntimeError(f"unsupported way to run {type(self)}")

        last = df

        while True:  # 获取最内层df
            a = last.child
            if isinstance(a, ColEval) or a is None:
                break
            last = a
        return df, last

    def gen_df(self):
        """
        获取按列run时使用的DataFrame，并存在自身变量中
        """
        if self.df is not None:     # 不重复生成
            return
        assert type(self) == ColEval
        first_df, last_df = self.find_dfs()
        assert type(first_df) == DataFrame

        func = self.func

        if type(self) == ColEval:
            # print("\ngen in ColEval")
            if type(first_df.child) == GroupbyDataFrame or type(last_df) == GroupbyDataFrame:
                if func not in udaf_methods.keys():
                    raise RuntimeError(f"unsupported func: {func} after groupby col")

                # groupby后聚合单列，走原来的aggregate逻辑
                # eg: df.groupby("code")["a"].xxx()
                if func == "corr":
                    self.df = last_df.aggregate({(self.args[0].name, self.args[1][0].name): [ColEval.corr_selector(self.args[1][1])]})
                elif func == "cov":
                    raise RuntimeError("unsupported temporary")
                elif func == "average":
                    self.df = last_df.aggregate({(self.args[0].name, self.args[1][0].name): [ColEval.average]})
                else:
                    self.df = last_df.aggregate({self.args[0].name: [self.func]})

            else:
                # eg: df["a"].xxx()
                # 1. 聚合函数，表示聚合一整列，返回单值
                if func in udaf_methods.keys():
                    self.df = last_df.get_aggr_full_col_df(self)
                # 2. udf，返回这一列的结果
                elif func in udf_methods.keys():
                    raise RuntimeError(f"udf func: {func} after col unsupported temporary")  # todo: 可以实现一个获取单列的DF把它包起来。注意一定不能直接用groupby df包装
                else:
                    raise RuntimeError(f"invalid func: {func}")

        else:
            raise RuntimeError(f"invalid type: {type(self)}")

    def run_df(self, use_parallel: bool, parallelism: int, generate_mode: bool):
        """
        按列run
        """
        assert self.df is not None

        first_df, last_df = self.find_dfs()
        assert type(first_df) == DataFrame

        if type(self) == ColEval:
            # print("\nrun in ColEval")
            if type(first_df.child) == GroupbyDataFrame or type(last_df) == GroupbyDataFrame:
                # eg: df.groupby("code")["a"].xxx()
                return self.df.run(use_parallel, parallelism, generate_mode)

            else:
                # eg: df["a"].xxx()
                func = self.func
                # 1. 聚合函数，表示聚合一整列，返回单值
                if func in udaf_methods.keys():
                    return self.df.run_aggr_full_col_df(self)
                # 2. udf，返回这一列的结果
                elif func in udf_methods.keys():
                    raise RuntimeError("todo")
                else:
                    raise RuntimeError(f"invalid func: {func}")

        else:
            raise RuntimeError(f"invalid type: {type(self)}")

    def gen(self, prefix_space=0):
        """
        通过 ColEval单独生成的sql
        :param prefix_space: sql字符串中间隔的空格数量
        :return: sql
        """
        self.gen_df()
        return self.df.gen(prefix_space)

    def run(self, use_parallel: bool = False, parallelism: int = 1, generate_mode: bool = False):
        """
        通过 ColEval进行run
        :param use_parallel: 是否开启并行
        :param parallelism:  并行线程数量
        :param generate_mode:
        :return:
        """
        self.gen_df()
        return self.run_df(use_parallel, parallelism, generate_mode)

class RollingColEval:
    @staticmethod
    def make_func(name):
        def newfunc(self, *args):
            return RollingAggColEval(self, name, *args)

        return newfunc

    @staticmethod
    def method_init():
        for i, j in udaf_methods.items():
            newfunc = RollingColEval.make_func(i)
            newfunc.__name__ = i
            setattr(RollingColEval, i, newfunc)

    def __init__(self, col, rolling_args, conn, table, parent):
        self.col = col
        self.rolling_args = rolling_args
        self.conn=conn
        self.table=table
        self.parent = parent

    def gen_from_df(self, from_df, parent=None):
        if parent is None or type(parent) is not RollingAggColEval:
            raise RuntimeError(f"must append an function after rolling()")
        return f"rolling(`{self.col}`, {make_sql_args(list(self.rolling_args.values()))})"


class RollingAggColEval(ColEval):
    def __init__(self, reval, aggname, *args):
        ColEval.__init__(self, "rolling_accum")
        self.rollingeval = reval
        self.aggname = aggname
        # for rolling().apply()
        if aggname == 'applyAggregation':
            self.aggname = "applyRollingAggregation"
            id = str(uuid.uuid1())
            if len(args) == 0:
                raise TypeError("applyAggregation need 1 funciton argument")
            self.rollingeval.conn._register(id, self.rollingeval.table, str(cloudpickle.dumps(args[0])), "function")
            self.args = [make_sql_args([id])]
        else:
            self.args = args
        self.parent = reval.parent

    def gen_from_df(self, from_df):
        if len(self.args) > udaf_methods[self.aggname]:
            raise RuntimeError(f"df_xxx['{self.rollingeval.col}'].rolling(xxx).{self.aggname}()"
                               f" acquire most {udaf_methods[self.aggname]} arguments, but {len(self.args)} were given")

        if self.aggname == "applyRollingAggregation":
            return self.rollingeval.gen_from_df(from_df, self) + "." + self.aggname + f"({self.args[0]})"

        if len(self.args) > 0:
            # df['r1'].rolling(6).corr(df['r2'])转换为df[['r1', 'r2']].rolling(6).corr()一样的sql
            col_list = []
            if type(self.args[0]) is ColEval:
                col_list.append(self.args[0].name)
                self.args = self.args[1:]
            elif type(self.args[0]) is list and type(self.args[0][0]) is ColEval:
                for col in self.args[0]:
                    assert type(col) is ColEval
                    col_list.append(col.name)
                self.args = self.args[1:]
            if len(col_list) > 0:
                if type(self.rollingeval.col) is str:
                    col_list.insert(0, self.rollingeval.col)
                    self.rollingeval.col = col_list
                elif type(self.rollingeval.col) is list and type(self.args[0][0]) is str:
                    self.rollingeval.col.extend(col_list)
                else:
                    raise RuntimeError(f"generate rollingeval col failure")
            return self.rollingeval.gen_from_df(from_df, self) + "." + self.aggname + f"({list(self.args)})"
        # len(self.args) == 0 和其他情况保持一致，统一处理为不输出[]
        else:
            return self.rollingeval.gen_from_df(from_df, self) + "." + self.aggname + "()"

    def gen_df(self):
        """
        获取按列run时使用的DataFrame，并存在自身变量中
        """
        if self.df is not None:
            return
        first_df, last_df = self.find_dfs()
        assert type(first_df) == DataFrame

        func = self.aggname
        if func not in udaf_methods.keys():     # rolling只支持udaf
            raise RuntimeError(f"should not be here, invalid func: {func}")
        if func in ["corr", "cov"]:
            raise RuntimeError(f"rolling aggr with func: {func} unsupported temporary")

        if type(self) == RollingAggColEval:
            # print("\ngen in RollingAggColEval")
            if type(last_df) == GroupbyDataFrame:
                # eg: df.groupby("code")["a"].rolling(n).xxx()
                self.df = last_df.get_rolling_col_df(self)
            else:
                # eg: df["a"].rolling(n).xxx()
                self.df = last_df.get_rolling_col_df(self)     # todo: 混合使用可能会出问题

        else:
            raise RuntimeError(f"invalid type: {type(self)}")

    def run_df(self, use_parallel: bool, parallelism: int, generate_mode: bool):
        """
        按列run
        """
        assert self.df is not None

        first_df, last_df = self.find_dfs()
        assert type(first_df) == DataFrame

        func = self.aggname
        if func not in udaf_methods.keys():     # rolling只支持udaf
            raise RuntimeError(f"should not be here, invalid func: {func}")

        if type(self) == RollingAggColEval:
            # print("\nrun in RollingAggColEval")
            if type(first_df.child) == GroupbyDataFrame or type(last_df) == GroupbyDataFrame:
                # eg: df.groupby("code")["a"].rolling(n).xxx()
                return self.df.run(use_parallel, parallelism, generate_mode)

            else:
                # eg: df["a"].rolling(n).xxx()
                raise RuntimeError("rolling aggr without groupby unsupported temporary")

        else:
            raise RuntimeError(f"invalid type: {type(self)}")

__funcs = {"sum": ColEval.sum, "count": ColEval.count, "mean": ColEval.mean, "min": ColEval.min, "max": ColEval.max,
           "std": ColEval.std, "first": ColEval.first, "last": ColEval.last, "var": ColEval.var, "value_counts": ColEval.value_counts,
           "kurt": ColEval.kurt, "skew": ColEval.skew, "mad": ColEval.mad, "nunique": ColEval.nunique, "any": ColEval.any,
           "all": ColEval.all, "argmax": ColEval.argmax, "cov": ColEval.cov, "prod": ColEval.prod, "corr": ColEval.corr_selector,
           "average": ColEval.average}
def get_func_by_name(name):
    if name not in __funcs.keys():
        raise RuntimeError(f"unsupported udaf method: {name}")
    return __funcs[name]

class DataFrame:
    def __init__(self, conn: DatabaseConn, table, schema, db:str=None, user_ref=None, source_filter: str=None, **kwargs):
        """
        todo 从数据库初始化
        """

        #数据库连接
        self.conn = conn

        #当前层所有列的schema，也即上游可以提供给当前层的列名 + 当前层实际扩展出来的列
        self.schema = schema

        self.col_counter = 0

        self.db = db

        if db is not None:
            self.table = f"{db}.{table}"
        else:
            self.table = table

        """
        记录用户实际在当前DataFrame可以用到的所有的变量名，使用内部当前user_ref最新的唯一id名。
        这个随着用户操作DataFrame[x]是会增加的
        """
        self.current_all_internal_cols = {
        }

        self.raw_numeric_cols = None    # 表中最原始的数值列名列表

        if self.table not in ["anon", "group_by_dataframe", "applyGroupByAggregation","applyRollingAggregation","apply"]:
            self.raw_numeric_cols = self.__get_raw_numeric_col_names()

        for x in schema:
            self.current_all_internal_cols[x] = ColEval("col", x, self)
            if self.raw_numeric_cols is not None and x in self.raw_numeric_cols:
                self.current_all_internal_cols[x].numeric = True

        # user_ref为一个从python dataframe列名到内部列名的映射
        if user_ref is not None:
            self.user_ref = user_ref
        else:
            self.user_ref = self.current_all_internal_cols.copy()

        self.db = db

        # db只在最开始的df中设置
        if db is not None:
            if (db.islower() or not db.isascii()) and (table.islower() or not table.isascii()):
                self.table = f"`{db}`.`{table}`"
            else:
                raise ValueError(f"table only support lowercase string, but {db}.{table}")
            for x in schema:
                if x.isascii() and not x.islower():
                    raise ValueError(f"column name only support lowercase string, but {x}")
        else:
            self.table = table
        self.table_without_db = table
        self.parent = None

        self.child = None

        self.group_by_cols = None

        self.rolling_args = None

        self.limit_args = None

        # 用于计算某一个中间结果（可以用于计算udaf（不允许和udf混杂））
        self.virtual = False

        self.source_filter = source_filter

        # ctas相关信息
        self.ctas_enabled = False

        self.ctas_str = None
    def next_id(self):
        self.col_counter += 1
        return self.col_counter

    # 用于计算某一个中间结果
    def virtual_copy(self):
        r = copy.deepcopy(MapDataFrame(self.conn, self))
        r.virtual = True
        return r

    def filter(self, eval):
        # 下推的filter
        if type(self) == DataFrame:
            if self.source_filter is not None:
                raise RuntimeError(f"source filter already defined: {self.source_filter}")

            if type(eval) == str:
                self.source_filter = eval
                df = MapDataFrame(self.conn, self)  # 包一层表示source结束
            else:
                expr, push = generate_push_filter_sql(eval)
                # 解析表达式，根据返回结果决定是否下推
                if push:
                    self.source_filter = expr
                    push_only = False                   # 为True时，对于可下推的filter只进行下推操作，可用于验证下推是否真正起效
                    if push_only or " in " in expr:     # 包含in的可下推filter，只进行下推操作
                        df = MapDataFrame(self.conn, self)
                    else:
                        df = MapDataFrame(self.conn, self, filter=eval)     # 同时进行下推和非下推的filter，如果下推没起作用，由非下推filter保证返回结果正确
                else:
                    df = MapDataFrame(self.conn, self, filter=eval)
            return df
        # 非下推的filter
        else:
            df = MapDataFrame(self.conn, self, filter=eval)
            return df

    def limit(self, n):
        assert n <= 30000, "Not support limit more than 100000 currently."
        xx = self.virtual_copy()
        xx.limit_args = [n, 0]
        df = xx.run()
        final_df = df.head(n)
        return final_df

    # 目前用于解决df3['abc'] = df3.groupby(["code"])['close'].max()在子查询中重复出现的max函数
    def delete_col_forward(self, col):
        for k, v in dict(self.current_all_internal_cols).items():
            if type(v) is ColEval and v.args[0] is col:
                if k in self.schema:
                    self.schema.remove(k)
                for a, b in dict(self.user_ref).items():
                    if b is k:
                        del self.user_ref[a]
                del self.current_all_internal_cols[k]
        if isinstance(self.parent, DataFrame):
            self.parent.delete_col_forward(col)

    def choose_necessary_cols(self, col_list):
        if type(self) is GroupbyDataFrame:
            if type(self.group_by_cols) is str:
                col_list.append(self.group_by_cols)
            else:
                col_list.extend(self.group_by_cols)

        for k, v in dict(self.user_ref).items():
            if k not in col_list:
                if k in self.schema:
                    self.schema.remove(k)
                for a, b in dict(self.current_all_internal_cols).items():
                    if a is v:
                        del self.current_all_internal_cols[a]
                del self.user_ref[k]
        if isinstance(self.parent, DataFrame):
            self.parent.choose_necessary_cols(col_list)

    def groupby(self, by: Union[str, list]):
        """
        Groupby操作
        :param by: 列名
        :return: GroupbyDataFrame
        """
        # 每一个生成的groupbydataframe视为一张独立的表，这样能够区分
        # df3 = df3.groupby(["code"])
        # 和df3['abc'] = df3.groupby(["code"])['close'].max()
        if isinstance(by, str):
            by_cols = [by]
        else:
            by_cols = by

        by_cols = [self.user_ref[i] for i in by_cols]

        v_self = self #self.virtual_copy()
        gb_frame = GroupbyDataFrame(v_self.conn, v_self, list(v_self.current_all_internal_cols.keys()), v_self.user_ref.copy(), by_cols)
        # df = MapDataFrame(v_self.conn, gb_frame)
        return gb_frame

    def resample(self, window: str, on: str):
        raise ValueError("Please first group by tags")

    # def rolling(self,
    #             window: int,
    #             # timelyre 增加
    #             freq: Union[timedelta, str] = None,
    #             on: str = None,
    #             # todo closed区间左右开闭
    #             # todo win_type窗函数，设置窗内数据权重
    #             # todo min_periods窗内最少有几个数据，否则为NaN
    #             ):
    #
    #     """
    #     滑动窗口函数
    #     :param window:窗口大小
    #     :param freq:默认为None，如果不指定，则按照个数选择窗口大小
    #     :param on:如果freq按照时间确定窗口大小，需要使用on指定列
    #     :return:
    #     """
    #     rolling_args = {'method': None, 'window': window, 'freq': freq, 'on': on}
    #     rolling_frame = RollingDataFrame(self.conn, self, list(self.current_all_internal_cols.keys()), self.user_ref.copy(), rolling_args)
    #     return rolling_frame
    #
    # # 支持x方向计算udaf
    def max(self, axis='index', skipna=True, numeric_only=True):
        is_default, err = check_default_args(DataFrame.max, 1, 4, axis, skipna, numeric_only)
        if not is_default:
            raise err
        func = 'max'
        if self.table != "anon":
            tag_col = self.__get_tag_col_name()
            numeric_cols = self.__get_current_numeric_cols()
            if numeric_cols is None:
                return pd.Series()
            xx = self.virtual_copy()
            aggr_dict = {}
            # 前置计算
            for col in numeric_cols:
                aggr_dict[col] = [ColEval.max]
            xx = xx.groupby(tag_col).aggregate(aggr_dict)
            xx = xx.run()

            # 计算max
            xx = xx.max()
            xx = xx[[f"{col}_max" for col in numeric_cols]]
            xx.index = numeric_cols
            return xx
        else:
            raise ValueError(f"Cannot run .{func} on non-source DataFrame")

    def min(self, axis='index', skipna=True, numeric_only=True):
        is_default, err = check_default_args(DataFrame.min, 1, 4, axis, skipna, numeric_only)
        if not is_default:
            raise err
        func = 'min'
        if self.table != "anon":
            tag_col = self.__get_tag_col_name()
            numeric_cols = self.__get_current_numeric_cols()
            if numeric_cols is None:
                return pd.Series()
            xx = self.virtual_copy()
            aggr_dict = {}
            # 前置计算
            for col in numeric_cols:
                aggr_dict[col] = [ColEval.min]
            xx = xx.groupby(tag_col).aggregate(aggr_dict)
            xx = xx.run()

            # 计算min
            xx = xx.min()
            xx = xx[[f"{col}_min" for col in numeric_cols]]
            xx.index = numeric_cols
            return xx
        else:
            raise ValueError(f"Cannot run .{func} on non-source DataFrame")

    # def nunique(self, axis='index', dropna=True):
    #     func = 'nunique'
    #     args = [axis, dropna]
    #     if self._check_and_set_rolling_dataframe(func, args, axis):
    #         return self
    #     return self._select_map_dataframe_by_axis(func, args, axis)
    #
    # def any(self, axis='index', skipna=True):
    #     func = 'any'
    #     args = [axis, skipna]
    #     if self._check_and_set_rolling_dataframe(func, args, axis):
    #         return self
    #     return self._select_map_dataframe_by_axis(func, args, axis)
    #
    # def all(self, axis='index', skipna=True):
    #     func = 'all'
    #     args = [axis, skipna]
    #     if self._check_and_set_rolling_dataframe(func, args, axis):
    #         return self
    #     return self._select_map_dataframe_by_axis(func, args, axis)
    #
    def sum(self, axis='index', numeric_only=True):
        is_default, err = check_default_args(DataFrame.sum, 1, 3, axis, numeric_only)
        if not is_default:
            raise err
        func = 'sum'
        if self.table != "anon":
            tag_col = self.__get_tag_col_name()
            numeric_cols = self.__get_current_numeric_cols()
            if numeric_cols is None:
                return pd.Series()
            xx = self.virtual_copy()
            aggr_dict = {}
            # 前置计算
            for col in numeric_cols:
                xx[col] = xx[col].astype("float")
                aggr_dict[col] = [ColEval.sum]
            xx = xx.groupby(tag_col).aggregate(aggr_dict)
            xx = xx.run()

            # 计算sum
            xx = xx.sum()
            xx = xx[[f"{col}_sum" for col in numeric_cols]]
            xx.index = numeric_cols
            return xx
        else:
            raise ValueError(f"Cannot run .{func} on non-source DataFrame")

    # def prod(self, axis='index', skipna=True):
    #     func = 'prod'
    #     args = [axis, skipna]
    #     if self._check_and_set_rolling_dataframe(func, args, axis):
    #         return self
    #     return self._select_map_dataframe_by_axis(func, args, axis)

    def __get_tag_col_name(self):
        """
        获取表中tag列列名。需要用到表名
        :return: tag列列名
        """
        tag_col = None
        tag_cols = None
        if isinstance(self.conn, DatabaseConn):
            self.conn.real_db.internal_set_quark_mode()
            r = self.conn.real_db.run_simple_command(f"desc formatted {self.table}")
            self.conn.real_db.internal_set_crux_mode()
            for subList in r:
                k = subList[0]
                v = subList[1]
                if str(k).strip() == "timelyre.tag.cols":
                    tag_cols = str(v).strip().split(",")
                    break
        else:
            r = self.conn.get_table_info(self.table)
            tag_cols = r["tag_cols"]

        if tag_cols is None:
            raise ValueError(f"get no tag cols info from table: {self.table}")

        if len(tag_cols) != 1:
            raise ValueError("tag cols should be only one")
        tag_col = tag_cols[0]
        if tag_col is None:
            raise ValueError(f"cannot find tag col for table {self.table}")
        return tag_col

    def __get_raw_numeric_col_names(self):
        """
        获取表中最初的数值列列名。需要用到表名，因此只能由最初的DataFrame调用
        :return: list，存放表中初始的所有数值列列名。无数值列时返回None
        """
        numeric_cols = []
        if isinstance(self.conn, DatabaseConn):
            self.conn.real_db.internal_set_quark_mode()
            r = self.conn.real_db.run_simple_command(f"desc formatted {self.table}")
            self.conn.real_db.internal_set_crux_mode()
            for subList in r:
                k = subList[0]
                v = subList[1]
                if k in self.schema:
                    if v in numeric_types:
                        numeric_cols.append(k)

        else:
            r = self.conn.get_table_info(self.table)
            schema = r["schema"]
            data_types = r["data_types"]
            for i in range(len(schema)):
                if data_types[i] in numeric_types:
                    numeric_cols.append(schema[i])

        if len(numeric_cols) == 0:
            return None
        return numeric_cols


    def __get_current_numeric_cols(self):
        numeric_cols = [p[0] for p in self.user_ref.items() if p[1].numeric is True]    # 如果没有合法的p，numeric_cols会是None
        return numeric_cols

    def count(self):
        func = "count"
        if self.table != "anon":
            tag_col = self.__get_tag_col_name()
            cal_cols = self.user_ref.keys()
            xx = self.virtual_copy()
            aggr_dict = {}
            # 前置计算
            for col in cal_cols:
                aggr_dict[col] = [ColEval.count]
            xx = xx.groupby(tag_col).aggregate(aggr_dict)
            xx = xx.run()
            xx = xx.sum()
            xx = xx[[f"{col}_count" for col in cal_cols]]
            xx.index = cal_cols
            return xx
        else:
            raise ValueError(f"Cannot run .{func} on non-source DataFrame")
        # xx = self.conn.real_db.run(f"desc formatted default.{table_name}")

    def mean(self, axis='index', numeric_only=True):
        is_default, err = check_default_args(DataFrame.mean, 1, 3, axis, numeric_only)
        if not is_default:
            raise err
        func = "mean"
        if self.table != "anon":
            tag_col = self.__get_tag_col_name()
            numeric_cols = self.__get_current_numeric_cols()
            if numeric_cols is None:
                return pd.Series()
            xx = self.virtual_copy()
            aggr_dict = {}
            # 前置计算
            for col in numeric_cols:
                xx[col] = xx[col].astype("float")
                aggr_dict[col] = [ColEval.sum, ColEval.count]
            xx = xx.groupby(tag_col).aggregate(aggr_dict)
            xx = xx.run()

            # 计算mean
            xx = xx.sum()
            count_res = xx[[f"{col}_count" for col in numeric_cols]]
            sum_res = xx[[f"{col}_sum" for col in numeric_cols]]
            res = pd.Series(sum_res.values / count_res)
            res.index = numeric_cols
            return res
        else:
            raise ValueError(f"Cannot run .{func} on non-source DataFrame")

    # def mad(self, axis='index'):
    #     func = 'mad'
    #     args = [axis]
    #     if self._check_and_set_rolling_dataframe(func, args, axis):
    #         return self
    #     return self._select_map_dataframe_by_axis(func, args, axis)
    #
    # # 必须x计算udaf

    def corr(self, method='pearson', numeric_only=True):
        """
        计算全表的相关性
        :param method: 计算方法
        :param numeric_only: 计算只包含浮点、整型和布尔型数据
        :return:
        """
        is_default, err = check_default_args(DataFrame.corr, 1, 3, method, numeric_only)
        if not is_default:
            raise err
        func = "corr"
        if self.table != "anon":
            assert numeric_only is True
            tag_col = self.__get_tag_col_name()
            numeric_cols = self.__get_current_numeric_cols()   # 筛选出所有数值列
            if numeric_cols is None:
                return pd.DataFrame()
            xx = self.virtual_copy()
            pairs = list(itertools.combinations(numeric_cols, 2))     # 计算出所有列的对。不包括(1,1)，且含(1,2)时不含(2,1)
            aggr_dict = {}
            # 前置计算
            for col in numeric_cols:
                xx[f"{col}2"] = xx[col].pow(2)
                aggr_dict[f"{col}2"] = [ColEval.sum]
                aggr_dict[col] = [ColEval.sum]
            for pair in pairs:
                col1 = pair[0]
                col2 = pair[1]
                xx[f"{col1}_{col2}"] = xx[col1] * xx[col2]
                aggr_dict[f"{col1}_{col2}"] = [ColEval.sum]
            aggr_dict[tag_col] = [ColEval.count]
            xx = xx.groupby(tag_col).aggregate(aggr_dict)
            xx = xx.run()

            # 计算corr
            corr_res_dict = {}
            xx = xx.sum()
            for pair in pairs:
                col1 = pair[0]
                col2 = pair[1]
                molecular = xx[f"{col1}_{col2}_sum"] - xx[f"{col1}_sum"] * xx[f"{col2}_sum"] / float(xx[f"{tag_col}_count"])
                denominator = math.sqrt(
                    (xx[f"{col1}2_sum"] - math.pow(xx[f"{col1}_sum"], 2) / float(xx[f"{tag_col}_count"])) *
                    (xx[f"{col2}2_sum"] - math.pow(xx[f"{col2}_sum"], 2) / float(xx[f"{tag_col}_count"]))
                )
                corr_res_dict[pair] = molecular / denominator

            # 获取最后的df结果
            df = pd.DataFrame([[1.0] * len(numeric_cols)] * len(numeric_cols), columns=numeric_cols, index=numeric_cols)
            for item in corr_res_dict.items():
                col1 = item[0][0]
                col2 = item[0][1]
                df[col1][col2] = item[1]
                df[col2][col1] = item[1]
            return df

        else:
            raise ValueError(f"Cannot run .{func} on non-source DataFrame")

    def cov(self, ddof=1, numeric_only=True):
        """
        计算全表的协方差
        :param ddof:
        :param numeric_only: 计算只包含浮点、整型和布尔型数据
        :return:
        """
        is_default, err = check_default_args(DataFrame.cov, 1, 3, ddof, numeric_only)
        if not is_default:
            raise err
        func = "cov"
        if self.table != "anon":
            pd.set_option("display.max_columns", 1000)
            pd.set_option("display.width", 1000)
            assert numeric_only is True
            tag_col = self.__get_tag_col_name()
            numeric_cols = self.__get_current_numeric_cols()   # 筛选出所有数值列
            if numeric_cols is None:
                return pd.DataFrame()
            xx = self.virtual_copy()
            pairs = list(itertools.combinations(numeric_cols, 2))     # 计算出所有列的对。不包括(1,1)，且含(1,2)时不含(2,1)
            pairs += [(col, col) for col in numeric_cols]
            aggr_dict = {}
            # 前置计算
            # 1. 求每列平均值
            for col in numeric_cols:
                xx[col] = xx[col].astype("float")
                aggr_dict[col] = [ColEval.sum]
            aggr_dict[tag_col] = [ColEval.count]
            xx = xx.groupby(tag_col).aggregate(aggr_dict)
            xx = xx.run()
            xx = xx.sum()
            avg_dict = {}
            for col in numeric_cols:
                avg_dict[col] = xx[f"{col}_sum"] / float(xx[f"{tag_col}_count"])

            # 2.
            xx = self.virtual_copy()
            for col in numeric_cols:
                xx[col] = xx[col].astype("float")
            for pair in pairs:
                col1 = pair[0]
                col2 = pair[1]
                xx[f"{col1}_{col2}"] = (xx[col1] - avg_dict[col1]) * (xx[col2] - avg_dict[col2])
                aggr_dict[f"{col1}_{col2}"] = [ColEval.sum]
            aggr_dict[tag_col] = [ColEval.count]
            xx = xx.groupby(tag_col).aggregate(aggr_dict)
            xx = xx.run()

            # 计算cov
            cov_res_dict = {}
            xx = xx.sum()
            for pair in pairs:
                col1 = pair[0]
                col2 = pair[1]
                cov_res_dict[pair] = xx[f"{col1}_{col2}_sum"] / float(xx[f"{tag_col}_count"] - ddof)

            # 获取最后的df结果
            df = pd.DataFrame([[0.0] * len(numeric_cols)] * len(numeric_cols), columns=numeric_cols, index=numeric_cols)
            for item in cov_res_dict.items():
                col1 = item[0][0]
                col2 = item[0][1]
                df[col1][col2] = item[1]
                df[col2][col1] = item[1]
            return df

        else:
            raise ValueError(f"Cannot run .{func} on non-source DataFrame")

    # # 支持x方向计算udf
    # def cumsum(self, axis='index', skipna=True):
    #     func = 'cumsum'
    #     args = [axis, skipna]
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args, axis)
    #
    # def cumprod(self, axis='index', skipna=True):
    #     func = 'cumprod'
    #     args = [axis, skipna]
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args, axis)
    #
    # def cummin(self, axis='index', skipna=True):
    #     func = 'cummin'
    #     args = [axis, skipna]
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args, axis)
    #
    # def cummax(self, axis='index', skipna=True):
    #     func = 'cummax'
    #     args = [axis, skipna]
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args, axis)
    #
    # def rank(self, axis='index', method='average', numeric_only=None, na_option='keep', ascending=True, pct=False):
    #     func = 'rank'
    #     args = [axis, method, numeric_only, na_option, ascending, pct]
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args, axis)
    #
    # # 不支持x方向计算udaf
    # def first(self):
    #     func = 'first'
    #     args = PArgs.NoArgs()
    #     if self._check_and_set_rolling_dataframe(func, args):
    #         return self
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def last(self):
    #     func = 'last'
    #     args = PArgs.NoArgs()
    #     if self._check_and_set_rolling_dataframe(func, args):
    #         return self
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def argmax(self):
    #     func = 'argmax'
    #     args = PArgs.NoArgs()
    #     if self._check_and_set_rolling_dataframe(func, args):
    #         return self
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def std(self, skipna=True, ddof=1):
    #     func = 'std'
    #     args = [skipna, ddof]
    #     if self._check_and_set_rolling_dataframe(func, args):
    #         return self
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def var(self, skipna=True, ddof=1):
    #     func = 'var'
    #     args = [skipna, ddof]
    #     if self._check_and_set_rolling_dataframe(func, args):
    #         return self
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def kurt(self, skipna=True):
    #     func = 'kurt'
    #     args = [skipna]
    #     if self._check_and_set_rolling_dataframe(func, args):
    #         return self
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def skew(self, skipna=True):
    #     func = 'skew'
    #     args = [skipna]
    #     if self._check_and_set_rolling_dataframe(func, args):
    #         return self
    #     return self._select_map_dataframe_by_axis(func, args)

    # todo 之后再说
    # def apply(self,
    #           func: Callable,
    #           ):
    #     """WARP-82869:apply函数注册，rolling函数支持
    #     面向行应用某函数
    #     :param func:
    #     :return:
    #     """
    #     pass

    def apply(self, function):
        func = 'apply'
        id = str(uuid.uuid1())
        t = self
        while 1:
            if t.parent is None:
                break
            else:
                t = t.parent
        t.conn._register(id, t.table, str(cloudpickle.dumps(function)), "function")
        return MapDataFrame(self.conn, self, f"{func}", make_sql_args([id]))

    def register_public_package(self, package_name):
        t = self
        table_name = ""
        while 1:
            if t.parent is None:
                break
            else:
                t = t.parent
                table_name = t.table

        self.conn._register(func_id=package_name, table_name=table_name, func_body="", package="package")

    def register_local_package(self, file_path):
        package_name = os.path.basename(file_path)
        file = open(file_path, 'rb')
        content = file.read()
        body = zlib.compress(content, zlib.Z_BEST_COMPRESSION)
        t = self
        table_name = t.table
        while 1:
            if t.parent is None:
                break
            else:
                t = t.parent
                table_name = t.table
        self.conn._register(func_id=package_name, table_name=table_name, func_body=body, package="package")

    def register_file(self,file_name,file_path):
        # file_name = os.path.basename(file_path)
        file = open(file_path, 'rb')
        content = file.read()
        body = zlib.compress(content, zlib.Z_BEST_COMPRESSION)
        t = self
        table_name = t.table
        while 1:
            if t.parent is None:
                break
            else:
                t = t.parent
                table_name = t.table
        self.conn._register(func_id=file_name, table_name=table_name, func_body=body, package="file")


    # 不支持x方向计算udf
    # def sign(self):
    #     func = 'sign'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def negative(self):
    #     func = 'negative'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def abs(self):
    #     func = 'abs'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def square(self):
    #     func = 'square'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def cube(self):
    #     func = 'cube'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def root(self):
    #     func = 'root'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def exp(self):
    #     func = 'exp'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def ln(self):
    #     func = 'ln'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def sin(self):
    #     func = 'sin'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def cos(self):
    #     func = 'cos'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def tan(self):
    #     func = 'tan'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def asin(self):
    #     func = 'asin'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def acos(self):
    #     func = 'acos'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def atan(self):
    #     func = 'atan'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def pow(self, arg):
    #     func = 'pow'
    #     args = arg
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def log(self, arg):
    #     func = 'log'
    #     args = arg
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def diff(self, periods):
    #     func = 'diff'
    #     args = [periods]WARP-82869:apply函数注册，rolling函数支持
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def ceil(self, decimals=0):
    #     func = 'ceil'
    #     args = decimals
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def floor(self, decimals=0):
    #     func = 'floor'
    #     args = decimals
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def round(self, decimals=0):
    #     args = decimals
    #     func = 'round'
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def shift(self,
    #           periods: int,
    #           freq: Union[timedelta, str] = None,
    #           # timelyre增加
    #           on: str = None,
    #           ):
    #     """
    #     :param periods: 移动的周期数
    #     :param freq: 周期,没有指定时间，则按照行进行移动
    #     :param on: 时间列如果使用固定时间周期，需要指定以哪列为时间标准列
    #     :return:
    #     """
    #     func = 'shift'
    #     args = [periods, freq, on]
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def value_counts(self, normalize=False, sort=True, dropna=True):
    #     func = 'value_counts'
    #     args = [normalize, sort, dropna]
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def replace(self, to_replace=None, value=None):
    #     func = 'replace'
    #     args = [to_replace, value]
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def drop_duplicates(self, subset=None, keep='first', inplace=False):
    #     assert keep in ['first', 'last', False]
    #     func = 'drop_duplicates'
    #     args = [subset, keep, inplace]
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def interpolate(self):
    #     func = 'interpolate'
    #     args = PArgs.NoArgs()
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)
    #
    # def fillna(self, value, inplace=False, limit=None):
    #     func = 'fillna'
    #     args = [value, inplace, limit]
    #     self._check_and_reject_rolling_dataframe(func)
    #     return self._select_map_dataframe_by_axis(func, args)

    def dropna(self, subset, axis='index', inplace=False, how='any'):
        is_default, err = check_default_args(DataFrame.dropna, 2, 4, axis, inplace)
        if not is_default:
            raise err

        eval = None
        for col in subset:
            cur_expr = (self.__getitem__(col) != None)

            if eval is None:
                eval = cur_expr
            else:
                if how == 'all':
                    eval = eval | cur_expr
                elif how == 'any':
                    eval = eval & cur_expr
                else:
                    raise RuntimeError(f"parameter how only support 'any', 'all'")

        return self.filter(eval)

    @close_session_finally
    def add_columns(self, right_df: pd.DataFrame, schema: list, timestamp_col: str, code_cols: Union[str, list],
                    use_file_upload=True, upload_batch_size=200000):
        if schema is None or len(schema) == 0:
            raise RuntimeError("must specify schema for right_df")
        if isinstance(code_cols, str):
            code_cols_str = code_cols
        elif isinstance(code_cols, list):
            code_cols_str = ",".join(code_cols)
        else:
            raise RuntimeError(f"invalid input code_cols type")
        if timestamp_col == "" or code_cols_str == "":
            raise RuntimeError(f"must specify timestamp_col and code_col in right_df")

        new_cols = []
        right_schema = []
        for i in range(len(schema)):
            right_schema.append(schema[i][0])
            if schema[i][0] != timestamp_col and code_cols_str.find(schema[i][0]) == -1:
                new_cols.append(schema[i][0])

        # check schema, 必须是新的列
        cols = self.conn.real_db.show_columns(f"{self.table_without_db}")
        table_cols = list(list(zip(*cols))[0])
        for col in new_cols:
            if col in table_cols:
                raise RuntimeError(f"col {col} already exists in table {self.table}")

        self.__add_update_columns_impl("add", right_df, schema, new_cols, timestamp_col, code_cols_str, batch_size=upload_batch_size, use_file_upload=use_file_upload)

    def __merge_columns(self, right_tbl_name, new_columns: list, new_col_names: list = [], merge_type=""):
        if len(new_col_names) > 0 and len(new_col_names) != len(new_columns):
            raise RuntimeError(f"new_col_names len {len(new_col_names)} != new_columns len {len(new_columns)}")
        cols_part = ""
        for i in range(len(new_columns)):
            cols_part += f"`{new_columns[i]}` string"
            if len(new_col_names) > 0:
                cols_part += f" as {new_col_names[i]}"
            if i < (len(new_columns) -1):
                cols_part += ","
        if merge_type != "":
            add_columns_sql = f"alter table {self.table} merge table {self.db}.{right_tbl_name} columns ({cols_part}) right table parquet"
        else:
            add_columns_sql = f"alter table {self.table} merge table {self.db}.{right_tbl_name} columns ({cols_part})"
        old_mapping_table = "none"
        self.conn.real_db.internal_set_crux_mode()
        res = self.conn.real_db.run_simple_command(add_columns_sql)
        mapping_table = res[0][0]
        join_sql = res[1][0]
        #print("__merge_columns sql " + join_sql)
        if len(res) > 2:
            old_mapping_table = res[2][0]
        try:
            self.conn.real_db.internal_set_quark_mode()
            self.conn.real_db.run_set_command("set mapred.reduce.tasks=48;")
            self.conn.real_db.run_simple_command(join_sql)
        except Exception as e:
            if mapping_table != "":
                self.conn.real_db.drop_table(mapping_table)
            self.conn.real_db.internal_set_quark_mode()
            self.conn.real_db.run_simple_command(f"alter table {self.table} set tblproperties('timelyre.merge.columns.mapping'='{old_mapping_table}');")
            raise RuntimeError(f"merge columns failed with exception {e}")
        finally:
            # 标记column modification完成
            self.conn.real_db.internal_set_quark_mode()
            self.conn.real_db.run_simple_command(
                f"alter table {self.table} set tblproperties('timelyre.doing.column.modification'='false');")
        # 清理阶段
        if old_mapping_table != "none":
            self.conn.real_db.drop_table(old_mapping_table)

    def __merge_columns_with_parallel(self, right_tbl_name, new_columns: list, new_col_names: list = [], merge_type="",
                                      use_time_range_filter: bool = False, time_range=""):
        if len(new_col_names) > 0 and len(new_col_names) != len(new_columns):
            raise RuntimeError(f"new_col_names len {len(new_col_names)} != new_columns len {len(new_columns)}")
        cols_part = ""
        for i in range(len(new_columns)):
            cols_part += f"`{new_columns[i]}` string"
            if len(new_col_names) > 0:
                cols_part += f" as {new_col_names[i]}"
            if i < (len(new_columns) -1):
                cols_part += ","
        if merge_type != "":
            add_columns_sql = f"alter table {self.table} merge table {self.db}.{right_tbl_name} columns ({cols_part}) right table parquet"
        else:
            add_columns_sql = f"alter table {self.table} merge table {self.db}.{right_tbl_name} columns ({cols_part})"
        add_columns_sql += " parallel"
        if use_time_range_filter and time_range != "":
            add_columns_sql += f" timerange '{time_range}'"
        self.conn.real_db.internal_set_crux_mode()
        res = self.conn.real_db.run_simple_command(add_columns_sql)
        join_sql = res[1][0]
        self.conn.real_db.internal_set_quark_mode()
        self.conn.real_db.run_set_command("set mapred.reduce.tasks=48;")
        self.conn.real_db.run_simple_command(join_sql)

    @close_session_finally
    def drop_columns(self, col_names: list):
        # check schema, 必须是原有的列,不能删除所有的field列
        cols = self.conn.real_db.show_columns(f"{self.table_without_db}")
        prop = self.conn.real_db.show_properties(f"{self.table_without_db}")
        tagstr = prop.get("timelyre.tag.cols")
        tag_cols = []
        if tagstr != "":
            tag_cols = tagstr.split(",")
        time_col = prop.get("timelyre.timestamp.col")
        table_cols = list(list(zip(*cols))[0])
        for col in col_names:
            if col not in table_cols:
                raise RuntimeError(f"col {col} does not exist in table {self.table}")
        count = 0
        for col in table_cols:
            if col in col_names or col in tag_cols or col == time_col:
                count += 1
        if count == len(cols):
            raise RuntimeError("cannot drop all fields")

        cols_part = ""
        for i in range(len(col_names)):
            cols_part += f"`{col_names[i]}` string" # 加一个任意的类型
            if i < (len(col_names) - 1):
                cols_part += ","
        drop_columns_sql = f"alter table {self.table} drop columns ({cols_part})"
        old_mapping_table = "none"
        self.conn.real_db.internal_set_crux_mode()
        res = self.conn.real_db.run_simple_command(drop_columns_sql)
        mapping_table = res[0][0]
        insert_sql = res[1][0]
        if len(res) > 2:
            old_mapping_table = res[2][0]
        try:
            self.conn.real_db.internal_set_quark_mode()
            self.conn.real_db.run_simple_command(insert_sql)
        except Exception as e:
            # 如果drop失败，需要将mapping table设置为旧的mapping table
            self.conn.real_db.internal_set_crux_mode()
            if mapping_table != "":
                self.conn.real_db.drop_table(mapping_table)
            self.conn.real_db.internal_set_quark_mode()
            self.conn.real_db.run_simple_command(f"alter table {self.table} set tblproperties('timelyre.merge.columns.mapping'='{old_mapping_table})';")
            raise RuntimeError(f"drop columns failed with exception {e}")
        finally:
            # 标记column modification完成
            self.conn.real_db.internal_set_quark_mode()
            self.conn.real_db.run_simple_command(
                f"alter table {self.table} set tblproperties('timelyre.doing.column.modification'='false');")
        # 清理阶段: 最后删除旧的mapping table
        if old_mapping_table != "none":
            self.conn.real_db.drop_table(old_mapping_table)

    @close_session_finally
    def update_columns(self, right_df: pd.DataFrame, schema: list, timestamp_col: str, code_cols: str,
                       use_file_upload=True, upload_batch_size=200000):
        if schema is None or len(schema) == 0:
            raise RuntimeError("must specify schema for right_df")
        if isinstance(code_cols, str):
            code_cols_str = code_cols
        elif isinstance(code_cols, list):
            code_cols_str = ",".join(code_cols)
        else:
            raise RuntimeError(f"invalid input code_cols type")
        if timestamp_col == "" or code_cols_str == "":
            raise RuntimeError(f"must specify timestamp_col and code_col in right_df")
        # times = []
        # times.append(time.perf_counter())

        new_cols = []
        right_schema = []
        for i in range(len(schema)):
            right_schema.append(schema[i][0])
            if schema[i][0] != timestamp_col and code_cols_str.find(schema[i][0]) == -1:
                new_cols.append(schema[i][0])

        # check schema, 必须是原有的列
        cols = self.conn.real_db.show_columns(f"{self.table_without_db}")
        table_cols = list(list(zip(*cols))[0])
        for col in new_cols:
            if col not in table_cols:
                raise RuntimeError(f"col {col} does not exist in table {self.table}")

        self.__add_update_columns_impl("update", right_df, schema, new_cols, timestamp_col, code_cols_str, batch_size=upload_batch_size, use_file_upload=use_file_upload)

    @close_session_finally
    def parallel_update_columns(self, right_df: pd.DataFrame, schema: list, timestamp_col: str, code_cols: str,
                       use_file_upload=True, upload_batch_size=200000, use_time_range_filter: bool=True):
        if schema is None or len(schema) == 0:
            raise RuntimeError("must specify schema for right_df")
        if isinstance(code_cols, str):
            code_cols_str = code_cols
        elif isinstance(code_cols, list):
            code_cols_str = ",".join(code_cols)
        else:
            raise RuntimeError(f"invalid input code_cols type")
        if timestamp_col == "" or code_cols_str == "":
            raise RuntimeError(f"must specify timestamp_col and code_col in right_df")
        new_cols = []
        right_schema = []
        for i in range(len(schema)):
            right_schema.append(schema[i][0])
            if schema[i][0] != timestamp_col and code_cols_str.find(schema[i][0]) == -1:
                new_cols.append(schema[i][0])

        # check schema, 必须是原有的列
        cols = self.conn.real_db.show_columns(f"{self.table_without_db}")
        table_cols = list(list(zip(*cols))[0])
        for col in new_cols:
            if col not in table_cols:
                raise RuntimeError(f"col {col} does not exist in table {self.table}")

        self.__add_update_columns_impl("parallel update", right_df, schema, new_cols, timestamp_col, code_cols_str,
                                       batch_size=upload_batch_size, use_file_upload=use_file_upload, with_parallel=True, use_time_range_filter=use_time_range_filter)


    """
    join_column[[]],指定joinkey，
    需要指定tag列,默认tag列必须相等
    需要指定time列,如果没有明确time相等，就是date对齐(设置对齐的时间力度)
    """
    def common_join(self, right_table: str, join_type = JoinType.leftjoin, dst_table: str = "", join_key_list: list = None,
                    time_level: str = "day", left_cols: list = None, right_cols: list = None, left_filter: str = None, right_filter: str = None):
        self.conn.common_join(left_table=self.table, right_table=right_table, dst_table=dst_table,join_key_list=join_key_list,join_type=join_type,
                     left_cols=left_cols, right_cols=right_cols,left_filter=left_filter,right_filter=right_filter)

    def __add_update_columns_impl(self, impl: str, right_df: pd.DataFrame, schema: list, new_cols: list,
                                  timestamp_col: str, code_cols_str: str, batch_size,
                                  use_file_upload=True, with_parallel=False, use_time_range_filter: bool=False):
        if use_file_upload:
            external_table_name = ""
            hdfs_path = ""
            try:
                t1 = time.perf_counter_ns()
                external_table_name, hdfs_path = self.conn.real_db.upload_df(right_df, schema, tag_cols=code_cols_str, ts_col=timestamp_col, batch_size=batch_size)
                t2 = time.perf_counter_ns()
                # 获取当前临时表中time的最大值和最小值，确认时间区间
                time_range = ""
                if use_time_range_filter:
                    nowres = self.conn.real_db.query_raw_data(sql=f"select min({timestamp_col}), max({timestamp_col}) from {external_table_name}")
                    if len(nowres) == 1:
                        try:
                            start_time = self.__from_unix_time(int(nowres[0][0]))
                            end_time = self.__from_unix_time(int(nowres[0][1]))
                            time_range = f"{start_time},{end_time}"
                        except ValueError:
                            getLogger().info(f'get time range failed, back to normal update')
                if with_parallel:
                    self.__merge_columns_with_parallel(external_table_name, new_cols, merge_type="parquet", use_time_range_filter=use_time_range_filter, time_range=time_range)
                else:
                    self.__merge_columns(external_table_name, new_cols, merge_type="parquet")
                t3 = time.perf_counter_ns()
                getLogger().info(f'[{impl} column] upload df: {(t2 -t1)/1000000} ms, merge column: {(t3 -t2)/1000000} ms')
            finally:
                # 清理外表和hdfs数据
                self.conn.real_db.internal_set_quark_mode()
                if hdfs_path != "":
                    self.conn.real_db.run_simple_command(f"dfs -rm -R {hdfs_path}")
                if external_table_name != "":
                    self.conn.real_db.run_simple_command(f"drop table {external_table_name}")

        else:
            # 建对应的临时表
            t1 = time.perf_counter_ns()
            import uuid
            uuid = ''.join(str(uuid.uuid1()).split('-'))
            tmp_table_name = f"temp_table_{uuid}"
            self.conn.real_db.create_temporary_table(tmp_table_name, schema, timecol=timestamp_col, tags=code_cols_str)

            # 把df数据插入到临时表中
            self.conn.real_db.insert(tmp_table_name, right_df, batch=50000, run_mode=QuarkMode)
            t2 = time.perf_counter_ns()

            # 添加新列
            self.__merge_columns(tmp_table_name, new_cols)
            t3 = time.perf_counter_ns()
            getLogger().info(f'[{impl} column] upload df: {(t2 - t1) / 1000000} ms, merge column: {(t3 - t2) / 1000000} ms')

    def __from_unix_time(self, unix_time: int):
        # 将微秒时间戳转换为 Python 的 datetime 对象
        dt = datetime.datetime.fromtimestamp(unix_time / 1000000)
        # 将 datetime 对象格式化为字符串
        str_time = dt.strftime('%Y-%m-%d %H:%M:%S')
        return str_time

    def __getitem__(self, key: str):
        """
        对应DataFrame['列名']的索引操作
        :param key:
        :return:
        """
        if isinstance(key, slice):
            if key.step is not None:
                raise RuntimeError(f"slice {key} not support step parameter")
            if key.start is not None:
                start = key.start
            else:
                start = 0
            if key.stop is not None:
                stop = key.stop
            else:
                stop = sys.maxsize
            if start < 0 or stop < start:
                raise RuntimeError(f"slice {key} only support stop >= start >= 0")
            self.limit_args = [stop - start, start]
            return self
        elif isinstance(key, list):
            assert len(key) > 0
            real_key = []
            for k in key:
                if type(k) is str:
                    if k not in self.user_ref.keys():
                        raise RuntimeError(f"col {k} not found")
                    else:
                        real_key.append(self.user_ref[k])
                else:
                    raise RuntimeError(f"only suppot list[str]")

            sub_cols_df = self.virtual_copy()
            for i in list(sub_cols_df.user_ref.keys()):
                if not i in key:
                    del sub_cols_df.user_ref[i]
            return sub_cols_df
        elif isinstance(key, str) or isinstance(key, ColEval) and key.op == "col":
            if isinstance(key, ColEval) and key.op == "col":
                key = key.name
            if key.find("-") > -1:
                raise ValueError("col name cannot contains -")
            if key in self.user_ref.keys():
                return self.user_ref[key]
            if key in self.schema:
                return ColEval("col", key, self)
            raise RuntimeError(f"col {key} not found")
        else:
            raise RuntimeError(f"{key}: {type(key)} not support")

    def __setitem__(self,
                    key,
                    value):
        if isinstance(key, ColEval) and key.op == "col":
            key = key.name
        assert type(key) == str
        if key.find("-") > -1:
            raise ValueError("col name cannot contains -")

        # 不允许udaf和udf同时计算
        # if self.virtual is False and type(value) is ColEval:
        #     if value.func is not None and value.func in udaf_methods.keys():
        #         raise RuntimeError(f"may not support set {value.func}() value to a column, please use: \n"
        #                            f"{key} = dataframe.virtual_copy()\n"
        #                            f"{key}['{key}'] = {key}...{value.func}()")

        col_id = self.col_counter
        self.col_counter += 1

        real_key = key + "_" + str(col_id)
        if real_key in self.current_all_internal_cols:
            raise RuntimeError(f"duplicate key {real_key}")
        self.user_ref[key] = ColEval("col", real_key, self)
        if isinstance(value, ColEval):
            self.user_ref[key].numeric = value.numeric
        self.user_ref[key].origin_name = key
        new_col = value
        self.current_all_internal_cols[real_key] = new_col

        if real_key not in self.schema:
            self.schema.append(real_key)

    # todo 两张表之间的操作SQL不容易表述
    # def __mul__(self,
    #             other: Union[float, int, ColEval],
    #             ):
    #     """
    #      乘法
    #     :param other:
    #     :return:
    #     """
    #     return self
    #
    # def __rmul__(self, other):
    #     return self.__mul__(other)
    #
    # def __truediv__(self,
    #                 other: Union[float, int, ColEval],
    #                 ):
    #     """
    #     除法
    #     :param other:
    #     :return:
    #     """
    #     return self
    #
    # def __rtruediv__(self, other):
    #     return self.__truediv__(other)
    #
    # def __add__(self,
    #             other: Union[float, int, ColEval],
    #             ):
    #     """
    #     加法
    #     :param other:
    #     :return:
    #     """
    #     return self
    #
    # def __radd__(self, other):
    #     return self.__radd__(other)
    #
    # def __sub__(self,
    #             other: Union[float, int, ColEval],
    #             ):
    #     """
    #     减法
    #     :param other:
    #     :return:
    #     """
    #     return self
    #
    # def __rsub__(self, other):
    #     return self.__sub__(other)

    # udf不支持跟在rollingDataFrame后面
    def _check_and_reject_rolling_dataframe(self, func):
        if type(self) is RollingDataFrame:
            raise RuntimeError(f"do not append {func}() after rolling()")

    # index向udaf支持跟在rollingDataFrame后面（仅限一个）
    def _check_and_set_rolling_dataframe(self, func, args, axis='index'):
        assert axis in [0, 1, 'index', 'columns']
        # 统一输出：无args时不输出[]、None等
        if args is None:
            args = ''
        # True: 符合条件且设置成功
        if type(self) is RollingDataFrame:
            if self.rolling_args is not None:
                # 只有rolling后第一个udaf需要和rolling combine
                if self.rolling_args['method'] is None:
                    # rolling后不可x向聚合
                    if axis in [0, 'index']:
                        self.rolling_args['method'] = f'{func}({args})'
                        return True
                    else:
                        raise RuntimeError(f"rolling().{func}(axis='columns') is illegal")
                else:
                    return False
            else:
                raise RuntimeError(f"generate rollingDataFrame failure")
        else:
            return False

    # 区分x向和y向聚合
    def _select_map_dataframe_by_axis(self, func, args, axis='index'):
        assert axis in [0, 1, 'index', 'columns']
        if axis in [0, 'index']:
            # return MapDataFrame(self.conn, self, f"{func}", args)
            return ColEval("func", f"{func}", self, args)
        else:
            args[0] = 'columns'
            return MapDataFrame(self.conn, self, f"{func}_x", args)

    def gen_select_part(self, prefix_space=0):
        select_str = f"{prefix_space * ' '}select "

        xx_list = []

        for i in self.schema:
            col_name = i
            col_expr = self.current_all_internal_cols[i]
            xx_list.append(f'{generate(col_expr, self)} as `{col_name}`')

        # for k in self.user_ref.keys():
        #     v = self.user_ref[k]
        #     xx_list.append(f'{generate(self.current_all_internal_cols[v], self)} as {v}')

        select_str += ", ".join(xx_list)
        return select_str

    def gen(self, prefix_space=0):
        select_str = self.gen_select_part(prefix_space) + " from " + self.table
        if self.source_filter is not None:
            if isinstance(self.source_filter, str):
                select_str += f" where {self.source_filter} "
            else:
                raise RuntimeError(f"invalid source_filter: {self.source_filter}")
        if self.limit_args is not None:
            if self.limit_args[1] != 0:
                select_str += f" skip {self.limit_args[1]}"
            select_str += f" limit {self.limit_args[0]}"
        return select_str

    def gen_map_sql(self):
        assert len(self.user_ref) > 0
        ur = list(self.user_ref.items())
        select_str = "select"
        select_str += f" {ur[0][1]} as {ur[0][0]}"

        for col in ur[1:]:
            select_str += f", {col[1]} as {col[0]}"

        select_str += f" from (\n{self.gen()}\n)"
        return select_str

    def save_as_table(self, table_name: str, table_type: str = "timelyre", db: str = None, **kwargs):
        assert type(table_name) is str
        if db is None:      # 不指定db时，默认存在当前数据库
            ctas_db = self.conn.real_db.db()
        else:
            ctas_db = db
        if table_type != "timelyre":
            raise RuntimeError(f"save_as_table not support type: {table_type}")
        if self.ctas_enabled == True:
            raise RuntimeError(f"save_as_table can only use once")
        self.ctas_enabled = True
        ctas_table = table_name
        if isinstance(self.conn, Connection) or self.conn.real_db.db() is None:
            ctas_table = f"default.{table_name}"
        else:
            ctas_table = f"{ctas_db}.{table_name}"
        tblProps = []
        for k in kwargs:
            if k == 'wal_status':
                wal_status = kwargs[k]
                tblProps.append(f'"wal.enabled"="{wal_status}"')
            elif k == 'shard_duration':
                shard_duartion = kwargs[k]
                tblProps.append(f'"shard.group.duration.seconds"="{shard_duartion}"')
            elif k == 'retention_period':
                retention_period = kwargs[k]
                tblProps.append(f'"retention.period.seconds"="{retention_period}"')
            elif k == 'rowkey':
                rowkey = kwargs[k]
                tblProps.append(f'"epoch.row.key.cols"="{rowkey}"')
            else:
                tblProps.append(f'"{k}"="{kwargs[k]}"')
        if len(tblProps) > 0:
            props = ', '.join(tblProps)
            self.ctas_str = f"create table {ctas_table} stored as {table_type} tblproperties({props}) as "
        else:
            self.ctas_str = f"create table {ctas_table} stored as {table_type} as "

    def save_as(self, table_name):
        assert type(table_name) is str
        sql = f"create table {table_name} stored as timelyre as\n"
        sql += self.gen_map_sql()
        json_string = self.conn.real_db.run(sql)
        try:
            obj = json.loads(json_string)
            if "error" in obj:
                raise RuntimeError(obj["error"])
        except JSONDecodeError:
            raise RuntimeError(json_string)

    ##todo 修改兼容分布式返回结果
    def __run_sql(self, sql: str):
        res = self.conn.real_db.run(sql)
        if isinstance(res, list):
            try:
                (data, schema, names_from_timelyre) = format_result(res)
                return data, schema, names_from_timelyre
            except JSONDecodeError:
                raise RuntimeError(res)
        else:
            try:
                obj = json.loads(res)
                if "error" in obj:
                    raise RuntimeError(obj["error"])

                (data, schema, names_from_timelyre) = result_data_to_list(obj)
                return data, schema, names_from_timelyre
            except JSONDecodeError:
                raise RuntimeError(res)

    def __result_fetch(self, sqls: list):
        t1 = time.time()
        results = []
        executor = ThreadPoolExecutor(max_workers=20)
        for result in executor.map(self.__run_sql, sqls):
            results.append(result)
        t2 = time.time()
        t = t2 - t1
        return results, t

    def __find_source_dataframe(self):
        if self.parent is None:
            return self
        else:
            return self.parent.__find_source_dataframe()

    def get_aggr_full_col_df(self, c: ColEval):
        """
        将当前DataFrame转变成供全列聚合时使用的DataFrame
        :param c: 进行全列聚合的列
        :return: 全列聚合使用的df
        """
        tag_col = self.__get_tag_col_name()
        aggr_col = c.args[0].name
        aggr_fn = c.func

        self = MapDataFrame(self.conn, self)    # 包一层MapDataFrame

        if aggr_fn == "mean":
            self = self.groupby([tag_col]).aggregate({aggr_col: [ColEval.sum, ColEval.count]})

        elif aggr_fn == "corr":
            col1 = c.args[0].name
            col2 = c.args[1][0].name
            self['xy'] = self[col1] * self[col2]
            self['x2'] = self[col1].pow(2)
            self['y2'] = self[col2].pow(2)

            self = self.groupby(tag_col).aggregate({"xy": [ColEval.sum],
                                                    "x2": [ColEval.sum],
                                                    "y2": [ColEval.sum],
                                                    col1: [ColEval.sum, ColEval.count],
                                                    col2: [ColEval.sum],
                                                    })

        elif aggr_fn == "max":
            self = self.groupby([tag_col]).aggregate({aggr_col: [ColEval.max]})

        elif aggr_fn == "min":
            self = self.groupby([tag_col]).aggregate({aggr_col: [ColEval.min]})

        elif aggr_fn == "count":
            self = self.groupby([tag_col]).aggregate({aggr_col: [ColEval.count]})

        elif aggr_fn == "sum":
            self = self.groupby([tag_col]).aggregate({aggr_col: [ColEval.sum]})

        else:
            raise RuntimeError(f"unsupported aggr full col: {aggr_fn}")
        return self

    def run_aggr_full_col_df(self, c: ColEval):
        """
        进行全列聚合
        :param c: 进行全列聚合的列
        :return: 全列聚合的结果，通常是单值
        """
        aggr_col = c.args[0].name
        aggr_fn = c.func

        df = self.run()

        if aggr_fn == "mean":
            xx = df[f"{aggr_col}_sum"].sum() / df[f"{aggr_col}_count"].sum()
            return xx

        elif aggr_fn == "corr":
            col = c.args[1][0].name
            xx = df.sum()
            molecular = xx['xy_sum'] - xx[f'{aggr_col}_sum'] * xx[f"{col}_sum"] / float(xx[f"{aggr_col}_count"])
            denominator = math.sqrt(
                (xx["x2_sum"] - math.pow(xx[f"{aggr_col}_sum"], 2) / float(xx[f"{aggr_col}_count"])) *
                (xx["y2_sum"] - math.pow(xx[f"{col}_sum"], 2) / float(xx[f"{aggr_col}_count"]))
            )
            xx = molecular / denominator
            return xx

        elif aggr_fn == "max":
            xx = df.max()
            return xx[f"{aggr_col}_max"]

        elif aggr_fn == "min":
            xx = df.min()
            return xx[f"{aggr_col}_min"]

        elif aggr_fn == "count":
            xx = df.sum()
            return xx[f"{aggr_col}_count"]

        elif aggr_fn == "sum":
            xx = df.sum()
            return xx[f"{aggr_col}_sum"]

        else:
            raise RuntimeError(f"unsupported run aggr full col: {aggr_fn}")

    def get_rolling_col_df(self, rc: RollingAggColEval):
        """
        获取进行列rolling的DataFrame
        :param rc: 进行rolling的列
        :return: MapDataFrame
        """
        df = MapDataFrame(self.conn, self)
        df = df.get_rolling_col_df(rc)
        return df

    def gen_final_sql(self):
        sql = self.gen()
        # 这里针对最后用户的列，进行一个裁剪
        # 理论上这个优化可以做在DataFrame里，但是稍微有点麻烦，因为用户用的A列可能依赖一个中间列B(用户不需要)，不能直接只选择A列。
        # 因此这里简单处理下，内部DataFrame还是生成所有内部列，只在最后输出时裁剪成用户列
        select_str = f"select "
        xx_list = []
        user_ref_list = list(self.user_ref)
        for k in user_ref_list:
            v = self.user_ref[k]
            # xx_list.append(f'{generate(self.current_all_internal_cols[v.as_col_name()], self)} as {k}')
            xx_list.append(f'{v.as_col_name()} as `{k}`')
        select_str += ", ".join(xx_list)
        slice_user_ref_sql = select_str + f' from (\n {sql} \n)'
        if self.ctas_enabled == False:
            return slice_user_ref_sql
        else:
            final_sql = self.ctas_str + slice_user_ref_sql
            return final_sql

    """
    saveas的api暂时不支持parallel的模式
    """
    @close_session_finally
    def run(self, use_parallel: bool = False, parallelism: int = 1, generate_mode: bool = False, use_pq: bool = True):
        if self.ctas_str is not None:
            use_pq = False  # save_as_table不走pq传输
        if use_pq:
            self.conn.real_db.run_set_command("set timelyre.use.pq.transfer=true")
        else:
            self.conn.real_db.run_set_command("set timelyre.use.pq.transfer=false")

        time1 = time.time_ns()

        user_ref_list = list(self.user_ref)

        if use_parallel:
            df = self.__find_source_dataframe()
            sqls = []
            for i in range(parallelism):
                df.source_filter = f"partial_tags({i}, {parallelism})"
                sqls.append(self.gen_final_sql())
        else:
            sqls = [self.gen_final_sql()]

        # for sql in sqls:
        #     print(sql)

        run_times = []
        run_times.append(time.perf_counter())

        if use_pq:
            #把TimeQL交由TimeLyre执行
            assert len(sqls) == 1
            df = self.conn.real_db.run(sqls[0], use_pq=use_pq)

        else:
            if not use_parallel:
                #把TimeQL交由TimeLyre执行
                assert len(sqls) == 1
                res = self.conn.real_db.run(sqls[0], use_pq=use_pq)
                run_times.append(time.perf_counter())
                if isinstance(res, list):
                    try:
                        (data, schema, names_from_timelyre) = format_result(res)
                    except JSONDecodeError:
                        raise RuntimeError(res)
                else:
                    try:
                        obj = json.loads(res)
                        if "error" in obj:
                            raise RuntimeError(obj["error"])

                        (data, schema, names_from_timelyre) = result_data_to_list(obj)
                    except JSONDecodeError:
                        raise RuntimeError(res)
            else:
                results, times = self.__result_fetch(sqls)
                run_times.append(time.perf_counter())
                if len(results) == 0:
                    time2 = time.time_ns()
                    getLogger().info(f'df.run costs: {(time2 - time1) / 1000000.0} ms')
                    return pd.DataFrame.empty
                data = []
                schema = None
                names_from_timelyre = None
                for x in results:
                    if len(x[0]) > 0:
                        data.extend(x[0])
                        if schema is None:
                            schema = x[1]
                        if names_from_timelyre is None:
                            names_from_timelyre = x[2]

            df = pd.DataFrame(data, columns=user_ref_list)

        run_times.append(time.perf_counter())

        if df.shape[0] == 0:
            time2 = time.time_ns()
            getLogger().info(f'df.run costs: {(time2 - time1) / 1000000.0} ms')
            return df

        if not use_pq:
            #将所以时间类型用datetime64[ns]表示(此时还是GMT时间)
            for i, x in enumerate(schema):
                if x == TimestampType or x == CastDateType or x == CastMinuteType or x == CastTSType:
                    df[names_from_timelyre[i]] = df[names_from_timelyre[i]].astype(dtype="datetime64[ns]")
                elif x == LongType:
                    #int64不支持NA
                    df[names_from_timelyre[i]] = df[names_from_timelyre[i]].astype(dtype="Int64")
                elif x == VarStringType:
                    df[names_from_timelyre[i]] = df[names_from_timelyre[i]].astype(dtype="string")
                elif x == DoubleType:
                    df[names_from_timelyre[i]] = df[names_from_timelyre[i]].astype(dtype="float64")
                elif x == BoolType:
                    df[names_from_timelyre[i]] = df[names_from_timelyre[i]].astype(dtype="bool")
                elif x == TagType:
                    df[names_from_timelyre[i]] = df[names_from_timelyre[i]].astype(dtype="string")
                else:
                    raise ValueError(f"cannot determine type id {x}")
            run_times.append(time.perf_counter())
            #把内部的GMT时间处理成当前时区的时间
            lz = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
            for (a, b) in df.select_dtypes('datetime64').items():
                if b.dt.tz is None:
                    df[a] = b.dt.tz_localize(datetime.timezone.utc).dt.tz_convert(lz)
            run_times.append(time.perf_counter())

        diffs = [str(run_times[i] - run_times[i - 1]) for i in range(1, len(run_times))]
        if use_pq:
            infos = ["run timeql", "format result", "result process", "timezone process"]
        else:
            infos = ["run timeql"]
        try:
            assert len(diffs) == len(infos)
            msg = [f"{infos[i]}: {diffs[i]}" for i in range(len(diffs))]
            getLogger().info('dfrun time stat:' + ', '.join(msg))
        except Exception:
            getLogger().info('dfrun time stat:' + ', '.join(diffs))
        time2 = time.time_ns()
        getLogger().info(f'df.run costs: {(time2 - time1) / 1000000.0} ms')
        return df

class GroupbyDataFrame(DataFrame):
    def __init__(self, conn, parent, schema, user_ref, gb_cols):
        DataFrame.__init__(self, conn=conn, table="group_by_dataframe", schema=schema, user_ref=user_ref)
        self.parent = parent
        parent.child = self
        self.gb_cols = gb_cols
        self.schema = schema

    def do_transform(self):
        return self

    def resample(self, window: str, on: str, label=''):
        orig_parent = self.parent
        orig_schema = self.schema

        group = re.match(r'([0-9]*)([a-zA-Z]+)', window)
        if group.group(1) == "":
            mult = 1
        else:
            mult = int(group.group(1))

        unit_time = group.group(2)
        if label == '' or label == 'left':
            if unit_time == "H":
                assert mult == 1, "only support H right now"
                orig_parent[on] = orig_parent[on].hour_align()
            elif unit_time == "T":
                orig_parent[on] = orig_parent[on].flexible_minute_align(mult)
            elif unit_time == "S":
                orig_parent[on] = orig_parent[on].flexible_second_align(mult)
            elif unit_time == "D":
                assert mult == 1, "only support D right now"
                orig_parent[on] = orig_parent[on].day_align()
            elif unit_time == "W":
                assert mult == 1, "only support W right now"
                #  W 默认右对齐
                if label == "":
                    orig_parent[on] = orig_parent[on].week_align()
                elif label == "left":
                    orig_parent[on] = orig_parent[on].week_align_left()
            elif unit_time == "MS":
                assert mult == 1, "only support MS right now"
                orig_parent[on] = orig_parent[on].month_align()
            elif unit_time == "QS":
                assert mult == 1, "only support QS right now"
                orig_parent[on] = orig_parent[on].quarter_align()
            elif unit_time == "AS":
                assert mult == 1, "only support AS right now"
                orig_parent[on] = orig_parent[on].year_align()
            else:
                raise RuntimeError(f"unsupported unit_time: {unit_time}")
        elif label == 'right':
            if unit_time == "H":
                assert mult == 1, "only support H right now"
                orig_parent[on] = orig_parent[on].hour_align_right()
            elif unit_time == "T":
                orig_parent[on] = orig_parent[on].flexible_minute_align_right(mult)
            elif unit_time == "S":
                orig_parent[on] = orig_parent[on].flexible_second_align_right(mult)
            elif unit_time == "D":
                assert mult == 1, "only support D right now"
                orig_parent[on] = orig_parent[on].day_align_right()
            elif unit_time == "W":
                assert mult == 1, "only support W right now"
                orig_parent[on] = orig_parent[on].week_align()
            elif unit_time == "MS":
                assert mult == 1, "only support MS right now"
                orig_parent[on] = orig_parent[on].month_align_right()
            elif unit_time == "QS":
                assert mult == 1, "only support QS right now"
                orig_parent[on] = orig_parent[on].quarter_align_right()
            elif unit_time == "AS":
                assert mult == 1, "only support AS right now"
                orig_parent[on] = orig_parent[on].year_align_right()
            else:
                raise RuntimeError(f"unsupported unit_time: {unit_time}")
        else:
            raise RuntimeError(f"unsupported label: {label}")

        self.gb_cols.append(orig_parent.user_ref[on])
        return self

    def aggregate(self, colFuncs: dict):
        old_user_ref_keys = list(self.user_ref.keys())
        self.user_ref.clear()
        self.schema.clear()
        self.current_all_internal_cols.clear()

        for gb_col in self.gb_cols:
            cur_col_name = gb_col.name
            v = cur_col_name.rsplit('_', 1)
            if len(v) == 2 and v[0] in old_user_ref_keys and v[1].isdigit():  # groupby列可能是中间结果，如: datetime_0
                DataFrame.__setitem__(self, v[0], self.parent[cur_col_name])    # 同时确认groupby列 xx_1 是列 xx 的中间结果，而不是本来就叫 xx_1 的一列
            else:
                self.current_all_internal_cols[cur_col_name] = self.parent[cur_col_name]
                self.schema.append(cur_col_name)
                self.user_ref[cur_col_name] = self.parent[cur_col_name]

        for k, v in colFuncs.items():
            if isinstance(k, str):
                if isinstance(v, list):
                    if len(set(v)) == len(v):
                        use_dedup_id = False
                    else:
                        use_dedup_id = True

                    for f in v:
                        if isinstance(f, str):
                            fname = f
                            f = get_func_by_name(f)
                        else:
                            fname = f.__name__

                        if fname not in udaf_methods.keys():
                            raise RuntimeError(f"current func: {fname} is not an aggregate function")
                        if fname in ["value_counts", "cov"]:
                            raise RuntimeError(f"aggregation of the current func: {fname} is not supported temporarily")
                        if use_dedup_id:
                            aggrColName = k + '_' + fname + '_' + str(DataFrame.next_id(self))
                        else:
                            aggrColName = k + '_' + fname
                        DataFrame.__setitem__(self, aggrColName, f(self.parent[k]))
                else:
                    if isinstance(v, str):
                        raise RuntimeError(f"unsupported way to aggr func {v}")
                    aggrColName = k + '_' + v.__name__
                    DataFrame.__setitem__(self, aggrColName, v(self.parent[k]))

            elif isinstance(k, tuple):
                if len(k) != 2:  # 目前多列情况只支持两列聚合
                    raise RuntimeError(f"invalid length of tuple key: {k}")

                if isinstance(v, list):
                    if len(set(v)) == len(v):
                        use_dedup_id = False
                    else:
                        use_dedup_id = True

                    for f in v:
                        if isinstance(f, str):
                            real_func_name = f
                            f = get_func_by_name(f)
                        else:
                            real_func_name = f.__name__.split('_')[0]  # 某些函数会根据类型有不同的版本，如corr

                        if real_func_name not in ["corr", "average"]:
                            raise RuntimeError(f"call func: {real_func_name} invalid")
                        args = [self.parent[col] for col in k]
                        if use_dedup_id:
                            aggrColName = '_'.join(k) + '_' + real_func_name + str(DataFrame.next_id(self))
                        else:
                            aggrColName = '_'.join(k) + '_' + real_func_name
                        DataFrame.__setitem__(self, aggrColName, f(*args))
                else:
                    raise RuntimeError(f"unsupported value type: {type(v)}. key = {k}, value = {v}")

            else:
                raise RuntimeError(f"invalid key type {type(k)}. key = {k}")

        df = MapDataFrame(self.parent.conn, self)
        return df

    def apply(self, function):
        func = 'apply'
        id = str(uuid.uuid1())
        t = self
        while 1:
            if t.parent is None:
                break
            else:
                t = t.parent
        t.conn._register(id, t.table, str(cloudpickle.dumps(function)), "function")
        return MapDataFrame(self.conn, self, f"{func}", make_sql_args([id]))


    def applyAggregation(self, function):
        func_name = "applyGroupByAggregation"
        old_user_ref_keys = list(self.user_ref.keys())
        self.user_ref.clear()
        self.schema.clear()
        self.current_all_internal_cols.clear()

        for gb_col in self.gb_cols:
            v = gb_col.name.rsplit('_', 1)
            if len(v) == 2 and v[0] in old_user_ref_keys and v[1].isdigit():  # groupby列可能是中间结果，如: datetime_0
                DataFrame.__setitem__(self, v[0], self.parent[gb_col])  # 同时确认groupby列 xx_1 是列 xx 的中间结果，而不是本来就叫 xx_1 的一列
            else:
                DataFrame.__setitem__(self, gb_col, self.parent[gb_col])
        id = str(uuid.uuid1())

        layer = self
        while layer.parent is not None:
            layer = layer.parent
            table = layer.table

        self.conn._register(id, table, str(cloudpickle.dumps(function)), "function")
        DataFrame.__setitem__(self, "apply_column",
                              MapDataFrame(self.conn, self.parent, f"{func_name}", make_sql_args([id])), )
        df = MapDataFrame(self.conn, self)
        return df

    agg = aggregate

    def do_transform(self):
        return self

    def get_rolling_col_df(self, rc: RollingAggColEval):
        """
        获取进行列rolling的DataFrame。走到这里就是groupby之后的rolling
        :param rc: 进行rolling的列
        :return: MapDataFrame
        """
        old_user_ref_keys = list(self.user_ref.keys())
        self.user_ref.clear()
        self.schema.clear()
        self.current_all_internal_cols.clear()

        for gb_col in self.gb_cols:
            v = gb_col.name.rsplit('_', 1)
            if len(v) == 2 and v[0] in old_user_ref_keys and v[1].isdigit():  # groupby列可能是中间结果，如: datetime_0
                DataFrame.__setitem__(self, v[0], self.parent[gb_col])          # 同时确认groupby列 xx_1 是列 xx 的中间结果，而不是本来就叫 xx_1 的一列
            else:
                DataFrame.__setitem__(self, gb_col, self.parent[gb_col])

        self.__setitem__(rc.rollingeval.col, rc)

        df = MapDataFrame(self.parent.conn, self)
        return df

    def gen(self, prefix_space=0):
        if isinstance(self.parent, DataFrame):
            if type(self.parent) is not RollingDataFrame:
                tmp = generate(self.gb_cols[0], self)
                for x in self.gb_cols[1:]:
                    tmp += f", {generate(x, self)}"
                select_str1 = self.parent.gen(prefix_space=prefix_space + 2)

                select_str = DataFrame.gen_select_part(self, prefix_space)

                select_str += f" from (\n{select_str1}\n{prefix_space * ' '}) group by {tmp}"

                if self.limit_args is not None:
                    if self.limit_args[1] != 0:
                        select_str += f" skip {self.limit_args[1]}"
                    select_str += f" limit {self.limit_args[0]}"
                return select_str
            else:
                raise RuntimeError(f"do not append groupby() after rolling()")
        else:
            raise RuntimeError(f"only dataframe can use groupby")


class RollingDataFrame(DataFrame):
    def __init__(self, conn, parent, schema, user_ref, rolling_args):
        DataFrame.__init__(self, conn=conn, table="rolling_dataframe", schema=schema, user_ref=user_ref)
        self.parent = parent
        parent.child = self
        self.rolling_args = rolling_args
        self.schema = schema

    def gen(self, prefix_space=0):
        if isinstance(self.parent, DataFrame):
            if type(self.parent) is not RollingDataFrame:
                if self.rolling_args['method'] is not None:
                    func = self.rolling_args['method'].split('(')[0]
                    if func in udaf_methods.keys():
                        select_str1 = self.parent.gen(prefix_space=prefix_space + 2)
                        select_str = f"{prefix_space * ' '}select"

                        # 根据expand_cols扩展*
                        if expand_cols is True:
                            if len(self.parent.user_ref) > 0:
                                ur = list(self.parent.user_ref.values())
                                select_str += f" rolling({ur[0]}, " \
                                              f"{list(self.rolling_args.values())[1:]}).{self.rolling_args['method']}" \
                                              f" as {ur[0]}"
                                for col in ur[1:]:
                                    select_str += f", rolling({col}, " \
                                                  f"{list(self.rolling_args.values())[1:]})." \
                                                  f"{self.rolling_args['method']} as {col}"
                            else:
                                raise RuntimeError(f"get parent user_ref failure when expand * to cols")
                        else:
                            select_str += f" rolling(*, " \
                                          f"{list(self.rolling_args.values())[1:]}).{self.rolling_args['method']}"
                        select_str += f" from (\n{select_str1}\n{prefix_space * ' '})"

                        if self.limit_args is not None:
                            if self.limit_args[1] != 0:
                                select_str += f" skip {self.limit_args[1]}"
                            select_str += f" limit {self.limit_args[0]}"

                        return select_str
                    else:
                        raise RuntimeError(f"rolling() not support append {func}")
                else:
                    raise RuntimeError(f"must append an function after rolling()")
            else:
                raise RuntimeError(f"do not append rolling() after rolling()")
        else:
            raise RuntimeError(f"only dataframe can use rolling")


class MapDataFrame(DataFrame):
    def __init__(self, conn, parent, name="anon", args=None, filter=None):
        col_list = list(parent.current_all_internal_cols.keys())
        ur = parent.user_ref.copy()
        if name == 'anon' or (args is not None and len(args) > 0 and args[0] == 'columns') is False:
            DataFrame.__init__(self, conn=conn, table=name, schema=col_list, user_ref=ur)
        else:
            col_list += [f"{name}_*"]
            # ur = {f"{name}_*": f"{name}_*"}
            ur[f"{name}_*"] = [f"{name}_*"]
            DataFrame.__init__(self, conn=conn, table=name, schema=col_list, user_ref=ur)

        # 目前MapDataFrame的parent都是DataFrame
        self.parent = parent
        parent.child = self
        self.args = args
        if isinstance(filter, str):
            self.df_filter = None
            self.filter_raw = filter
        else:
            self.df_filter = filter
            self.filter_raw = None

    def gen_select_part(self, prefix_space=0):
        assert isinstance(self.parent, DataFrame)

        # 根据expand_cols扩展‘*’，‘*’会被扩展为上层所有的col
        select_str = f"{prefix_space * ' '}select"

        select_str = DataFrame.gen_select_part(self, prefix_space)

        ur = list(self.user_ref.values())
        if self.args is not None and len(self.args) > 0 and self.args[0] == 'columns':
            select_str += f" {self.table}({ur}"
            if self.args is not None:
                select_str += f", {self.args}"
            select_str += f") as {self.table}_*"

        if self.table != 'anon':
            select_str += f" {self.table}({ur[0]}"
            if self.args is not None:
                select_str += f", {self.args}"
            select_str += f") as {ur[0]}"
            for col in ur[1:]:
                select_str += f", {self.table}({col}"
                if self.args is not None:
                    select_str += f", {self.args}"
                select_str += f") as {col}"

        return select_str

    def gen(self, prefix_space=0):
        # self.table == 'anon'时，说明是匿名MapDataFrame
        if self.table == 'anon':
            select_str = self.gen_select_part(prefix_space)
        # self.table != 'anon'时,说明是主动生成的MapDataFrame，对应对整个df的操作，每个操作翻译成一层select
        elif self.table in udf_methods.keys() or self.table in udaf_methods.keys():
            select_str = self.gen_select_part(prefix_space)
        # todo 预留给两张表join操作：__sub__等
        else:
            raise RuntimeError(f"not support two dataframe join operator yet 1")

        select_str += " from (\n" + self.parent.gen(prefix_space + 2)

        # self.table == 'anon'时，说明是匿名MapDataFrame，limit应该是属于parent的
        if self.table == 'anon':
            if self.limit_args is not None:
                if self.limit_args[1] != 0:
                    select_str += f" skip {self.limit_args[1]}"
                select_str += f" limit {self.limit_args[0]}"
            select_str += "\n" + prefix_space * ' ' + ")"
        # self.table != 'anon'时,说明是主动生成的MapDataFrame，limit属于自己
        # 对整表的操作
        elif self.table in udf_methods.keys() or self.table in udaf_methods.keys():
            select_str += "\n" + prefix_space * ' ' + ")"
            if self.limit_args is not None:
                # 判断是否可以切片
                if self.table in udf_methods.keys():
                    if self.limit_args[1] != 0:
                        select_str += f" skip {self.limit_args[1]}"
                    select_str += f" limit {self.limit_args[0]}"
                else:
                    raise RuntimeError(f"not support get slice after {self.table}()")
        # todo 预留给两张表join操作：__sub__等
        else:
            raise RuntimeError(f"not support two dataframe join operator yet 2")

        if self.df_filter is not None:
            expr = generate(self.df_filter, self)
            if "isin(" in expr:
                raise RuntimeError(f"unsupported filter expr with isin: {expr}")  # 带有in操作的filter语句不能走到这里，必须下推
            ret_str = select_str + " where " + expr
        elif self.filter_raw is not None:
            ret_str = select_str + " where " + self.filter_raw
        else:
            ret_str = select_str

        return ret_str

    def gen2(self):
        assert isinstance(self.parent, DataFrame)

        tmp = f"{self.table}("
        if expand_cols is False:
            tmp += f"*"
        else:
            exclude_col = ''
            for k, v in self.parent.current_all_internal_cols.items():
                if v is self:
                    exclude_col = k

            col_list = list(self.user_ref.values())
            if exclude_col in col_list:
                col_list.remove(exclude_col)
            for k in range(0, len(col_list)):
                if k == len(col_list) - 1:
                    tmp += str(col_list[k].as_col_name())
                else:
                    tmp += str(col_list[k].as_col_name()) + ","
            # tmp += str(col_list)
        if self.args is not None and len(self.args) > 0:
            tmp += f", {self.args})"
        else:
            tmp += f")"
        return tmp

    def get_rolling_col_df(self, rc: RollingAggColEval):
        """
        获取进行列rolling的DataFrame
        :param rc: 进行rolling的列
        :return: MapDataFrame
        """
        self.user_ref.clear()
        self.schema.clear()
        self.current_all_internal_cols.clear()

        self.__setitem__(rc.rollingeval.col, rc)
        df = MapDataFrame(self.parent.conn, self)
        return df
import time
import json
from dataclasses import dataclass
from json import JSONDecodeError
import requests
import pandas as pd
from typing import *
from concurrent.futures import ThreadPoolExecutor
from itertools import repeat
from threading import Thread, Lock
from enum import Enum

from .constants import timelyre_type_to_sql_type

@dataclass
class SimpleConnInfo:
    tc_addr: str
    jdbc_addr: str
    hdfs_nn_addrs: str
    user: str
    pwd: str
    token: str = ""
    db: str = "default"
    realm: str = None
    keytab_path: str = None
    real_ui_host_port: str = None

class Connection:
    def __init__(self, host, quark_http_port, single_timelyre_http_address=None, should_log=True,
                 start_id=0, skipRealConOp=False):
        self.__req_id = start_id
        self.host = host
        self.port = quark_http_port
        self.should_log = should_log
        self.lock = Lock()
        self.single_timelyre_http_address = single_timelyre_http_address
        if not skipRealConOp:
            self.__query_raw("set timelyre.sql.enabled=true")
            self.__query_raw("set timelyre.local.server.enabled=true")
            self.__query_raw("set timelyre.timeql.direct.return=true")
            if single_timelyre_http_address is not None:
                self.single_timelyre_http_address = single_timelyre_http_address
                self.__query_raw(f"set timelyre.local.server.http.address={single_timelyre_http_address}")

    def __deepcopy__(self, memodict={}):
        return Connection(self.host, self.port, single_timelyre_http_address=self.single_timelyre_http_address,
                          start_id=self.__req_id, skipRealConOp=True)

    def query_raw(self, q: str):
        self.__query_raw(q)

    def __query_raw(self, q: str):

        curQueryId = -1
        self.lock.acquire()
        self.__req_id += 1
        curQueryId = self.__req_id
        self.lock.release()

        if self.should_log:
            if len(q) >= 30:
                print(f"query [{curQueryId}] {q[:30]}... starts", flush=True)
            else:
                print(f"query [{curQueryId}] {q} starts", flush=True)

        st = time.time_ns()
        # import requests.packages.urllib3.util.connection as urllib3_cn
        # requests.packages.urllib3.util.connection.HAS_IPV6 = True

        res = requests.post(url="http://" + self.host + ":" + str(self.port) + f"/test?id={self.__req_id}", data=q.encode("utf-8"))
        nd = time.time_ns()
        if self.should_log:
            print(f"query [{curQueryId}] costs: {(nd - st)/1000000.0} ms", flush=True)
        return res

    def run(self, sql):
        res = self.__query_raw(sql)
        return res.text

    def drop_table(self, tblName: str):
        #当前没有实现，但为了可以像DatabaseConn一样drop+create连续调用，这里有个fake
        pass

    def create_table(self, tblName: str, tblType: str, schema: list, otherProps={}, **kwargs):
        """
        创建一张表
        :param tblName: 表名
        :param tblType: 表的类型，当前支持timelyre时序表和普通的orc表
        :param schema: 指定表的列名和对应类型
        :param kwargs: 如果创建timelyre时序表, 必须指定timecol的时间戳列，可选指定tags列(1列或多列，多个列名用逗号隔开)
        :return:
        """
        if tblType == 'timelyre':
            tags = None
            timecol = None
            needUniqCols = False
            tblProps = []
            for k in kwargs:
                if k == 'tags':
                    tags = kwargs[k]
                    tblProps.append(f'"timelyre.tag.cols"="{tags}"')
                if k == 'timecol':
                    timecol = kwargs[k]
                    tblProps.append(f'"timelyre.timestamp.col"="{timecol}"')
                if k == 'uniqcols':
                    uniqCols = kwargs[k]
                    tblProps.append(f'"epoch.engine.enabled"="true"')
                    tblProps.append(f'"epoch.row.key.cols"="{uniqCols}"')
                if k == "wal":
                    enabled = kwargs[k]
                    tblProps.append(f'"wal.enabled"="{str(enabled).lower()}"')
            if len(otherProps) != 0:
                for k, v in otherProps.items():
                    tblProps.append(f'"{k}"="{v}"')

            assert tags is not None and timecol is not None, "create timelyre table without time and tag"
            if schema is None or len(schema) <= 0:
                raise RuntimeError(f"create timelyre table without schema")
            if isinstance(schema[0][1], str):
                colWithTypes = [f"`{x[0]}` {x[1]}" for x in schema]
            elif isinstance(schema[0][1], Enum):
                colWithTypes = [f"`{x[0]}` {x[1].value}" for x in schema]
            else:
                raise RuntimeError(f"invalid schema type: {type(schema)}, schema: {schema}")
            schemaSpec = ",".join(colWithTypes)

            props = ', '.join(tblProps)
            query = f'create table {tblName}({schemaSpec}) stored as {tblType} tblproperties({props})'
            res = self.__query_raw(query)
            if res.text == '':
                return
            else:
                raise RuntimeError(res.text)
        else:
            raise ValueError('tblType can only be orc or timelyre')

    def __insert(self, table, values):
        if len(values) == 0:
            return
        all_rows = []
        row_len = len(values[0])
        for row in values:
            for i in range(row_len):
                if (self.__is_null(row[i])):
                    row[i] = "null"
            row2 = ['\'' + str(x) + '\'' for x in row]
            row_values = '(' + ','.join(row2) + ')'
            all_rows.append(row_values)
        all_data = ','.join(all_rows)
        q = f'insert into {table} values {all_data}'
        res = self.__query_raw(q)
        if res.text == '':
            return res
        else:
            raise RuntimeError(res.text)

    def __is_null(self, value):
        pdna = pd.isna(value)
        if pdna:
            return pdna
        if isinstance(value, str):
            if value == "":
                return True
            else:
                lowerval = value.lower()
                if lowerval == "" or lowerval == "na" or lowerval == "none" or lowerval == "nan" or lowerval == "null":
                    return True
                else:
                    return False
        else:
            return False

    def insert(self, table, values: Union[pd.DataFrame, list], batch: int = 500, parallelism: int = 1):
        """
        向指定表插入数据
        :param table: 表名
        :param values: 插入的数据，支持DataFrame或者list数据的形式
        :param batch: 内部插入数据每批的大小，默认500行一次插入
        :param parallelism: 进行数据插入的线程数
        :return:
        """
        
        if parallelism > 1:
            executor = ThreadPoolExecutor(max_workers=parallelism)
            if isinstance(values, list):
                rowcount = len(values)
                ROW_BATCH: int = batch
                batches = [values[i * ROW_BATCH: (i + 1) * ROW_BATCH] for i in range(0, int(rowcount / ROW_BATCH) + 1)]
            elif isinstance(values, pd.DataFrame):
                rowcount = values.shape[0]
                ROW_BATCH: int = batch
                batches = [values.loc[i * ROW_BATCH: (i + 1) * ROW_BATCH - 1].values.tolist() for i in range(0, int(rowcount / ROW_BATCH) + 1)]
            else:
                raise TypeError("unsupported values type: ", type(values))

            t1 = time.time_ns()
            results = []
            for result in executor.map(self.__insert, repeat(table), batches):
                results.append(1)
            t2 = time.time_ns()
            print(f"insert total cost {(t2 - t1) / 1000000.0} ms")
            return

        if isinstance(values, list):
            rowcount = len(values)
            ROW_BATCH: int = batch
            for i in range(0, int(rowcount / ROW_BATCH) + 1):
                rows = values[i * ROW_BATCH: (i + 1) * ROW_BATCH]   # list[:]：左闭右开
                self.__insert(table, rows)

        elif isinstance(values, pd.DataFrame):
            rowcount = values.shape[0]
            ROW_BATCH: int = batch
            for i in range(0, int(rowcount / ROW_BATCH) + 1):
                rows = values.loc[i * ROW_BATCH: (i + 1) * ROW_BATCH - 1].values.tolist()   # pd.loc[:]：左闭右闭
                self.__insert(table, rows)
        else:
            raise TypeError("unsupported values type: ", type(values))

    def _register(self, func_id, table_name, func_body, package):
        if package == 'package':
            q = f"{table_name}##register_package#{func_id}##{func_body}"
        elif package == 'function':
            q = f"{table_name}##register#_({func_id})_##{func_body}"
        elif package == 'file':
            q = f"{table_name}##register_file#{func_id}##{func_body}"
        else:
            raise ValueError(f"package type not support ")
        self.__query_raw(q)

    def get_info_from_opt(self, key: str, opt: dict) -> list:
        if key not in opt.keys():
            return []
        info = opt[key].split(",")
        info = [] if len(info) == 1 and info[0] == "" else info
        return info

    def get_table_info(self, tblName: str) -> dict:
        """
        获取表信息，包括tag列、timestamp列、schema、schema数据类型等
        :param tblName: 表名
        :return: dict
        """
        if self.single_timelyre_http_address is None:
            raise RuntimeError("connection lack of timelyre http address")
        url = "http://" + self.single_timelyre_http_address + f"/api/timelyre/tables?name={tblName}"
        if self.should_log:
            print(f"\nget {url} starts", flush=True)

        st = time.time_ns()
        data = requests.get(url=url)
        nd = time.time_ns()
        if self.should_log:
            print(f"get costs: {(nd - st) / 1000000.0} ms", flush=True)

        res = {}
        try:
            obj = json.loads(data.text)
            opt = obj["tables"][0]["opt"]
            if "error" in obj:
                raise RuntimeError(obj["error"])
            tag_cols = self.get_info_from_opt("timelyre.tag.cols", opt)
            ts_cols = self.get_info_from_opt("timelyre.timestamp.col", opt)
            user_ts_cols = self.get_info_from_opt("user.timestamp.col", opt)
            schema = self.get_info_from_opt("schema", opt)
            data_types = self.get_info_from_opt("data.types", opt)

            if len(schema) != len(data_types):
                raise RuntimeError(f"schema_names len: {len(schema)} and schema_types len: {len(data_types)} not equal")
            for i in range(len(data_types)):
                data_types[i] = timelyre_type_to_sql_type(schema[i], data_types[i], user_ts_cols)

            res["tag_cols"] = tag_cols
            res["ts_cols"] = ts_cols
            res["user_ts_cols"] = user_ts_cols
            res["schema"] = schema
            res["data_types"] = data_types

        except JSONDecodeError:
            raise RuntimeError(data.text)

        return res
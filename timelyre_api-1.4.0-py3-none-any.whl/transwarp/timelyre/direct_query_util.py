import re
from typing import List
import traceback
from datetime import datetime
from transwarp.timelyre.timelyre_logger import getLogger

class DirectQueryUtil:
    @staticmethod
    def is_direct_query_enabled(query, tag_col, time_col):
        try:
            getLogger().debug(f'is_direct_query_enabled, query: {query}')
            query = query.replace('`', '').strip()
            # 1. 含子句或含部分关键词，则不支持:
            keyword_patterns = [r'\s+from\s+\(', r'\s+order\s+by\s+', r'\s+group\s+by\s+', r'\s+limit\s+', r'\s+or\s+',
                                r'\s+join\s+']
            keywords = [re.sub(r'[\\s+]', '', pattern) for pattern in keyword_patterns]
            pattern = '|'.join(keyword_patterns)
            matches = re.findall(pattern, query, flags=re.IGNORECASE)
            if matches:
                for match in matches:
                    if match.replace(' ', '').lower() in keywords:
                        return None

            # 2. 匹配select子句，from子句，where子句（可选）
            pattern = r'select\s+(.+?)\s+from\s+(\S+)(?:\s+where\s+(.+))?$'
            match = re.match(pattern, query, flags=re.IGNORECASE)
            if not match:
                # print("not a valid select sql")
                return None

            table_name, cols, tag_value_list, time_filter = None, None, None, None

            def get_timestamp(date_str):
                date_format = "%Y-%m-%d %H:%M:%S.%f" if '.' in date_str else "%Y-%m-%d %H:%M:%S"
                return datetime.strptime(date_str, date_format)

            def check_is_valid_str(str):
                if str is None or str == '':
                    return False
                if str[0] == str[-1] and (str[0] == '"' or str[0] == "'"):
                    return True
                return False

            if match.group(3) is not None:
                # 按and切分where子句
                sub_conds = re.split(r'\s+and\s+', match.group(3).strip())
                # print('sub_conds', sub_conds)
                # 对子句挨个检查
                for cond in sub_conds:
                    col = cond.split(' ', 1)[0]
                    # 不接受非tag、time列相关子句
                    if col not in [tag_col, time_col]:
                        return None
                    # 从tag列子句解析tag_value_list
                    if col == tag_col:
                        if tag_value_list is not None:
                            getLogger().debug('already have tag_col cond')
                            return None
                        pattern = r'\s+in\s*\(([^)]+)\)'  # 匹配 in (xx,xx)
                        match1 = re.search(pattern, cond)
                        pattern = r'\s*==\s*([^)]+)'  # 匹配 == xx
                        match2 = re.search(pattern, cond)
                        if match1:
                            values = match1.group(1).split(',')
                            values = [v.strip() for v in values]
                            for v in values:
                                if not check_is_valid_str(v):
                                    return None
                            values = [re.sub(r'\"|\'', '', v) for v in values]  # 去除多余的单双引号
                            tag_value_list = values
                        elif match2:
                            value = match2.group(1).strip()
                            if not check_is_valid_str(value):
                                # print("值不对")
                                return None
                            value = re.sub(r'\"|\'', '', match2.group(1).strip())
                            tag_value_list = [value]
                        else:
                            getLogger().debug('tag_col cond but is not in or ==')
                            return None

                    # 从time列子句解析time_filter
                    if col == time_col:
                        if time_filter is None: time_filter = [None, None]

                        pattern = r'\s*>=\s*([^)]+)'  # 匹配 >= xx
                        match1 = re.search(pattern, cond)
                        pattern = r'\s*<=\s*([^)]+)'  # 匹配 <= xx
                        match2 = re.search(pattern, cond)
                        if match1:
                            value = re.sub(r'|\"|\'', '', match1.group(1).strip())
                            if time_filter[0] is None or get_timestamp(value) > get_timestamp(time_filter[0]):
                                time_filter[0] = value
                        elif match2:
                            value = re.sub(r'|\"|\'', '', match2.group(1).strip())
                            if time_filter[1] is None or get_timestamp(value) < get_timestamp(time_filter[1]):
                                time_filter[1] = value
                        else:
                            return None
            # 提取列名和表名，并去除多余空格
            if match.group(1) == '' or match.group(1) is None:
                # print("not a valid select sql, no select col")
                return None
            columns = match.group(1).strip().split(",")
            cols = []
            for col in columns:
                col = col.strip()
                # 选择的列带有函数或者as都不支持
                if len(col.split(' ')) != 1:
                    return None
                if '(' in col:
                    return None
                cols.append(col)
            if cols == ['*']:  cols = None

            if match.group(2) == '' or match.group(2) is None:
                # print("not a valid select sql, no from")
                return None
            from_clause = re.sub(r'\s+', '', match.group(2).strip())  # 识别结果可能为:db.tbl 或者 tbl
            values = from_clause.split('.')
            if len(values) > 2:
                return None
            elif len(values) == 2:
                db_name, table_name = values
            else:
                db_name = ""
                table_name = values[0]

            # print('table_name:', table_name)
            # print('cols:', cols)
            # print('tag_value_list:', tag_value_list)
            # print('time_filter:', time_filter)
            return DirectQueryInfo(db_name=db_name, table_name=table_name, cols=cols, tag_value_list=tag_value_list, time_filter=time_filter)
        except Exception as e:
            getLogger().error(f"failed to analyze, error: {e}, details:\n{traceback.format_exc()}")
            return None

    @staticmethod
    def paras_to_query(table_name: str, cols: List[str], tag_value_list: List[str], time_filter: List[str]):
        # 如果不是timelyre表，会尝试拼成一个sql，默认的tag列名为"code", 时间戳列名为"datetime"
        select_cols = ",".join(cols) if cols and len(cols) > 0 else "*"
        filter_str = []
        if tag_value_list and len(tag_value_list) > 0:
            filter_str.append("code in (" + ",".join([f"'{x}'" for x in tag_value_list]) + ")")
        ts_str = []
        if time_filter and len(time_filter) > 0:
            lower_bound = time_filter[0]
            upper_bound = time_filter[1]
            if lower_bound and len(lower_bound) > 0:
                ts_str.append(f" datetime >= '{lower_bound}'")
            if upper_bound and len(upper_bound) > 0:
                ts_str.append(f" datetime <= '{upper_bound}'")
        if len(ts_str) > 0:
            filter_str.append(" and ".join(ts_str))
        final_sql = f"select {select_cols} from {table_name}"
        if len(filter_str) > 0:
            final_sql += (" where " + " and ".join(filter_str))
        return final_sql


class DirectQueryInfo:
    def __init__(self, db_name: str, table_name: str,
                 cols: List[str] = None, tag_value_list: List[str] = None, time_filter: List[str] = None):
        self.db_name = db_name
        self.table_name = table_name
        self.cols = cols
        self.tag_value_list = tag_value_list
        self.time_filter = time_filter

if __name__  == "__main__":
    tag_col = 'code'
    time_col = 'datetime'
    # query = 'select * from test_table where code in ("xx", "yy") and datetime >= "2020-01-01 00:00:00"'
    # query = 'insert into db.tbl'
    query = 'select * from where code in ("xx")'
    query = 'select * from where'
    info = DirectQueryUtil.is_direct_query_enabled(query, tag_col, time_col)
    print(query)
    if info is not None:
        print(info.cols)
        print(info.tag_value_list)
        print(info.time_filter)
    else:
        print("cannot direct query")

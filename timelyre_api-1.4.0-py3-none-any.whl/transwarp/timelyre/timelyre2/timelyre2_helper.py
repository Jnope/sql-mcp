from transwarp.timelyre.database import Database
import datetime


def task_prune_enabled(db: Database, tblName) -> bool:
    props = db.show_properties(tblName)
    is_fast_csv = props.get("timelyre.fast.csv.import.table")
    if is_fast_csv is not None and is_fast_csv == "true":
        return False
    return True


def dataframe_timestamp_transform(df):
    lz = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
    for col in df.select_dtypes(include=['datetime64', 'datetime64[ns, Asia/Shanghai]']).columns:
        # 如果列没有时区信息，先本地化为 UTC
        if df[col].dt.tz is None:
            df[col] = df[col].dt.tz_localize(datetime.timezone.utc)
        # 转换为目标时区
        df[col] = df[col].dt.tz_convert(lz)

    return df

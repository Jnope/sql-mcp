import os
import re
import sys

from transwarp.timelyre.dfs.DFSClient import init_krb, NameNodeInfo
from hdfs import InsecureClient, TokenClient
from hdfs.ext.kerberos import KerberosClient
import pwd

_DEFAULT_REALM_PATTERN = "default_realm\s*=\s*([^\s]+)"
def _get_current_user() -> str:
    username = os.environ.get("username", None)
    if username is None:
        user_info = pwd.getpwuid(os.getuid())
        username = user_info.pw_name
    return username

def _get_current_keytab_path() -> str:
    keytab = os.environ.get("KEY_TAB", None)
    return keytab

def _get_krb5_config_file_path() -> str:
    return os.environ.get("KRB5_CONFIG", None)

def  _get_user_realm(user: str) -> str:
    krb5_config_path = _get_krb5_config_file_path()


    def_realm = None
    with open(krb5_config_path) as f:
        for x in f.readlines():
            m = re.search(_DEFAULT_REALM_PATTERN, x)
            if m:
                def_realm = m.group(1)
                break
    assert def_realm is not None, "default realm is not present in config file."

    realm = user + "@" + def_realm
    return realm

def get_hdfs_client(nn_web_addrs: str,
                    client_use_krb: bool = None,
                    client_user: str = None,
                    client_realm: str = None,
                    client_keytab_path: str = None,
                    session = None,
                    ):
    active_nn_web = None
    hdfs_use_krb = None
    for u in nn_web_addrs.split(";"):
        nni = NameNodeInfo(u)
        if nni.is_active_nn():
            active_nn_web = u
            hdfs_use_krb = nni.is_security_on()
            break
    if active_nn_web is None:
        raise RuntimeError(f"cannot find active namenode in {nn_web_addrs.split(';')}")

    use_krb_conn = None
    if hdfs_use_krb is None:
        if client_use_krb is None:
            raise RuntimeError("HDFS security cannot be determined, please manually specify client_use_krb")
        else:
            use_krb_conn = client_use_krb
    if hdfs_use_krb is not None:
        if client_use_krb is None:
            use_krb_conn = hdfs_use_krb
        else:
            if hdfs_use_krb != client_use_krb:
                raise RuntimeError(f"HDFS security is {hdfs_use_krb}, while client_use_krb is {client_use_krb}, please unset it or set it to value '{hdfs_use_krb}'")
            else:
                use_krb_conn = hdfs_use_krb

    http_active_nn = f"http://{active_nn_web}"
    print(f"Active NN: {http_active_nn}, Use KRB for connection: {use_krb_conn}")

    user = _get_current_user() if client_user is None else client_user
    if use_krb_conn:
        realm = _get_user_realm(user) if client_realm is None else client_realm
        keytab_path = _get_current_keytab_path() if client_keytab_path is None else client_keytab_path
        init_krb(realm, keytab_path)
        c = KerberosClient(url=http_active_nn, principal=realm, session=session)
    else:
        c = InsecureClient(url=http_active_nn, user=user)
    return c


if __name__ == "__main__":
    nn_webs = sys.argv[1]
    if len(sys.argv) > 2:
        test_path = sys.argv[2]
    else:
        test_path = "/test_hdfs"
    c = get_hdfs_client(nn_webs)
    print(c.list("/"))
    c.makedirs(test_path)
    c.write(f"{test_path}/test.data", data=b"123456789")
    x = c.list(test_path)
    assert x == ["test.data"]
    with c.read(f"{test_path}/test.data") as reader:
        data = reader.read()
    assert data == b"123456789"
    c.delete(test_path, recursive=True)
    print("simple test passed...")

import threading

import requests
from hdfs import InsecureClient
from transwarp.time_utils import str_to_datetime
from transwarp.timelyre.timelyre_logger import getLogger

def parse_from_klist(config, output):
    from krbticket import KrbTicket, KrbConfig, KrbCommand
    if not output:
        return KrbTicket.get_instance(config=config)

    lines = output.splitlines()
    file = lines[0].split(':')[2]
    principal = lines[1].split(':')[1].strip()
    starting, expires, service_principal = lines[4].strip().split('  ')
    if len(lines) > 5:
        renew_expires = lines[5].strip().replace('renew until ', '')
    else:
        renew_expires = None

    def parseDatetime(str):
        if str:
            return str_to_datetime(str)

    return KrbTicket.get_instance(
        config=config,
        file=file,
        principal=principal,
        starting=parseDatetime(starting),
        expires=parseDatetime(expires),
        service_principal=service_principal,
        renew_expires=parseDatetime(renew_expires))

_init_lock = threading.Lock()
_has_initted = False
def init_krb(realm, keytab):
    global _has_initted
    with _init_lock:
        if _has_initted:
            return
        else:
            from krbticket import KrbTicket
            #XXX(LTY): 因为KrbTicket自带的没法解析其它格式的日期字符串形式，因子使用自定义的parse
            KrbTicket.parse_from_klist = parse_from_klist
            ticket = KrbTicket.init(realm, keytab)
            # config = KrbConfig(principal=realm, keytab=keytab)
            # ticket = parse_from_klist(config, KrbCommand.klist(config))
            ticket.updater_start()
            _has_initted = True

def is_active_nn(url):
    real_url = f"http://{url}/jmx"
    # print(f"Check {real_url} for active state.")

    data = requests.get(real_url).json()
    for x in data["beans"]:
        if x.get("name", None) == 'Hadoop:service=NameNode,name=NameNodeStatus':
            return x["State"] == "active"
    return False

class NameNodeInfo:
    def __init__(self, url: str):
        if url.startswith("http://"):
            real_url = url
        else:
            real_url = f"http://{url}/jmx"

        # print(f"Check {real_url} for active state.")
        data = requests.get(real_url).json()
        self.jmx_data = data

    def is_active_nn(self):
        data = self.jmx_data
        for x in data["beans"]:
            if x.get("name", None) == 'Hadoop:service=NameNode,name=NameNodeStatus':
                return x["State"] == "active"
        return False

    def is_security_on(self):
        data = self.jmx_data
        for x in data["beans"]:
            if x.get("name", None) == 'Hadoop:service=NameNode,name=NameNodeStatus':
                return x["SecurityEnabled"]
        return None

class DFSClient:
    def __init__(self, nn_web_addrs: str, use_krb: bool, realm=None, keytab=None, non_krb_default_user: str = "hive"):
        active_nn_web = None
        for u in nn_web_addrs.split(";"):
            if is_active_nn(u):
                active_nn_web = u
                break
        if active_nn_web is None:
            raise RuntimeError(f"cannot find active namenode in {nn_web_addrs.split(';')}")

        http_active_nn = f"http://{active_nn_web}"
        self.http_active_nn = http_active_nn

        # print(f"Active NN: {http_active_nn}")

        if use_krb:
            from hdfs.ext.kerberos import KerberosClient
            init_krb(realm, keytab)
            c = KerberosClient(url=http_active_nn, principal=realm)
        else:
            c = InsecureClient(url=http_active_nn, user=non_krb_default_user)
        self._client = c

    def _normlize_path(self, _hdfs_path):
        if _hdfs_path.startswith("hdfs://"):
            hdfs_path = _hdfs_path[len("hdfs://"):]
            hdfs_path = hdfs_path[hdfs_path.find("/"):]
        else:
            hdfs_path = _hdfs_path
        return hdfs_path

    def list(self, path):
        path = self._normlize_path(path)
        return self._client.list(path)

    def mkdir(self, path):
        self._client.makedirs(path)

    def rmdir(self, path, recursive: bool=False, skip_trash:bool=False):
        self._client.delete(path, recursive=recursive, skip_trash=skip_trash)

    def get(self, _hdfs_path: str, local_dir: str):
        hdfs_path = self._normlize_path(_hdfs_path)
        c = self._client
        # st = c.status("/lty")
        ret = c.download(hdfs_path=hdfs_path, local_path=local_dir, n_threads=2)
        getLogger().info(dir)
        return ret

    def put(self, _hdfs_path: str, local_file: str):
        _hdfs_path = self._normlize_path(_hdfs_path)
        with open(local_file, "rb") as f:
            data = f.read()
            self._client.write(_hdfs_path, data)
        return

    def remove(self, _hdfs_path: str, recursive: bool):
        _hdfs_path = self._normlize_path(_hdfs_path)
        return self._client.delete(hdfs_path=_hdfs_path, recursive=recursive)





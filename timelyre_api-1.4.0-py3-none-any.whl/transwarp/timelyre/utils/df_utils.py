import datetime

import pandas as pd

pd.set_option('mode.chained_assignment', None)


def combine_two_time_dataframe(sdf1, df2, tc):
    a = df2[tc].min()
    b = df2[tc].max()
    filtered_df = sdf1[(sdf1[tc] < a) | (sdf1[tc] > b)]
    final_df = pd.concat([filtered_df, df2], ignore_index=True)
    ret_df = final_df.sort_values(by=tc, ignore_index=True)
    return ret_df


def df_localize_time(df):
    # 获得本地时区信息
    local_time_zone = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
    for (a, b) in df.select_dtypes('datetime64').items():
        # 如果时间戳列不带时区信息，那么认为这个时间戳是UTC时间，然后将这个时间戳转换成本地时区的时间戳
        if b.dt.tz is None:
            df[a] = b.dt.tz_localize(datetime.timezone.utc).dt.tz_convert(local_time_zone)


def df_normalize_time(df):
    for (a, b) in df.select_dtypes('datetimetz').items():
        # df[a] = b.dt.tz_convert(datetime.timezone.utc).dt.tz_localize(None)
        df[a] = df[a].dt.tz_convert(datetime.timezone.utc)
        df[a] = df[a].dt.tz_localize(None)
        # df[a] = df[a].dt.tz_localize(None)
    return df


def slice_timed_df(df, tcol, st, nd, ignore_index: bool = True):
    lz = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
    if ignore_index:
        return df[(df[tcol] >= pd.to_datetime(st).tz_localize(lz)) & (
                    df[tcol] < pd.to_datetime(nd).tz_localize(lz))].reset_index(drop=True)
    else:
        return df[(df[tcol] >= pd.to_datetime(st).tz_localize(lz)) & (df[tcol] < pd.to_datetime(nd).tz_localize(lz))]


def dt_to_pd_local_dt(dt: datetime.date):
    lz = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
    return pd.to_datetime(dt).tz_localize(lz)

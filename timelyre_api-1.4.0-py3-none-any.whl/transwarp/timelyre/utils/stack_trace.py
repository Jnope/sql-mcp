import traceback
import threading
import time
import sys

def dumpstacks(signal, frame, logger):
    id2name = dict([(th.ident, th.name) for th in threading.enumerate()])
    code = []
    for threadId, stack in sys._current_frames().items():
        code.append("\n# Thread: %s(%d)" % (id2name.get(threadId, ""), threadId))
        for filename, lineno, name, line in traceback.extract_stack(stack):
            code.append('File: "%s", line %d, in %s' % (filename, lineno, name))
            if line:
                code.append("  %s" % (line.strip()))
    logger("\n".join(code))
    logger("------------------------- END STACK TRACE ----------------------")


def loop_stack_trace(nsec: int, logger):
    while True:
        dumpstacks(None, None, logger)
        time.sleep(nsec)


def start_background_stacktrace(nsec: int = 3, logger = print):
    t = threading.Thread(target=loop_stack_trace, args=(nsec, logger, ))
    t.name = "background_stacktrace_daemon"
    t.daemon = True
    t.start()


if __name__ == "__main__":
    start_background_stacktrace(nsec=3, logger=print)
    time.sleep(10)
    print("Finish")

def bind_methods(cls, method_modules):
    for module in method_modules:
        for name in dir(module):
            method = getattr(module, name)
            if callable(method):
                setattr(cls, name, method)

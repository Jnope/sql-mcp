import io
import math
import os
from concurrent.futures.thread import ThreadPoolExecutor
from itertools import repeat

import pandas as pd

from transwarp.timelyre.quark import QuarkTempDirMgr


# 单个dataframe写成parquet文件，返回文件名
def write_to_parquet(file_name: str, batch_df: pd.DataFrame, compression="snappy"):
    batch_df.to_parquet(file_name, compression=compression, engine="pyarrow", use_deprecated_int96_timestamps=True)
    return file_name


# 单个dataframe写成parquet bytes，返回bytes对象
def write_to_parquet_bytes(batch_df: pd.DataFrame, compression="snappy"):
    buffer = io.BytesIO()
    batch_df.to_parquet(buffer, compression=compression, engine="pyarrow", use_deprecated_int96_timestamps=True)
    buffer.seek(0)
    return buffer.getvalue()


def make_tempdir_if_needed(id: str):
    tmp_dir = f"/tmp/timelyre-py-temp/{id}"
    os.makedirs(tmp_dir, exist_ok=True)
    return tmp_dir


# 将单个dataframe生成parquet bytes，然后把这个bytes送往远程的quark server
def single_send_df_to_remote_server(batch_df: pd.DataFrame, filename: str,
                                    host_port: str, token: str, remote_dir_id: str,
                                    compression="snappy"):
    parquet_bytes = write_to_parquet_bytes(batch_df, compression)
    mgr = QuarkTempDirMgr(host_port, token)
    res = mgr.putFileBytesInTempDir(remote_dir_id, filename, parquet_bytes)
    return res


# 将一个大的dataframe并行地根据batch_size切分，生成parquet bytes，然后把这个bytes送往远程的quark server
def parallel_send_to_remote_server(df: pd.DataFrame,
                                   host_port: str, token: str, remote_dir_id: str,
                                   table_type: str, uid: str, batch_size: int = 200000, max_worker_num=20):
    if table_type != "parquet":
        raise RuntimeError(f"parallel_write only supported table type: parquet, now table type: {table_type}")
    executor = ThreadPoolExecutor(max_workers=max_worker_num)
    batches = []
    responses = []
    file_names = []
    num_batches = math.ceil(len(df) / batch_size)
    for i in range(num_batches):
        start_idx = i * batch_size
        end_idx = min(start_idx + batch_size, len(df))
        batch_df = df.iloc[start_idx:end_idx]
        batches.append(batch_df)
        file_name = f"{uid}-{i}"
        file_names.append(file_name)
    for result in executor.map(single_send_df_to_remote_server, batches, file_names,
                               repeat(host_port), repeat(token), repeat(remote_dir_id)):
        responses.append(result)
    for response in responses:
        if response.status_code != 200:
            raise RuntimeError(f"[parallel_send_to_remote_server] request failed, status code {response.status_code}")
    return file_names


# 将一个大的dataframe并行地根据batch_size切分，生成N个本地parquet文件，返回目录和文件列表
def parallel_write_to_parquet(df: pd.DataFrame,
                              table_type: str, uid: str, batch_size: int = 200000, max_worker_num=20):
    if table_type != "parquet":
        raise RuntimeError(f"parallel_write only supported table type: parquet, now table type: {table_type}")
    executor = ThreadPoolExecutor(max_workers=max_worker_num)
    batches = []
    files = []
    res = []
    dir = make_tempdir_if_needed(uid)
    num_batches = math.ceil(len(df) / batch_size)
    for i in range(num_batches):
        file_path = f"{dir}/{uid}-{i}"
        start_idx = i * batch_size
        end_idx = min(start_idx + batch_size, len(df))
        batch_df = df.iloc[start_idx:end_idx]
        files.append(file_path)
        batches.append(batch_df)
    for result in executor.map(write_to_parquet, files, batches):
        res.append(result)
    return dir, res


def df_to_local_file(df: pd.DataFrame, table_type: str, uid: str, batch_size: int = 200000,
                     compression="snappy"):
    batch_num = int(len(df) / batch_size) + 1
    dir = make_tempdir_if_needed(uid)
    res = []
    for i in range(0, batch_num):
        file_path = f"{dir}/{uid}-{i}"
        if table_type == "parquet":
            # 一定要指定engine为pyarrow，否则quark读取会出错
            df[i * batch_size: (i + 1) * batch_size].to_parquet(file_path, compression=compression,
                                                                engine="pyarrow",
                                                                use_deprecated_int96_timestamps=True)
        elif table_type == "csv":
            df[i * batch_size: (i + 1) * batch_size].to_csv(file_path)
        res.append(file_path)
    return dir, res

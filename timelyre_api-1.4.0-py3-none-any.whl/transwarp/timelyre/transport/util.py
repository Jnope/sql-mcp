import numpy as np


# 不使用python自带的hash，需要用和java一样的算法
def get_hash(string):
    hash_code = 0
    for char in string:
        hash_code = (31 * hash_code + ord(char)) & 0xFFFFFFFF
    return np.int32(hash_code)


def make_shiva_pk(tag_keys, tag_values):
    pks = []
    if len(tag_keys) == 1:
        for v in tag_values:
            pk_str = f'{tag_keys[0]}={v}'
            pks.append((v, pk_str))
    else:
        for v in tag_values:
            pk_str = ','.join([f"{tag}={v[idx]}" for idx, tag in enumerate(tag_keys)])
            pks.append((v, pk_str))
    return pks


def make_shiva_pk_for_timelyre2(tag_keys, tag_values):
    # timelyre2中只使用tag value的值
    pks = []
    if len(tag_keys) == 1:
        return [[v, v] for v in tag_values]
    else:
        for tags in tag_values:
            pks.append([tags, ','.join([str(tag) for tag in tags])])
    return pks

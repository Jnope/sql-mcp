from transwarp import time_utils
from transwarp.timelyre.meta.table_distribution import BucketInfo, TabletInfo


class ReadRequest:
    def __init__(self,
                 bucket: BucketInfo,
                 tablet: TabletInfo,
                 cols,
                 tag_key,
                 tag_value_list=None,
                 time_filter=None,
                 chunk_size=100000,
                 vec_read=True,
                 use_arrow_transfer=True,
                 compress="none"
                 ):
        if time_filter is None:
            time_filter = []
        if tag_value_list is None:
            tag_value_list = []
        self.tablet = tablet
        self.http_addr = bucket.http_addr
        self.bucket_name = bucket.bucket_name
        self.cols = cols
        self.tag_key = tag_key
        self.tag_value_list = tag_value_list
        self.time_filter = time_filter
        self.chunk_size = chunk_size
        self.vec_read = vec_read
        self.arrow_transfer = use_arrow_transfer
        self.compress = compress

    def get_bucket_info(self):
        return f"bucket name: {self.bucket_name} http: {self.http_addr}"

    def make_col_str(self):
        return "|".join(self.cols)


    def make_tag_list_str(self):
        filter_str = ""
        tags = self.tag_key.split(',')
        if len(tags) == 1:
            if len(self.tag_value_list) > 0:
                tag_string = "('{}')".format("', '".join(self.tag_value_list))
                filter_str += f"({self.tag_key} in {tag_string})"
        else:
            filters = []
            for tag_values in self.tag_value_list:
                filters.append("(" + " and ".join([f"{v}='{tag_values[i]}'" for i, v in enumerate(tags)]) + ")")
            if len(filters) > 0:
                filter_str = "(" + ' or '.join(filters) + ")"
        return filter_str

    def make_time_filter_str(self):
        ts_string = ""
        if len(self.time_filter) > 0:
            if self.time_filter[0] is not None and self.time_filter[0] != "":
                ts_string += f"time >= {time_utils.str_to_nano(self.time_filter[0])}"
            if len(self.time_filter) > 1 and self.time_filter[1] is not None and self.time_filter[1] != "":
                if ts_string != "":
                    ts_string += " and "
                ts_string += f"time <= {time_utils.str_to_nano(self.time_filter[1])}"
        return ts_string

    def make_filter_str(self):
        filter_str = ""
        tag_str = self.make_tag_list_str()
        if tag_str != "":
            filter_str += tag_str
        time_str = self.make_time_filter_str()
        if time_str != "":
            if filter_str != "":
                filter_str += " and "
            filter_str += time_str
        return filter_str

    def make_simple_query(self):
        filter_str = self.make_filter_str()
        cols_str = self.make_col_str()
        if filter_str != "":
            simple_query = f"@ | {filter_str}\n{cols_str}"
        else:
            simple_query = cols_str
        xy_options = []
        if self.arrow_transfer:
            xy_options.append("useArrowTransfer")
        simple_query += f"\n#confmap# needColumnPrune=true"
        if len(xy_options) > 0:
            simple_query += f";xyOptions={','.join(xy_options)}"

        return simple_query

    def make_url(self):
        url = f"/api/timelyre/query/simple?" \
              f"chunked=true" \
              f"&pq_chunk_size={self.chunk_size}" \
              f"&tbl={self.bucket_name}" \
              f"&use_pq_transfer=true" \
              f"&arrow_compression_type={self.compress}"
        return url

    # 为重试构造下一个read request
    def make_next_bucket_read_request(self):
        if self.tablet is None:
            return None
        bucket = self.tablet.get_next_bucket_info()
        if bucket is None:
            return bucket
        return ReadRequest(bucket=bucket,
                           tablet=self.tablet,
                           cols=self.cols,
                           tag_key=self.tag_key,
                           tag_value_list=self.tag_value_list,
                           time_filter=self.time_filter,
                           chunk_size=self.chunk_size,
                           vec_read=self.vec_read,
                           use_arrow_transfer=self.arrow_transfer)

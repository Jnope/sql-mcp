from requests.auth import HTTPBasicAuth

from transwarp.timelyre.meta.table_distribution import TableDistribution
from transwarp.timelyre.meta.tag_distribution import TagDistribution
from transwarp.timelyre.meta.timelyre2_tag_distribution import TimeLyre2TagDistribution
from transwarp.timelyre.meta.timelyre_schema import TimeLyreSchema
from transwarp.timelyre.transport import util
import json
import requests


class TimeLyreClient:
    def __init__(self, shiva_web_addr):
        self.__shiva_web_addr = shiva_web_addr

    def get_schema_from_shiva(self, table_name):
        """ 获取一张shiva表的schema
        """

        url = f'http://{self.__shiva_web_addr}/table/description?database=default&table_name={table_name}'
        response = requests.get(url, auth=HTTPBasicAuth("shiva", "shiva"))
        response_data = response.text
        json_data = json.loads(response_data)
        try:
            prop_list = json_data['table_description']['properties']['custom_properties']
        except Exception as e:
            raise RuntimeError(f'{e}, json_data={json_data}')
        schema = TimeLyreSchema.from_shiva_prop(prop_list)
        return schema

    def get_table_distribution(self, table_name, leader_only=False, is_timelyre2=False):
        """ 获取一张表的数据分布
        """
        if is_timelyre2:
            api = "timelyre2BucketTalkerListByName"
        else:
            api = "timelyreBucketTalkerListByName"

        url = f"http://{self.__shiva_web_addr}/api/shiva/table/{api}?" \
              f"table_name={table_name}&leader_only={leader_only}"
        response = requests.get(url, auth=HTTPBasicAuth("shiva", "shiva"))
        response_data = response.text
        json_data = json.loads(response_data)
        try:
            table_json = json_data['tables'][0]
        except KeyError:
            raise RuntimeError(f"shiva table {table_name} does not exist")
        table = TableDistribution.from_json(table_json, is_timelyre2)
        #print(f"table: {table_name}, json_data: {json_data}")
        return table

    def get_tag_distribution(self, table_name, tag_value_list):
        """ 获取一张表中，一些tag值的数据分布
        """
        schema = self.get_schema_from_shiva(table_name)
        table_distribution = self.get_table_distribution(table_name)
        pk_strs = util.make_shiva_pk(schema.tag_keys, tag_value_list)
        pk_set = set()
        tag_value_map = {}  # tag value -> pk的映射
        for v in pk_strs:
            tag_value = v[0]
            pk_str = v[1]
            pk = util.get_hash(pk_str)
            pk_set.add(pk)
            tag_value_map[tag_value] = pk
        para_str = ",".join(str(pk) for pk in pk_set)

        url = f'http://{self.__shiva_web_addr}/api/shiva/table/timelyreBucketTalkerListByPkOpt?' \
              f'table_name={table_name}&primary_key={para_str}'
        response = requests.get(url, auth=HTTPBasicAuth("shiva", "shiva"))
        response_data = response.text
        if "URI Too Long" in response_data:
            if tag_value_list is not None:
                raise ValueError(f"too much tags in one request, tag num: {len(tag_value_list)}")
            else:
                raise RuntimeError(f"URI too log, but tag_value_list is None, url: {url}")
        json_data = json.loads(response_data)
        # 拿到的是pk -> tablet id的映射
        pk_map = {}
        try:
            for v in json_data['entrys']:
                pk_map[v['primary_key']] = v['tablet_id']
        except Exception as e:
            raise RuntimeError(f"{e}, json_data={json_data}")
        #print(f"tag: {tag_value_list} json: {json_data}")
        return TagDistribution(schema, tag_value_map, pk_map, table_distribution)

    def get_tag_distribution_for_timelyre2(self, table_name, tag_value_list, tag_cols):
        table_distribution = self.get_table_distribution(table_name, is_timelyre2=True)
        pk_strs = util.make_shiva_pk_for_timelyre2(tag_cols, tag_value_list)
        pk_set = set()
        tag_value_map = {}  # tag value -> pk的映射
        for v in pk_strs:
            tag_value = v[0]
            pk_str = v[1] + "\t"
            pk = util.get_hash(pk_str)
            pk_set.add(pk)
            tag_value_map[tag_value] = pk
        para_str = ",".join(str(pk) for pk in pk_set)

        url = f'http://{self.__shiva_web_addr}/api/shiva/table/timelyre2BucketTalkerListByPkOpt?' \
              f'table_name={table_name}&primary_key={para_str}'
        response = requests.get(url, auth=HTTPBasicAuth("shiva", "shiva"))
        response_data = response.text
        if "URI Too Long" in response_data:
            if tag_value_list is not None:
                raise ValueError(f"too much tags in one request, tag num: {len(tag_value_list)}")
            else:
                raise RuntimeError(f"URI too log, but tag_value_list is None, url: {url}")
        json_data = json.loads(response_data)
        # 拿到的是pk -> tablet id的映射
        pk_map = {}

        try:
            for v in json_data['entrys']:
                pk_map[v['primary_key']] = v['tablet_id']
        except Exception as e:
            raise RuntimeError(f"{e}, json_data={json_data}")
        #print(f"tag: {tag_value_list} json: {json_data}")
        return TimeLyre2TagDistribution(tag_value_map, pk_map, table_distribution)

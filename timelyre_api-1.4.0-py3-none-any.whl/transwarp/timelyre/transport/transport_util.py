import io
import json
import struct
import datetime
import pandas as pd
import pyarrow as pa
from transwarp.timelyre.constants import TimestampType, CastTSType, CastMinuteType, CastDateType
from transwarp.timelyre.transport import compress

MAGIC_STR = "_TIMELYRE_"
ERROR_STR = "_TIMERROR_"
MAGIC_STR_BYTES = b"_TIMELYRE_"


# 用小端法读取一个long值
def read_long_re(response):
    b = response.read(8)
    if len(b) == 0:
        return 0
    return struct.unpack('<Q', b)[0]


def read_string(response, length):
    b = response.read(length)
    return b.decode('utf-8')


# 处理http response，返回一个dataframe
def process_response(response, use_arrow_ipc, compress_type, ret_raw_bytes: bool=False):
    schema_obj = None
    pq_bytes_len = read_long_re(response)
    if pq_bytes_len == 0:
        return schema_obj, None
    #print("pq_bytes_len", pq_bytes_len)
    # 尝试读magic字符串
    magic_str_b = response.read(len(MAGIC_STR_BYTES))
    if len(magic_str_b) == 0:
        raise ValueError("No Magic string found")
    magic_str = magic_str_b.decode('utf-8')
    # 读取到error
    if magic_str == ERROR_STR:
        length = read_long_re(response)
        err = read_string(response, length)
        raise ValueError(f"got error from storage: {err}")
    if magic_str != MAGIC_STR:
        raise ValueError("Magic string check error")
    schema_len = read_long_re(response)
    if schema_len < 0:
        raise ValueError(f"invalid schema bytes len {schema_len}")
    if schema_len > 0:
        schema_bytes = response.read(schema_len)
        schema_str = schema_bytes.decode('utf-8')
        schema_obj = json.loads(schema_str)
    data_bytes = response.read(pq_bytes_len)
    data_bytes = compress.handle_decompress(data_bytes, compress_type)
    x = io.BytesIO(data_bytes)
    if ret_raw_bytes:
        return schema_obj, x.getvalue()
    if use_arrow_ipc:
        table = pa.ipc.open_stream(x).read_all()
        df = table.to_pandas()
    else:
        df = pd.read_parquet(x)
    return schema_obj, df


def dataframe_timestamp_transform(df, col_types):
    for i in range(len(col_types)):
        tp = col_types[i]
        if tp in [TimestampType, CastTSType, CastMinuteType, CastDateType]:
            col = df.columns[i]
            df[col] = df[col].dt.tz_localize(None)
    lz = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
    for (a, b) in df.select_dtypes('datetime64').items():
        if b.dt.tz is None:
            df[a] = b.dt.tz_localize(datetime.timezone.utc).dt.tz_convert(lz)

import io
import threading
import time
import queue

from transwarp.timelyre.meta.table_distribution import BucketInfo
from transwarp.timelyre.transport.read_request_builder import ReadRequestBuilder
from transwarp.timelyre.transport.timelyre_client import TimeLyreClient
from transwarp.timelyre.transport.timelyre_transport import TimeLyreTransporter


def read_timelyre_data_fast(talker_addr: str, bucket_name: str, cols: list, tag_key: str, tag_list: list, time_range: list):
    http_addr = talker_addr
    table_name = bucket_name
    bucket = BucketInfo(table_name, http_addr)
    timestamp_filter = time_range
    req3 = (ReadRequestBuilder(bucket)
            .with_cols(cols)
            .with_chunk_size(5000)
            .with_tag_key(tag_key)
            .with_tag_value_list(tag_list)
            .with_time_filter(timestamp_filter)
            .build())
    gen = TimeLyreTransporter.read_bytes(read_request=req3)
    return gen

class BytesDataIterator:
    def __init__(self, *args, **kwargs):
        # self.gen = read_timelyre_data_fast(*args, **kwargs)
        self.finish = False
        self.next_data = None

    def init(self, *args, **kwargs):
        print('init with args', args, 'kwargs', kwargs)
        self.gen = read_timelyre_data_fast(*args, **kwargs)

    def has_next(self):
        if self.finish:
            return False
        else:
            try:
                self.next_data = next(self.gen)
                return True
            except StopIteration:
                self.finish = True
                return False

    def next(self):
        ret = self.next_data[1]
        self.next_data = None
        return ret


class _END_BLOCK: pass
END_BLOCK = _END_BLOCK()
class MultiBytesDataIterator:
    def __init__(self):
        self.threads = []
        self.qs: list[queue.Queue] = []
        self.finish: list[bool] = []
        self.current_data: list = []
        self.timeout = 30
        pass

    def do_work(self, q: queue.Queue, *args, **kwargs):
        iterator = BytesDataIterator()
        iterator.init(*args, **kwargs)
        while iterator.has_next():
            block = iterator.next()
            print(f'put block {len(block)}')
            q.put(block)
        print(f'put end')
        q.put(END_BLOCK)
    def init(self, codes: list, addresses: list, buckets: list, *args, **kwargs):
        for i in range(len(codes)):
            code = codes[i]
            http_addr = addresses[i]
            bucket_name = buckets[i]
            q = queue.Queue()
            t = threading.Thread(target=self.do_work, args=(q, *args, ),
                                 kwargs={**kwargs, 'tag_list': [code], 'talker_addr': http_addr, 'bucket_name': bucket_name})
            self.finish.append(False)
            self.current_data.append(None)
            self.threads.append(t)
            self.qs.append(q)

        for t in self.threads:
            t.start()
    def has_next(self, code_idx: int):
        print(f'code {code_idx} call has next')
        if self.finish[code_idx]:
            return False
        else:
            obj = self.qs[code_idx].get(timeout=self.timeout)
            if obj is END_BLOCK:
                self.finish[code_idx] = True
                return False
            else:
                self.current_data[code_idx] = obj
                return True

    def next(self, code_idx: int):
        print(f'code {code_idx} call next')
        ret = self.current_data[code_idx]
        self.current_data[code_idx] = None
        print(f'code {code_idx} got next len {len(ret)}')
        return ret

if __name__ == '__main__':
    cols = []
    for x in range(5):
        cols.append(f'ask_price_{x + 1}')
    for x in range(5):
        cols.append(f'ask_volume_{x + 1}')
    for x in range(5):
        cols.append(f'bid_price_{x + 1}')
    for x in range(5):
        cols.append(f'bid_volume_{x + 1}')
    cols.extend(['last_price', 'turnover', 'update_time', 'volume', 'code', 'datetime', 'trade_day'])

    def foo(talker_addr, bucket_name, code):
        print(f'Requesting {talker_addr} {bucket_name} {code}')
        t1 = time.time()

        iterator = BytesDataIterator()
        iterator.init(talker_addr=talker_addr,
                                bucket_name=bucket_name,
                                cols=cols,
                                tag_key="code",
                                tag_list=[code],
                                time_range=["2024-03-28 09:00:16.000000", "2024-03-28 09:30:17.0000"],)

        while iterator.has_next():
            print(f'{code} got arrow block with len', len(iterator.next()))

        t2 = time.time()
        print(t2 - t1)

    client = TimeLyreClient('tq-dev-node2:4567')
    code_list = ['RM2405.ZCE', 'FG2405.ZCE', 'SA2405.ZCE', 'SA2409.ZCE']
    ret = client.get_tag_distribution('meta_data.futures_lv2_data_new', code_list)

    if False:
        threads = []
        for x in code_list:
            d = ret.get_tag_value_location(x)
            t = threading.Thread(target=foo, args=(d.http_addr, d.bucket_name, x))
            threads.append(t)
            print(ret.get_tag_value_location(x))
        for x in threads:
            x.start()
        for x in threads:
            x.join()
    else:
        mbd_iter = MultiBytesDataIterator()
        addresses = [ret.get_tag_value_location(x).http_addr for x in code_list]
        buckets = [ret.get_tag_value_location(x).bucket_name for x in code_list]
        mbd_iter.init(code_list, addresses, buckets, cols=cols, tag_key='code', time_range=["2024-03-28 09:00:16.000000", "2024-03-28 09:09:17.0000"],)

        t1 = time.time()
        has_any = True
        while has_any:
            has_any = False
            for x in range(len(code_list)):
                if mbd_iter.has_next(x):
                    block = mbd_iter.next(x)
                    print(f'code {code_list[x]} got block {len(block)}')
                    has_any = True
                else:
                    print(f'code {code_list[x]} finish got block')

        t2 = time.time()
        print('Finish', t2 - t1, 'seconds')
from transwarp.timelyre.meta.table_distribution import TabletInfo, TimeLyre2BucketInfo

BUCKET_NAME = "__BUCKET_NAME__"


class TimeLyre2ReadRequest:
    def __init__(self,
                 bucket: TimeLyre2BucketInfo,
                 tablet: TabletInfo,
                 query,
                 cols,
                 tag_key,
                 ts_col_name,
                 tag_value_list,
                 time_filter,
                 limit,
                 fmt: str,
                 compression: str,
                 use_final: bool,
                 username: str,
                 password: str):
        if time_filter is None:
            time_filter = []
        if tag_value_list is None:
            tag_value_list = []
        self.query = query
        self.tablet = tablet
        self.host = bucket.host
        self.http_port = bucket.http_port
        self.bucket_name = bucket.bucket_name
        self.cols = cols
        self.tag_key = tag_key
        self.tag_value_list = tag_value_list
        self.ts_col_name = ts_col_name
        self.time_filter = time_filter
        self.limit = limit
        self.fmt = fmt
        self.compression = compression
        self.use_final = use_final
        self.username = username
        self.password = password

    def make_tag_list_str(self):
        filter_str = ""
        tags = self.tag_key.split(',')
        if len(tags) == 1:
            if len(self.tag_value_list) > 0:
                tag_string = "('{}')".format("', '".join(self.tag_value_list))
                filter_str += f"({self.tag_key} in {tag_string})"
        else:
            if len(self.tag_value_list) > 0:
                tag_string = "({})".format(",".join([str(v) for v in self.tag_value_list]))
                filter_str += f"({self.tag_key}) in {tag_string}"
        return filter_str

    def make_time_filter_str(self):
        ts_string = ""
        if len(self.time_filter) > 0:
            if self.time_filter[0] is not None and self.time_filter[0] != "":
                ts_string += f"{self.ts_col_name} >= '{self.time_filter[0]}'"
            if len(self.time_filter) > 1 and self.time_filter[1] is not None and self.time_filter[1] != "":
                if ts_string != "":
                    ts_string += " and "
                ts_string += f"{self.ts_col_name} <= '{self.time_filter[1]}'"
        return ts_string

    def make_predicate_str(self):
        filter_str = ""
        tag_str = self.make_tag_list_str()
        if tag_str != "":
            filter_str += tag_str
        time_str = self.make_time_filter_str()
        if time_str != "":
            if filter_str != "":
                filter_str += " and "
            filter_str += time_str
        return filter_str

    def make_query(self):
        if self.query is not None:
            query = self.query.replcae(BUCKET_NAME, self.bucket_name)
            return query
        else:
            cols_str = ",".join(self.cols)
            predicate_str = self.make_predicate_str()
            query = f"select {cols_str} from {self.bucket_name}"
            if self.use_final:
                query += " FINAL"
            if predicate_str != "":
                query += f" where {predicate_str}"

            if self.limit is not None:
                query += f" limit {self.limit}"
            return query

    def make_next_bucket_read_request(self):
        if self.tablet is None:
            return None
        bucket = self.tablet.get_next_bucket_info()
        if bucket is None:
            return bucket
        return TimeLyre2ReadRequest(bucket=bucket,
                                    tablet=self.tablet,
                                    query=self.query,
                                    cols=self.cols,
                                    tag_key=self.tag_key,
                                    ts_col_name=self.ts_col_name,
                                    tag_value_list=self.tag_value_list,
                                    time_filter=self.time_filter,
                                    limit=self.limit,
                                    fmt=self.fmt,
                                    compression=self.compression,
                                    use_final=self.use_final,
                                    username=self.username,
                                    password=self.password)

from typing import List, Optional

from .constants import JoinType, CruxMode
from .database import Database
from .timelyre_logger import set_logger_file_output
import pandas as pd


def set_logger(log_to_file: bool):
    set_logger_file_output(log_to_file)


def close_session_finally(func):
    """
    装饰器，装饰的函数会在finally模块中关闭session，防止连接泄漏
    """

    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            raise e
        finally:
            if hasattr(args[0], 'close_connection') and hasattr(args[0], 'auto_close'):
                if args[0].auto_close:
                    args[0].close_connection()

    return wrapper


# 区别是重复close不会报错
def close_session_finally2(func):
    """
    装饰器，装饰的函数会在finally模块中关闭session，防止连接泄漏
    """

    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            raise e
        finally:
            if hasattr(args[0], 'close_connection') and hasattr(args[0], 'auto_close'):
                if args[0].auto_close:
                    args[0].close_connection(raise_error_if_double_close=False)

    return wrapper


class DatabaseConn:
    def __init__(self, jdbc_http_proxy: str,
                 real_conn: str,
                 db: str = "default",
                 run_mode: str = "crux",
                 compressSQL: bool = False,
                 auth_type: str = "simple",
                 query_default_use_cache: bool = False,
                 query_cache_ttl: int = 60 * 60 * 1000,  # 1个小时
                 kafka_servers: str = "",
                 kafka_zk_address: str = "",
                 run_tdc: bool = False,
                 tdc_quark_ui_port: str = None,
                 session_timeout: int = 5 * 60 * 1000,  # 5min
                 login_timeout: int = 5 * 60 * 1000,  # 5min
                 auto_close: bool = True,
                 disable_cancel: bool = False,
                 real_ui_host_port: str = None,  # for quark fast meta manager
                 real_leopard_url: str = None,  # for tdc leopard environment
                 **kwargs):
        self.real_db = Database(jdbc_http_proxy, real_conn, db, auth_type, run_mode, compressCommand=compressSQL,
                                kafka_servers=kafka_servers, kafka_zk_address=kafka_zk_address,
                                run_tdc=run_tdc, tdc_quark_ui_port=tdc_quark_ui_port, session_timeout=session_timeout,
                                login_timeout=login_timeout, auto_close=auto_close, disable_cancel=disable_cancel,
                                real_ui_host_port=real_ui_host_port, real_leopard_url=real_leopard_url,
                                **kwargs)
        self.query_use_cache = query_default_use_cache
        self.query_cache_ttl = query_cache_ttl
        self.auto_close = auto_close
        return

    def run_simple_command(self, query: str) -> list:
        return self.real_db.run_simple_command(query)

    @DeprecationWarning
    def run_register_command(self, query: str):
        return self.real_db.run_register_command(query)

    def run_set_command(self, cmd: str):
        return self.real_db.run_set_command(cmd)

    def set_crux_mode(self):
        return self.real_db.internal_set_crux_mode()

    def set_quark_mode(self):
        return self.real_db.internal_set_quark_mode()

    def set_session_name(self, sn, basic=False):
        return self.real_db.set_session_name(sn, basic)

    def set_convert_decimal_to_float64(self, flag: bool):
        self.real_db.set_convert_decimal_to_float64(flag)

    def set_process_result_null_dtype(self, flag: bool):
        self.real_db.set_process_result_null_dtype(flag)

    def get_convert_decimal_to_float64(self):
        return self.real_db.get_convert_decimal_to_float64()

    def get_process_result_null_dtype(self):
        return self.real_db.get_process_result_null_dtype()

    def show_session_state(self) -> list:
        return self.real_db.show_session_state()

    def close_inactive_sessions(self, period: int) -> list:
        return self.real_db.close_inactive_sessions(period)

    @close_session_finally
    def show_databases(self) -> list:
        return self.real_db.show_databases()

    @close_session_finally
    def show_tables(self, **kwargs) -> list:
        return self.real_db.show_tables(**kwargs)

    @close_session_finally
    def show_columns(self, tblName: str, **kwargs) -> list:
        return self.real_db.show_columns(tblName, **kwargs)

    @close_session_finally
    def show_properties(self, tblName: str, **kwargs) -> dict:
        return self.real_db.show_properties(tblName, **kwargs)

    @close_session_finally
    def show_table_type(self, tblName: str, **kwargs):
        return self.real_db.show_table_type(tblName, **kwargs)

    @close_session_finally
    def create_database(self, dbName: str):
        return self.real_db.create_database(dbName)

    @close_session_finally
    def create_table(self, tblName: str, tblType: str, schema: list, **kwargs):
        return self.real_db.create_table(tblName, tblType, schema, **kwargs)

    @close_session_finally
    def create_temporary_table(self, tblName: str, schema: list, **kwargs):
        return self.real_db.create_temporary_table(tblName, schema, **kwargs)

    # only used for test, set shard group duration to default value
    @close_session_finally
    def create_table_for_test(self, tblName: str, tblType: str, schema: list, **kwargs):
        return self.real_db.create_table(tblName, tblType, schema, shard_group_duration="604800", **kwargs)

    @close_session_finally
    def create_simple_table(self, tblName: str, tblType: str, schema: list, **kwargs):
        return self.real_db.create_table(tblName, tblType, schema, True, **kwargs)

    @close_session_finally
    def create_simple_table_for_test(self, tblName: str, tblType: str, schema: list, **kwargs):
        return self.real_db.create_table(tblName, tblType, schema, True, shard_group_duration="604800", **kwargs)

    @close_session_finally
    def drop_database(self, dbName: str, forceDrop: bool = False):
        return self.real_db.drop_database(dbName, forceDrop)

    @close_session_finally
    def drop_table(self, tblName: str, **kwargs):
        return self.real_db.drop_table(tblName, **kwargs)

    @close_session_finally
    def truncate_table(self, tblName: str, **kwargs):
        return self.real_db.truncate_table(tblName, **kwargs)

    @close_session_finally
    def clear_mapping_table(self, tblName: str):
        return self.real_db.clear_mapping_table(tblName)

    @close_session_finally
    def clear_tmp_table(self, concurrency=10, **kwargs):
        return self.real_db.clear_tmp_table(concurrency, **kwargs)

    @close_session_finally
    def clear_upload_df_tbl(self, tblName: str):
        """
        清理指定的由upload_df生成的临时表
        :param tblName: 表名
        """
        return self.real_db.clear_upload_df_tbl(tblName)

    @close_session_finally
    def clear_all_upload_df_tbl(self, concurrency=10):
        """
        并发清理所有由upload_df生成的临时表，即以temp_df_table开头的表
        :param concurrency: 并发数
        :return: 表总量，成功清理的数量
        """
        return self.real_db.clear_all_upload_df_tbl(concurrency)

    @close_session_finally
    def query_as_df(self, tbl: str,
                    query: str = None,
                    select_cols: str = None,
                    condition: str = None,
                    combine_ignore_index: bool = True,
                    time_range_hint: str = "",
                    use_cache: bool = None,
                    cache_ttl: int = None,
                    use_local_write: bool = False,
                    pq_file_size: int = 2000000,
                    query_timeout: int = 180,
                    local_dir: str = None,
                    cols: List[str] = None,
                    tag_value_list: List[str] = None,
                    time_filter: List[str] = None,
                    direct_query_enabled: bool = True,
                    auto_direct_check: bool = True,
                    use_meta_cache: bool = False,
                    **kwargs
                    ):
        if use_cache is None:
            thisQueryUseCache = self.query_use_cache
        else:
            thisQueryUseCache = use_cache
        if cache_ttl is None:
            thisCacheTTL = self.query_cache_ttl
        else:
            thisCacheTTL = cache_ttl
        return self.real_db.query_as_df(tbl=tbl,
                                        query=query,
                                        select_cols=select_cols,
                                        condition=condition,
                                        combine_ignore_index=combine_ignore_index,
                                        order_by_range=time_range_hint,
                                        use_cache=thisQueryUseCache,
                                        cache_ttl=thisCacheTTL,
                                        use_local_write=use_local_write,
                                        pq_file_size=pq_file_size,
                                        query_timeout=query_timeout,
                                        local_dir=local_dir,
                                        cols=cols,
                                        tag_value_list=tag_value_list,
                                        time_filter=time_filter,
                                        direct_query_enabled=direct_query_enabled,
                                        auto_direct_check=auto_direct_check,
                                        use_meta_cache=use_meta_cache,
                                        **kwargs)

    @close_session_finally
    def query_to_local_dir(self,
                           local_dir: str,
                           tbl: str,
                           query: str = None,
                           time_range_hint: str = "",
                           use_cache: bool = None,
                           cache_ttl: int = None,
                           cols: List[str] = None,
                           tag_value_list: List[str] = None,
                           time_filter: List[str] = None,
                           use_meta_cache: bool = False):
        if use_cache is None:
            thisQueryUseCache = self.query_use_cache
        else:
            thisQueryUseCache = use_cache
        if cache_ttl is None:
            thisCacheTTL = self.query_cache_ttl
        else:
            thisCacheTTL = cache_ttl
        if query is not None:
            if cols is not None or tag_value_list is not None or time_filter is not None:
                raise RuntimeError("not support cols, tag_value_list, time_filter while using query")
            return self.real_db.query_as_df(tbl=tbl,
                                            query=query,
                                            combine_ignore_index=True,
                                            local_dir=local_dir,
                                            order_by_range=time_range_hint,
                                            use_cache=thisQueryUseCache,
                                            cache_ttl=thisCacheTTL,
                                            use_meta_cache=use_meta_cache)
        else:
            if time_range_hint != "":
                raise RuntimeError("direct query does not support time_range_hint")
            if use_cache is not None or cache_ttl is not None:
                raise RuntimeError("direct query does not support cache")
            return self.real_db.direct_query_as_df(table_name=tbl,
                                                   cols=cols,
                                                   tag_value_list=tag_value_list,
                                                   time_filter=time_filter,
                                                   local_dir=local_dir,
                                                   use_meta_cache=use_meta_cache)

    @close_session_finally
    def remove_cache(self, tbl):
        self.real_db.invalidate_cache_related_to_tbl(tbl)

    @close_session_finally
    def remove_all_cache(self, dropNum: int = 10):
        assert dropNum > 0, "dropNum should be positive."
        self.real_db.invalidate_all_cache()
        self.real_db.drop_cache_immediately(maxDropNum=dropNum)

    @close_session_finally
    def remove_residual_cache(self):
        self.real_db.force_drop_residual_cache_like_tables()

    def close_connection(self, raise_error_if_double_close=False):
        self.real_db.close_session(raise_error_if_double_close)

    @close_session_finally
    def upload_df(self, df: pd.DataFrame, schema: list, table_name=None,
                  batch_size=200000, tag_cols="", ts_col="", max_worker_num=30,
                  use_parallel=True, use_memory_parquet=True, **kwargs):
        return self.real_db.upload_df(df, schema, table_name=table_name,
                                      batch_size=batch_size, tag_cols=tag_cols,
                                      ts_col=ts_col, max_worker_num=max_worker_num, use_parallel=use_parallel,
                                      use_memory_parquet=use_memory_parquet, **kwargs)

    @close_session_finally
    def query_raw_data(self, table=None, condition=None, sql=None):
        return self.real_db.query_raw_data(table, condition, sql)

    @close_session_finally
    def insert(self, table, values, batch: int = 2000, parallelism: int = 1, run_mode: str = CruxMode, **kwargs):
        return self.real_db.insert(table, values, batch, parallelism=parallelism, run_mode=run_mode, **kwargs)

    @close_session_finally
    def run(self, sql: str, use_pq: bool = True):
        return self.real_db.run(sql, use_pq)

    @DeprecationWarning
    def _register(self, func_id, table_name, func_body, package):
        if package == "package":
            cmd = f"{table_name}##register_package#{func_id}##{func_body}"
        elif package == "function":
            cmd = f"{table_name}##register#_({func_id})_##{func_body}"
        elif package == "file":
            cmd = f"{table_name}##register_file#{func_id}##{func_body}"
        else:
            raise ValueError(f"package type not support ")
        self.run_register_command(cmd)

    @close_session_finally
    @DeprecationWarning
    def create_stream_table(self, table_name: str, schema: list, **kwargs):
        self.real_db.create_stream_table(table_name, schema, **kwargs)

    @close_session_finally
    @DeprecationWarning
    def start_stream_job(self, table_name: str):
        self.real_db.start_stream_job(table_name)

    @close_session_finally
    @DeprecationWarning
    def stop_stream_job(self, table_name: str):
        self.real_db.stop_stream_job(table_name)

    @close_session_finally
    @DeprecationWarning
    def clean_up_stream_table(self, table_name: str):
        self.real_db.clean_up_stream_table(table_name)

    @close_session_finally
    @DeprecationWarning
    def query_join(self, base_table: str, base_cols: list, base_table_vin: str,
                   obd_table: str, obd_cols: list, obd_tag_col: str, obd_time_col: str, obd_f_tt: str, obd_f_list: str,
                   data_table: str, data_cols: list, data_tag_col: str, data_time_col: str,
                   filter: str, start_time: str, end_time: str,
                   base: int = 2000, filter_null: bool = True, all_time: bool = True, parallelism: int = 100):
        return self.real_db.query_join(base_table=base_table, base_cols=base_cols, base_table_vin=base_table_vin,
                                       obd_table=obd_table, obd_cols=obd_cols, obd_tag_col=obd_tag_col,
                                       obd_time_col=obd_time_col,
                                       obd_f_tt=obd_f_tt, obd_f_list=obd_f_list,
                                       data_table=data_table, data_cols=data_cols, data_tag_col=data_tag_col,
                                       data_time_col=data_time_col,
                                       filter=filter, start_time=start_time, end_time=end_time,
                                       base=base, filter_null=filter_null, all_time=all_time, parallelism=parallelism)

    @close_session_finally
    def like_count(self, table: str, tag_col: str, tag_like_str: str = "", base: int = 2000):
        return self.real_db.count_like(table=table, tag_col=tag_col, tag_like_str=tag_like_str, base=base)

    @close_session_finally
    def like_query(self, table: str, select_part: str, tag_col: str, tag_like_str: str = "", base: int = 2000):
        return self.real_db.query_like(table=table, select_part=select_part, tag_col=tag_col, tag_like_str=tag_like_str,
                                       base=base)

    @close_session_finally
    def common_join(self, left_table: str, right_table: str, dst_table: str, join_type: str = JoinType.leftjoin,
                    join_key_list: list = None,
                    left_cols: list = None, right_cols: list = None, left_filter: str = None, right_filter: str = None):
        self.real_db.common_join(left_table=left_table, right_table=right_table, dst_table=dst_table,
                                 join_type=join_type, join_key_list=join_key_list,
                                 left_cols=left_cols, right_cols=right_cols, left_filter=left_filter,
                                 right_filter=right_filter)

    @close_session_finally
    def asof_join(self, left_table: str, right_table: str, left_select_cols: list, right_select_cols: list,
                  left_join_keys: list = None, right_join_keys: list = None,
                  code_filter: list = None, low_ts_filter: str = None, high_ts_filter: str = None):
        return self.real_db.asof_join(left_table, right_table, left_select_cols, right_select_cols, left_join_keys,
                                      right_join_keys, code_filter, low_ts_filter, high_ts_filter)

    @close_session_finally
    def window_join(self, window: list, left_table: str, right_table: str,
                    left_select_cols: list = None, right_select_cols: list = None,
                    left_aggregation: list = None, right_aggregation: list = None,
                    left_join_keys: list = None, right_join_keys: list = None, code_filter: list = None,
                    low_ts_filter: str = None, high_ts_filter: str = None):
        return self.real_db.window_join(window, left_table, right_table, left_select_cols, right_select_cols,
                                        left_join_keys, right_join_keys, code_filter, low_ts_filter, high_ts_filter,
                                        left_aggregation, right_aggregation)

    @close_session_finally
    def run_sql(self, sql: str) -> list:
        return self.real_db.run_simple_command(sql)

    @close_session_finally
    def query_data(self, query: str = None, combine_ignore_index: bool = True, local_dir: str = None):
        return self.real_db.query_data(query=query, combine_ignore_index=combine_ignore_index, local_dir=local_dir)

    @close_session_finally
    def get_timelyre_schema(self, table_name, **kwargs):
        return self.real_db.get_timelyre_schema(table_name, **kwargs)

    @close_session_finally
    def get_tag_distribution(self, table_name, tag_value_list, use_meta_cache: bool = False, **kwargs):
        return self.real_db.get_tag_distribution(table_name, tag_value_list, use_meta_cache, **kwargs)

    @close_session_finally2
    def load_df(self, table_name, table_type="timelyre", use_connector_mode=True, datasource_version="v2",
                file_path="", tag_list=None, ts_min=None, ts_max=None, opts_map=None, **kwargs):
        return self.real_db.load_df(table_name, table_type, use_connector_mode, datasource_version,
                                    file_path, tag_list, ts_min, ts_max, opts_map, **kwargs)

    @close_session_finally2
    def load_df_from_file(self, file_path, file_type, schema=None, use_connector_mode=True):
        return self.real_db.load_file(file_path, file_type, schema, use_connector_mode)

    @close_session_finally2
    def save_df_as_table(self, df, table_name, table_type="timelyre", mode="error", tags=None, timecol=None):
        return self.real_db.save_df_as_table(df, table_name, table_type, mode, tags, timecol)

    def stop_leopard_session(self):
        return self.real_db.stop_leopard_session()

    def direct_query_as_df(self,
                           table_name: str,
                           cols: List[str] = None,
                           tag_value_list: List[str] = None,
                           time_filter: List[str] = None,
                           threads=-1,
                           use_meta_cache=False,
                           **kwargs):
        return self.real_db.direct_query_as_df(table_name=table_name, cols=cols, tag_value_list=tag_value_list,
                                               time_filter=time_filter, threads=threads, use_meta_cache=use_meta_cache,
                                               **kwargs)

    def timelyre2_direct_query_as_df(self,
                                     table_name: str,
                                     cols: List[str] = None,
                                     tag_value_list: Optional[List[str]] = None,
                                     time_filter: Optional[List[str]] = None,
                                     limit: Optional[int] = None,
                                     threads=-1,
                                     use_meta_cache=False,
                                     **kwargs):
        return self.real_db.timelyre2_direct_query_as_df(table_name=table_name, cols=cols, tag_value_list=tag_value_list,
                                                         time_filter=time_filter, limit=limit, threads=threads, use_meta_cache=use_meta_cache,
                                                          **kwargs)

    def get_rest_host_port(self):
        return self.real_db.get_rest_host_port()

    def check_direct_query_enabled(self):
        return self.real_db.direct_query_enabled

    @close_session_finally
    def get_tag_value_list(self, table_name: str, time_filter: List[str] = None, **kwargs):
        return self.real_db.get_tag_value_list(table_name, time_filter, **kwargs)

    @close_session_finally
    def get_quark_version(self):
        return self.real_db.get_quark_version()

    def get_internal_execute_command_count(self):
        return self.real_db.get_internal_execute_command_count()

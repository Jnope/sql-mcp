import time
import json

import requests

from transwarp.timelyre.timelyre_logger import getLogger


class QuarkFastMetaMgr:
    def __init__(self, host_port: str, token: str = None):
        self.host_port = host_port
        self.guardian_token = None
        if token is not None:
            self.guardian_token = f"&guardian_access_token={token}"
        else:
            self.guardian_token = ""
        getLogger().info(f"init QuarkFastMetaMgr, host_port: {host_port}")

    def get_conf(self, key: str):
        start_time = time.time_ns()
        url = f"http://{self.host_port}/api/fast_meta?optype=get_conf&key={key}{self.guardian_token}"
        resp = requests.get(url)
        js = resp.json()
        value = js["value"]
        end_time = time.time_ns()
        elapsed_time = (end_time - start_time) / 1000000
        getLogger().info("QuarkFastMetaMgr getConf %s executed in %.2f ms", key, elapsed_time)
        return value

    def get_schema(self, db: str, table_name: str, use_meta_cache=False):
        start_time = time.time_ns()
        url = f"http://{self.host_port}/api/fast_meta?optype=schema&db={db}&table={table_name}"
        if use_meta_cache:
            url += f"&use_meta_cache=true"
        url += self.guardian_token
        resp = requests.get(url)
        # http对方返回的数据可能不是utf-8
        # 反解码回bytes
        try:
            if resp.encoding is not None:
                bb = resp.text.encode(resp.encoding)
                # 重新编码成utf-8的字符串
                ss = bb.decode("utf-8")
                js = json.loads(ss)
            else:
                js = resp.json()
        except Exception as e:
            raise RuntimeError(f"error occurred while load json, resp.text: {resp.text}, error: {e}")
        if "error" in js:
            raise ValueError(f"{js['error']}")
        value = js["schema"]
        result = [[s.strip() for s in item.split(', ')] for item in value]
        end_time = time.time_ns()
        elapsed_time = (end_time - start_time) / 1000000
        getLogger().info("QuarkFastMetaMgr getSchema %s executed in %.2f ms", f"{db}.{table_name}", elapsed_time)
        return result

    def get_props(self, db: str, table_name: str, use_meta_cache=False):
        start_time = time.time_ns()
        url = f"http://{self.host_port}/api/fast_meta?optype=props&db={db}&table={table_name}"
        if use_meta_cache:
            url += f"&use_meta_cache=true"
        url += self.guardian_token
        resp = requests.get(url)
        js = resp.json()
        if "error" in js:
            raise ValueError(f"{js['error']}")
        value = js["props"]
        result = [item.strip() for item in value.split("\n")]
        end_time = time.time_ns()
        elapsed_time = (end_time - start_time) / 1000000
        getLogger().info("QuarkFastMetaMgr getProps %s executed in %.2f ms", f"{db}.{table_name}", elapsed_time)
        return result


if __name__ == "__main__":
    x = QuarkFastMetaMgr("localhost:4240")
    db = "default"
    table_name = "simple_test"
    not_exist_table = "simple_test_no_exist"
    print(x.get_conf("transwarp.docker.inceptor"))
    print(x.get_schema(db, table_name))
    print(x.get_props(db, table_name))


    #print(x.get_schema(db, not_exist_table))
    print(x.get_props(db, not_exist_table))
import io
import os
import pandas as pd

def read_parquet_bytes(bytesArr: list, combine_ignore_index: bool):
    dataframes = []
    for f in bytesArr:
        x = io.BytesIO(f)
        df = pd.read_parquet(x)
        dataframes.append(df)

    df = pd.concat(dataframes, ignore_index=combine_ignore_index)
    return df

def read_parquet_dir(dir, combine_ignore_index: bool=True):
    dataframes = []
    for f in os.listdir(dir):
        x = os.path.join(dir, f)
        df = pd.read_parquet(x)
        dataframes.append(df)

    df = pd.concat(dataframes, ignore_index=combine_ignore_index)
    return df


def read_parquet_dir_multi_df(dir) -> list:
    dataframes = []
    for f in os.listdir(dir):
        x = os.path.join(dir, f)
        df = pd.read_parquet(x)
        dataframes.append(df)
    return dataframes

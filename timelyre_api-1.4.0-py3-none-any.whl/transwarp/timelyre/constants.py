#存储对应的数据类型
from enum import Enum

# timelyre数据类型
DoubleType = 1
LongType = 2
VarStringType = 3
BoolType = 4
TimestampType = 5
TagType = 7
CastDateType = 16
CastMinuteType = 17
CastTSType = 18

# quark端支持的执行模式
QuarkMode = "quark"
CruxMode = "crux"

class DataType(Enum):
    """
    DataframeApi建表支持的数据类型
    """
    int = "int"
    bigint = "bigint"
    timestamp = "timestamp"
    boolean = "boolean"
    string = "string"
    double = "double"
    float = "float"

    @classmethod
    def has_key(cls, name):
        return name in cls.__members__

    @classmethod
    def get_all_type(cls):
        datatypes = [x.value for x in DataType]
        return " ".join(datatypes)

# DataframeApi建表支持的数据类型中属于数值的类型
numeric_types = [DataType.int.value, DataType.bigint.value, DataType.double.value, DataType.boolean.value]

class JoinType(Enum):
    """
    CommonJoin目前支持的join类型
    """
    innerjoin = "inner"
    leftjoin = "left"
    rightjoin = "right"
    fulljoin = "full"


    @classmethod
    def has_key(cls, name):
        return name in cls.__members__

    @classmethod
    def get_all_type(cls):
        jointypes = [x.value for x in JoinType]
        return " ".join(jointypes)
def timelyre_type_to_sql_type(col_name, tp, user_ts_cols=None):
    """
    crux-engine返回的timelyre数据类型转化成timelyreapi支持的数据类型
    :param col_name: 列名
    :param tp: timelyre数据类型
    :param user_ts_cols: 除指定ts列之外的其他ts列。这些列的类型会表示为Integer
    :return: timelyreapi数据类型
    """
    if tp == "Tag":
        return DataType.string.value
    elif tp == "String":
        return DataType.string.value
    elif tp == "Timestamp":
        return DataType.timestamp.value
    elif tp == "Integer":
        if user_ts_cols is not None and col_name in user_ts_cols:
            return DataType.timestamp.value
        else:
            return DataType.int.value
    elif tp == "Float":
        return DataType.double.value
    else:
        raise RuntimeError(f"unsupported timelyre type: {tp} for col: {col_name}")

def type_value_to_type_int(v: str, datatype: str):
    """
    quark返回的schema中timelyre数据类型的值会根据类型被处理
        eg：类型是double, 对应的timelyre类型是1, 会被quark处理成"1.0"返回
    本方法将被处理过的timelyre数据类型，根据类型还原成实际的timelyre数据类型
    :param v:被处理过的timelyre数据类型值
    :param datatype:列类型
    :return:还原后正确的timelyre数据类型
    """
    if datatype in [DataType.string.value, DataType.int.value, DataType.bigint.value]:
        return int(v)
    elif datatype == DataType.double.value:
        return int(float(v))
    elif datatype == DataType.boolean.value:
        return 4
    else:
        raise RuntimeError(f"unsupported, value: {v}, type: {type(v)}")


import threading

from hdfs import InsecureClient
import os

from transwarp.time_utils import str_to_datetime
from transwarp.timelyre.dfs.DFSClient import init_krb
from transwarp.timelyre.timelyre_logger import getLogger


# from hdfs.ext.dataframe import read_dataframe, write_dataframe

def hdfs_path_normalize_to_client(_hdfs_path) -> str:
    if _hdfs_path.startswith("hdfs://"):
        hdfs_path = _hdfs_path[len("hdfs://"):]
        hdfs_path = hdfs_path[hdfs_path.find("/"):]
    else:
        hdfs_path = _hdfs_path
    return hdfs_path

def get_hdfs_files(_hdfs_path: str, local_dir_prefix: str, realm: str=None, keytab: str=None, nn_addr: str=None):
    hdfs_path = hdfs_path_normalize_to_client(_hdfs_path)

    if nn_addr is None:
        nn_addr = os.environ.get("HDFS_NN_ADDR", None)

    if nn_addr is None:
        raise ValueError("HDFS NN address is not specified.")

    c = load_hdfs_client(nn_addr, realm is not None, realm, keytab)
    if len(c.list(hdfs_path)) != 0:
        dir = c.download(hdfs_path=hdfs_path, local_path=local_dir_prefix, n_threads=2)
        getLogger().info(dir)
        return dir
    else:
        return None

def get_hdfs_files_into_memory(_hdfs_path: str, realm: str=None, keytab: str=None, nn_addr: str=None):
    hdfs_path = hdfs_path_normalize_to_client(_hdfs_path)

    if nn_addr is None:
        nn_addr = os.environ.get("HDFS_NN_ADDR", None)

    if nn_addr is None:
        raise ValueError("HDFS NN address is not specified.")

    c = load_hdfs_client(nn_addr, realm is not None, realm, keytab)
    dir_files = c.list(hdfs_path)
    if len(dir_files) != 0:
        ret = []
        for fn in dir_files:
            with c.read(hdfs_path=hdfs_path + "/" + fn) as reader:
                data = reader.read()
                ret.append(data)
        return ret
    else:
        return None

def get_hdfs_single_file_into_memory(_hdfs_file_path: str, realm: str=None, keytab: str=None, nn_addr: str=None):
    hdfs_file_path = hdfs_path_normalize_to_client(_hdfs_file_path)

    if nn_addr is None:
        nn_addr = os.environ.get("HDFS_NN_ADDR", None)

    if nn_addr is None:
        raise ValueError("HDFS NN address is not specified.")

    c = load_hdfs_client(nn_addr, realm is not None, realm, keytab)
    with c.read(hdfs_path=hdfs_file_path) as reader:
        data = reader.read()
        return data

def put_hdfs_file(_hdfs_path: str, local_file: str, realm: str=None, keytab: str=None):
    xx = os.environ.get("HDFS_NN_ADDR", None)
    if xx is None:
        raise ValueError("HDFS NN address is not specified.")

    c = load_hdfs_client(xx, realm is not None, realm, keytab)
    with open(local_file, "rb") as f:
        data = f.read()
        c.write(_hdfs_path, data)

    return


def load_hdfs_client(url, use_krb: bool, realm=None, keytab=None):
    if use_krb:
        from hdfs.ext.kerberos import KerberosClient
        init_krb(realm, keytab)
        # c = TokenClient(url="http://tq-dev-node5:50070", token="BfWE1eaYA3lb3IqCuFsy-TDH")
        c = KerberosClient(url=url, principal=realm)
    else:
        c = InsecureClient(url=url, user="hive")
    return c


if __name__ == "__main__":

    # ticket = KrbTicket.init("lty@TDH", "./lty.keytab")
    # ticket.updater_start()
    # c = TokenClient(url="http://tq-dev-node5:50070", token="BfWE1eaYA3lb3IqCuFsy-TDH")
    # c = KerberosClient(url="http://tq-dev-node5:50070", principal="lty@TDH")
    # print(c.list("/"))

    os.environ["HDFS_NN_ADDR"] = "http://172.18.128.49:50070"

    c = InsecureClient(url="http://crux-49:50070", user="hive")
    print(c.list("/"))

    put_hdfs_file("/quark4/user/hive/warehouse/ray.db/hive/szl2_order_test_days__cache_2/tradingtime_lt_2023_06_22/000002_0",
                  "./000001_0")
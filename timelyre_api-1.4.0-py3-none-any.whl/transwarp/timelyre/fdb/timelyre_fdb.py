import argparse
import atexit
import concurrent.futures
import datetime
import os
import re
import shutil
import time
import uuid
from dataclasses import dataclass
from io import BytesIO

import pandas as pd
import pyarrow.parquet
from pandas import DataFrame

from transwarp.timelyre.dfs.DFSClient import DFSClient
from transwarp.timelyre.fdb.db_utils import get_table_schema, SimpleConnInfo, BASE_DATE, PartInfo, PartTable, \
    RANGE_NAME_PATTERN, get_table_schema_and_range, make_conn
from transwarp.timelyre.timelyre_logger import getLogger

from transwarp.timelyre.quark import read_parquet_dir_multi_df

from transwarp.timelyre.fdb.hdfs_utils import get_hdfs_files, get_hdfs_files_into_memory
from transwarp.timelyre.utils.df_utils import slice_timed_df, dt_to_pd_local_dt, combine_two_time_dataframe, \
    df_normalize_time
from transwarp.timelyre.timelyre_public import DatabaseConn


class FileDBClient:
    def __init__(self, dbconn_info: SimpleConnInfo, fetch_file_concurrency=3, working_dir_base="."):
        assert fetch_file_concurrency >= 1
        #检验本地时区是北京时区
        assert datetime.datetime.now().astimezone().tzinfo.utcoffset(None).seconds == 28800

        hdfs_nn_addrs = dbconn_info.hdfs_nn_addrs

        if hdfs_nn_addrs is None:
            hdfs_nn_addrs = os.environ.get("HDFS_NN_ADDR", None)

        if hdfs_nn_addrs is None:
            raise ValueError("HDFS NN address is not specified.")
        self.hdfs_nn_addrs = hdfs_nn_addrs
        self.hdfs_client = DFSClient(hdfs_nn_addrs, dbconn_info.realm is not None, realm=dbconn_info.realm, keytab=dbconn_info.keytab_path)
        self.conn_info = dbconn_info
        self.conn = self._make_conn()
        self.fetch_file_concurrency = fetch_file_concurrency
        self.working_dir = working_dir_base + "/" + self._get_datetime() + "-" + str(uuid.uuid1()) + "/"
        os.mkdir(self.working_dir)
        self.query_id = 0

        atexit.register(self.close)
        pass

    def close(self):
        if os.path.exists(self.working_dir):
            shutil.rmtree(self.working_dir)

    def _make_conn(self) -> DatabaseConn:
        return make_conn(conn_info)

    def _time_range(self, st: datetime.date, nd: datetime.date, period_days=90, base_date=BASE_DATE):
        assert period_days >= 1 and period_days <= 100, "period days should in range [10, 100]"
        ret = []
        if st >= base_date:
            xx = (st - base_date).days // period_days
            yy = (nd - base_date).days // period_days + 1
            for i in range(xx, yy, 1):
                cur_st = base_date + datetime.timedelta(days=period_days * i)
                cur_nd = base_date + datetime.timedelta(days=period_days * (i + 1))
                if cur_nd < st or cur_st >= nd:
                    pass
                else:
                    # print(f"index {i} valid")
                    ret.append((cur_st, cur_nd))
        return ret

    def delete_filedb_table(self, db_name: str, table_name: str):
        xx = self.list_filedb_tables(db_name)
        if table_name in xx:
            self.conn.run_simple_command(f"drop table {db_name}.{table_name}")
            return True
        else:
            return False

    def list_filedb_tables(self, db_name: str):
        ret = self.conn.query_raw_data(sql=f"select table_name from system.table_parameters_v "
                                 f"where database_name=\"{db_name}\" "
                                 f"and parameter_key=\"is_timelyre_filedb\" "
                                 f"and parameter_value=\"true\"")
        return [x[0] for x in ret]

    def copy_fdb_table(self,
                       s_db_name: str, s_tbl_name: str,
                       d_db_name: str, d_tbl_name: str,
                       ):
        paras = self.conn.query_raw_data(sql=f"select parameter_key, parameter_value from system.table_parameters_v "
                                     f"where database_name=\"{s_db_name}\" "
                                     f"and table_name=\"{s_tbl_name}\"")
        tbl_props = {}
        for x in paras:
            tbl_props[x[0]] = x[1]

        assert tbl_props.get("is_timelyre_filedb", "false") == "true", f"{s_db_name}.{s_tbl_name} is not a fdb table."


        #使用like复制表结构(包括分区信息)
        self.conn.run_simple_command(f"create table {d_db_name}.{d_tbl_name} like {s_db_name}.{s_tbl_name}")


        #补上复制一些默认没有复制的表属性
        MUST_COPY_OPTIONS = ["is_timelyre_filedb"]
        OTHER_COPY_OPTIONS = ["partition.size"]

        added_props = {}
        for k in MUST_COPY_OPTIONS:
            v = tbl_props[k]
            added_props[k] = v
        for k in OTHER_COPY_OPTIONS:
            v = tbl_props.get(k, None)
            if v is not None:
                added_props[k] = v

        props_str = ", ".join([f"\"{k}\"=\"{v}\""for k, v in added_props.items()])
        copy_options_sql = f"alter table {d_db_name}.{d_tbl_name} set tblproperties({props_str})"
        self.conn.run_simple_command(copy_options_sql)

        #按分区复制数据
        old_tbl = self._get_fdb_table_schema_and_range(f"{s_db_name}.{s_tbl_name}")
        new_tbl = self._get_fdb_table_schema_and_range(f"{d_db_name}.{d_tbl_name}")
        assert len(old_tbl.parts) == len(new_tbl.parts), "Internal error, copied table partitions are not consistent."

        for k, opi in old_tbl.parts.items():
            npi = new_tbl.parts[k]
            self.conn.run_simple_command(f"dfs -cp {opi.loc}/* {npi.loc}")

        return

    def build_fdb_table(self,
                        db_name: str, tbl_name: str,
                        time_col: str, time_range: tuple,
                        fdb_db_name: str, fdb_tbl_name: str,
                        segment_days: int = 90,
                        skip_import=False,
                        ):
        x, y = self._normalize_range(time_range[0], time_range[1])
        range_list = self._time_range(x, y, period_days=segment_days)
        target_fdb_full_name = f"{fdb_db_name}.{fdb_tbl_name}"
        cache_table_ddl, cache_table_name = self._make_cache_table_ddl(db_name=db_name, tbl_name=tbl_name,
                                                                       range_col=time_col,
                                                                       ranges=range_list, target_tbl_name=target_fdb_full_name)
        # 创建缓存表，range分区
        getLogger().info(f"[Create Table] {cache_table_ddl}")
        self.conn.run_simple_command(cache_table_ddl)

        def run_import(x: tuple, reuse_conn=None):
            this_import_sql = self._make_import_sql(target_full_name=cache_table_name,
                                                    src_full_name=db_name + "." + tbl_name, range_col=time_col, r=x)
            getLogger().info(f"[Import Data] {this_import_sql}")
            if reuse_conn is not None:
                this_conn = reuse_conn
            else:
                this_conn = self._make_conn()

            ret = this_conn.query_raw_data(sql=this_import_sql)
            getLogger().info(f"insert {x} ret: {ret}")

        if not skip_import:
            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                # 使用executor.map并行执行函数，并获取结果
                results = list(executor.map(run_import, range_list))

    def _to_date(self, dt: datetime.datetime):
        return datetime.date(year=dt.year, month=dt.month, day=dt.day)

    def _split_and_align_times(self, df: DataFrame, time_col: str, pdays: int, base_date: datetime.date):
        assert df[time_col].dtype.base == "datetime64[ns]"
        max_time = df[time_col].max()
        min_time = df[time_col].min()
        st_dt, nd_dt = self._normalize_range(min_time.to_pydatetime(), max_time.to_pydatetime())
        range_list = self._time_range(st_dt, nd_dt, pdays, base_date)
        return range_list, st_dt, nd_dt

    def _get_table_schema(self, table: str):
        return get_table_schema(self.conn, table)

    def _get_fdb_table_schema_and_range(self, table: str):
        return get_table_schema_and_range(self.conn, table)

    def validate_schema(self, schema, target_schema):
        #TODO
        return True

    def _get_datetime(self):
        current_datetime = datetime.datetime.now()
        current_datetime_str = current_datetime.strftime('%Y-%m-%d-%H-%M-%S')
        return current_datetime_str

    def make_session_path(self, path):
        if os.path.isabs(path):
            raise ValueError("should not provide absolute path")
        return self.working_dir + "/" + path


    def _do_overwrite_part(self, put_id, src_pq_file, full_table, part_name, pi: PartInfo):
        self.hdfs_client.remove(pi.loc, recursive=True)
        fn = put_id + "" + self._get_datetime()
        self.hdfs_client.put(pi.loc + "/" + fn, src_pq_file)

    def _do_combine_part(self, put_id, src_pq_file, full_table, part_name, pi: PartInfo, timecol: str):
        local_dir = self.hdfs_client.get(pi.loc, self.working_dir)

        src_df = pd.read_parquet(local_dir)
        self.__post_dataframe_process(src_df)
        # src_df.set_index(timecol)

        insert_df = pd.read_parquet(src_pq_file)
        self.__post_dataframe_process(insert_df)
        # insert_df.set_index(timecol)

        fn = put_id + "" + self._get_datetime()

        #FIXME:
        # dst_df = pd.concat([src_df, insert_df])
        dst_df = combine_two_time_dataframe(src_df, insert_df, timecol)
        dst_df.sort_values(by=timecol)
        dst_local_fp = self.make_session_path(f"{fn}")
        dst_df = df_normalize_time(dst_df)
        dst_df.to_parquet(dst_local_fp)
        self._do_overwrite_part(put_id, dst_local_fp, full_table, part_name, pi)
        pass

    def put(self, db_name, tbl_name, df: DataFrame, time_col: str):
        full_name = f"{db_name}.{tbl_name}"
        table = self._get_fdb_table_schema_and_range(full_name)
        base_date = table.find_base_date()
        align_ranges, min_dt, max_dt = self._split_and_align_times(df, time_col, table.period_days, base_date)
        put_id = str(uuid.uuid1())

        if min_dt < table.min_date or max_dt > table.max_date:
            raise RuntimeError(f"Your put dataframe time range [{min_dt}, {max_dt}) is out of "
                               f"internal fdb table time range [{table.min_date}, {table.max_date}]")

        to_put_ranges = []
        for x in align_ranges:
            xx = (x[0], x[1], x[0], x[1])
            if min_dt >= x[0] and min_dt < x[1]:
                xx = (min_dt, xx[1], xx[2], xx[3])
            if max_dt >= x[0] and max_dt < x[1]:
                xx = (xx[0], max_dt, xx[2], xx[3])
            to_put_ranges.append(xx)


        for x in to_put_ranges:
            pd_st = dt_to_pd_local_dt(x[0]) #pd.Timestamp(year=x[0].year, month=x[0].month, day=x[0].day)
            pd_nd = dt_to_pd_local_dt(x[1]) #pd.Timestamp(year=x[1].year, month=x[1].month, day=x[1].day)
            sub_df = df[ (df[time_col] >= pd_st) & (df[time_col] < pd_nd)]
            fp = self.make_session_path(f"{x[0]}_{x[1]}.parquet")
            sub_df = df_normalize_time(sub_df)
            sub_df.to_parquet(fp)
            schema = pyarrow.parquet.read_schema(fp)
            self.validate_schema(schema, table.schema)

        for x in to_put_ranges:
            real_st, real_nd, norm_st, norm_nd = x
            pi = table.parts[norm_nd]
            if real_st == norm_st and real_nd == norm_nd:
                fp = self.make_session_path(f"{x[0]}_{x[1]}.parquet")
                self._do_overwrite_part(put_id, fp, full_name, pi.part_name, pi)
            else:
                fp = self.make_session_path(f"{x[0]}_{x[1]}.parquet")
                self._do_combine_part(put_id, fp, full_name, pi.part_name, pi, time_col)

        return

    def _match_ranges(self, db_name: str, tbl_name: str, time_range: tuple):
        t11 = time.time()
        data = self.conn.query_raw_data(
            sql=f"select partition_name, location from system.range_partitions_v where database_name=\"{db_name}\" and table_name=\"{tbl_name}\"")
        t21 = time.time()
        getLogger().info(f"fetch partition info cost {t21 - t11}")
        st, nd = time_range

        part_locs = {}
        for xx in data:
            part_locs[xx[0]] = xx[1]

        prefix = ""
        all_ranges = []
        for x in data:
            m = re.match(RANGE_NAME_PATTERN, x[0])
            if m:
                prefix = m.group(1)
                dt_str = m.group(2)
                year_str, month_str, day_str = dt_str.split("_")
                dt = datetime.date(year=int(year_str), month=int(month_str), day=int(day_str))
                all_ranges.append(dt)

        selected_ranges = []
        if len(all_ranges) == 0:
            return pd.DataFrame()

        all_ranges.sort()
        if all_ranges[0] > st:
            assert False, f"require {st} is out of scope"
            #不应该取到第一个range，第一个range只是为符合quark规范建的
            #selected_ranges.append(all_ranges[0])

        last = all_ranges[0]
        for x in all_ranges[1:]:
            cur_st, cur_nd = last, x
            if cur_st >= nd or cur_nd <= st:
                pass
            else:
                selected_ranges.append(x)
            last = x
        return selected_ranges

    def __post_dataframe_process(self, df):
        """
        对获取到的dataframe进行一些额外的处理，包括：
            1. 把时间列修正为local timezone的表示
        :param df:
        :return:
        """
        lz = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
        for (a, b) in df.select_dtypes('datetime64').items():
            if b.dt.tz is None:
                df[a] = b.dt.tz_localize(datetime.timezone.utc).dt.tz_convert(lz)

    def _normalize_date_time(self, dt) -> datetime.datetime:
        if type(dt) == datetime.date:
            return datetime.datetime(year=dt.year, month=dt.month, day=dt.day)
        elif type(dt) == datetime.datetime:
            return dt
        else:
            raise ValueError("only support datetime and date")

    def _normalize_range(self, user_st, user_nd) -> tuple:
        #左边界的日期时间，变成日期
        user_st_dt = self._normalize_date_time(user_st)
        st = user_st_dt.date()

        #右边界的日期时间，变成日期。 注意： 如果不是当天的0点，那么右边界要往外一天，确保从内部取数据时不会少。
        user_nd_dt = self._normalize_date_time(user_nd)
        if user_nd_dt.time() == datetime.time(0):
            nd = user_nd_dt.date()
        else:
            nd = user_nd_dt.date() + datetime.timedelta(days=1)
        return st, nd

    def query(self, db_name: str, tbl_name: str, tcol: str, time_range: tuple):
        schema = self._get_table_schema(f"{db_name}.{tbl_name}")
        t11 = time.time()
        data = self.conn.query_raw_data(
            sql=f"select partition_name, location from system.range_partitions_v where database_name=\"{db_name}\" and table_name=\"{tbl_name}\"")
        t21 = time.time()
        getLogger().info(f"fetch partition info cost {t21 - t11}")
        user_st, user_nd = time_range

        st, nd = self._normalize_range(user_st, user_nd)

        part_locs = {}
        for xx in data:
            part_locs[xx[0]] = xx[1]

        prefix = ""
        all_ranges = []
        for x in data:
            m = re.match(RANGE_NAME_PATTERN, x[0])
            if m:
                prefix = m.group(1)
                dt_str = m.group(2)
                year_str, month_str, day_str = dt_str.split("_")
                dt = datetime.date(year=int(year_str), month=int(month_str), day=int(day_str))
                all_ranges.append(dt)

        selected_ranges = []
        if len(all_ranges) == 0:
            return pd.DataFrame(columns=[x[0] for x in schema])

        all_ranges.sort()
        if all_ranges[0] > st:
            selected_ranges.append(all_ranges[0])

        last = all_ranges[0]
        for x in all_ranges[1:]:
            cur_st, cur_nd = last, x
            if cur_st >= nd or cur_nd <= st:
                pass
            else:
                selected_ranges.append(x)
            last = x

        def _fetch_one_range_part_file(range_part_loc, use_quark_get_hdfs_files=False):
            if use_quark_get_hdfs_files:
                raise NotImplementedError
            else:
                t1 = time.time()
                path = get_hdfs_files(range_part_loc, self.working_dir + "/query/", self.conn_info.realm, self.conn_info.keytab_path, nn_addr=self.hdfs_client.http_active_nn)
                t2 = time.time()
            getLogger().info(f"fetch_file {t2 - t1}")
            return path

        def _fetch_one_range_part_df(range_part_loc, use_quark_get_hdfs_files=False):
            if use_quark_get_hdfs_files:
                t1 = time.time()
                this_conn = self._make_conn()
                t2 = time.time()
                df = this_conn.real_db.fetch_hdfs_pq_dir_as_df(range_part_loc)
                t3 = time.time()
                dfs = [df]
            else:
                t1 = time.time()
                path = get_hdfs_files(range_part_loc, ".", self.conn_info.realm, self.conn_info.keytab_path, nn_addr=self.hdfs_client.http_active_nn)
                t2 = time.time()
                if path is not None:
                    dfs = read_parquet_dir_multi_df(path)
                    # shutil.rmtree(path)
                else:
                    dfs = []
                    pass
                t3 = time.time()
            print(f"conn {t2 - t1} fetch {t3 - t2}")
            return dfs

        if False:
            dfs = []
            for x in selected_ranges:
                part_name = prefix + str(x).replace("-", "_")
                print(part_name, part_locs[part_name])
                df = self.conn.real_db.fetch_hdfs_pq_dir_as_df(part_locs[part_name])
                dfs.append(df)
        else:
            dfs = []
            all_fetch_locs = []
            for x in selected_ranges:
                part_name = prefix + str(x).replace("-", "_")
                part_loc = part_locs[part_name]
                all_fetch_locs.append(part_loc)
            with concurrent.futures.ThreadPoolExecutor(max_workers=self.fetch_file_concurrency) as executor:
                if False:
                    #并行生成小DF
                    dfs = list(executor.map(_fetch_one_range_part_df, all_fetch_locs))
                else:
                    if os.path.exists(self.working_dir + "/query"):
                        shutil.rmtree(self.working_dir + "/query")
                    os.mkdir(self.working_dir + "/query")
                    os.mkdir(self.working_dir + "/query/read_pq_in_one_dir")
                    #并行下载文件
                    dirs = list(executor.map(_fetch_one_range_part_file, all_fetch_locs))
                    for dir in dirs:
                        if dir is not None:
                            for x in os.listdir(dir):
                                getLogger().info(f"move local file {dir}/{x}")
                                if os.path.isfile(dir + "/" + x):
                                    xx = os.path.basename(dir)
                                    shutil.move(f"{dir}/{x}", self.make_session_path(f"query/read_pq_in_one_dir/{xx}_{x}"))
                            shutil.rmtree(dir)
                    #直接生成大DF
                    x1 = time.time()
                    df = pd.read_parquet(self.make_session_path("query/read_pq_in_one_dir"))
                    x2 = time.time()
                    getLogger().info(f"big df load cost {x2 - x1}")
                    dfs = [[df]]
            dfs = [element for row in dfs for element in row]
        tt1 = time.time()
        if len(dfs) > 1:
            ret_df = pd.concat(dfs, ignore_index=True)
        else:
            ret_df = dfs[0]
        tt2 = time.time()
        getLogger().info(f"Combine final df cost {tt2 - tt1}")
        self.__post_dataframe_process(ret_df)
        if len(ret_df) == 0:
            return pd.DataFrame(columns=[x[0] for x in schema])

        ret_df = slice_timed_df(ret_df,  tcol, time_range[0], time_range[1], ignore_index=True)
        return ret_df

    def _make_timestamp(self, dt):
        if type(dt) == datetime.date:
            return str(datetime.datetime(year=dt.year, month=dt.month, day=dt.day))
        elif type(dt) == datetime.datetime:
            return str(dt)
        else:
            raise NotImplementedError

    def _make_import_sql(self, target_full_name: str, src_full_name: str, range_col: str, r: tuple):

        return f"insert overwrite table {target_full_name} partition {self._make_part_name(range_col, r[1])} " \
               f"select * from {src_full_name} where {range_col} >= '{self._make_timestamp(r[0])}' and {range_col} < '{self._make_timestamp(r[1])}' distribute by 1"

    def _make_cache_table_ddl(self, db_name: str, tbl_name: str, range_col: str, ranges: list, target_tbl_name: str = None):
        xx = self.conn.query_raw_data(
            sql=f"select column_id, column_name, column_type from system.columns_v where database_name=\"{db_name}\" and table_name=\"{tbl_name}\"")
        if len(xx) == 0:
            raise RuntimeError(f"table {db_name}.{tbl_name} has no columns, and it may not be existed.")
        xx = sorted(xx, key=lambda x: int(x[0]))
        schema = [(x[1], x[2]) for x in xx]
        id = str(uuid.uuid1()).replace("-", "_")

        if target_tbl_name is None:
            ref_table_name = db_name + "." + "__" + tbl_name + f"_{id}"
        else:
            ref_table_name = target_tbl_name

        ct = self.make_create_table(tbl_name=ref_table_name, schema=schema, range_col=range_col, ranges=ranges)
        return ct, ref_table_name

    def _make_part_name(self, col, dt):
        if type(dt) == datetime.datetime:
            return col + "_LT_" + str(dt.date()).replace("-", "_")
        elif type(dt) == datetime.date:
            return col + "_LT_" + str(dt).replace("-", "_")

    def make_create_table(self, tbl_name: str, schema: list, range_col: str, ranges: list, format: str = "parquet"):

        schema_spec = ",".join([f"`{x[0]}` {x[1]}" for x in schema])
        range_col_spec = ""
        for x in schema:
            if x[0] == range_col:
                assert x[1].lower() == "date" or x[
                    1].lower() == "timestamp", f"{range_col} should be TIMESTAMP or DATE type."
                range_col_spec = f"{x[0]} {x[1]}"
                break
        rr = ranges[:]
        rr.append((rr[-1][1], None))
        range_spec = ",".join(
            [f"PARTITION {self._make_part_name(range_col, x[0])} VALUES LESS THAN ('{x[0]}')" for x in rr])
        return f"CREATE TABLE {tbl_name}({schema_spec}) PARTITIONED BY RANGE({range_col}) ({range_spec}) STORED AS {format} " \
               f"tblproperties(\"is_timelyre_filedb\"=\"true\")"

DEFAULT_REALM_PATTERN = "default_realm\s*=\s*([^\s]+)"

if __name__ == "__main__":

    parser = argparse.ArgumentParser(
        prog='timelyre-fast-cache',
        description='timelyre-fast-cache')

    parser.add_argument('-tc', '--timechord', required=True, default=None)
    parser.add_argument('-conn', '--jdbcconn', required=True, default=None)
    parser.add_argument('-u', '--user', required=False, default=os.environ.get("username", None))
    parser.add_argument('-pwd', '--password', required=False, default=os.environ.get("password", None))
    parser.add_argument('-t', '--token', required=False, default="")
    parser.add_argument('-op', '--optype', required=True, choices=["fetch", "query", "put"])
    parser.add_argument('-tcol', '--time_col', required=False, default=None)
    parser.add_argument('-db', '--database', required=True, default="")
    parser.add_argument('-tbl', '--table', required=True, default="")
    # parser.add_argument('-cp', '--cache_postfix', required=False, default=None)
    parser.add_argument('-tdb', '--target_database', required=False, default=None)
    parser.add_argument('-ttbl', '--target_table', required=True, default=None)
    parser.add_argument('-st', '--start', required=True, default="")
    parser.add_argument('-nd', '--end', required=True, default="")
    parser.add_argument('-ffc', '--fetch_file_concurrency', required=False, default="3")
    parser.add_argument('-krb', '--use_krb', required=False, default=False)
    parser.add_argument('-r', '--realm', required=False, default=None)
    parser.add_argument('-kt', '--keytab', required=False, default=None)
    args = parser.parse_args()

    if args.optype == "fetch":
        assert args.time_col is not None, "time col should not be None."


    if args.use_krb:
        assert args.keytab is not None
        krb5_config_path = os.environ.get("KRB5_CONFIG", None)

        if krb5_config_path is not None:
            # config = configparser.ConfigParser()
            # config.read(krb5_config_path)
            # def_realm = config.get("libdefaults", "default_realm")
            def_realm = None
            with open(krb5_config_path) as f:
                for x in f.readlines():
                    m = re.search(DEFAULT_REALM_PATTERN, x)
                    if m:
                        def_realm = m.group(1)
                        break
            assert def_realm is not None, "default realm is not present in config file."

            realm = args.user + "@" + def_realm
        else:
            assert args.realm is not None, "KRB5_CONFIG and realm are both not set."
            realm = args.realm
        keytab_path = args.keytab
    else:
        realm = None
        keytab_path = None

    st_date = datetime.datetime.strptime(args.start, "%Y-%m-%d").date()
    nd_date = datetime.datetime.strptime(args.end, "%Y-%m-%d").date()

    conn_info = SimpleConnInfo(args.timechord, args.jdbcconn, args.user, args.password, db=args.database, realm=realm, keytab_path=keytab_path)
    c = FileDBClient(conn_info, int(args.fetch_file_concurrency))

    if args.target_database is None:
        target_table_full_name = args.database + "." + args.target_table
    else:
        target_table_full_name = args.target_database + "." + args.target_table

    if args.optype == "fetch":
        t1 = time.time()
        c.build_fdb_table(args.database, args.table, args.time_col, time_range=(st_date, nd_date), skip_import=False,
                          fdb_db_name=args.database, fdb_tbl_name=target_table_full_name)
        t2 = time.time()
        print(
            f"fetch from {args.database}.{args.table} to {target_table_full_name} with time ({str(st_date)}, {str(nd_date)}) costs {t2 - t1} s.")
    elif args.optype == "query":
        t1 = time.time()
        df = c.query(target_table_full_name, time_range=(st_date, nd_date))
        t2 = time.time()
        print(df)
        print(f"fetch cost {t2 - t1} seconds")
    elif args.optype == "put":
        t1 = time.time()
        xx = pd.read_parquet("./000001_0")
        # xx.to_parquet(c.make_session_path("./xxx.parquet"))
        # schema = pyarrow.parquet.read_schema("/Users/ray/projects/pytimelyre/transwarp/timelyre/cc/pq/tradingtime_lt_2023_06_22_000001_0")
        # schema2 = pyarrow.parquet.read_schema("./pq/xxx.parquet")
        # print(schema)
        df = c.put(target_table_full_name, xx, "tradingtime")
        t2 = time.time()
        print(df)
        print(f"fetch cost {t2 - t1} seconds")
    else:
        raise NotImplementedError(f"Cannot recognize optype {args.optype}")
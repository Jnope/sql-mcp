import datetime
import io

import pandas as pd
import pyarrow.parquet as pq
import pyarrow.compute as pc
from pyarrow import dataset
from pyarrow._fs import PyFileSystem, FileSystemHandler
import pyarrow as pa
import base64

def read_parquet_into_df(source) -> pd.DataFrame:
    return pd.read_parquet(source)


def read_parquet_into_df_ext(source,
                         single_tag_col_name: str, tag_values: list,
                         time_col: str, time_range: tuple, sel_cols: list) -> pd.DataFrame:
    filters = [
        (time_col, ">=", time_range[0]),
        (time_col, "<", time_range[1]),
    ]

    if single_tag_col_name is not None:
        filters.append((single_tag_col_name, "in", tag_values))

    table = pq.read_table(source, columns=sel_cols, filters=filters, use_threads=True)
    df = table.to_pandas()
    return df

class MyFileSystemHandler(FileSystemHandler):

    def copy_file(self, src, dest):
        raise NotImplementedError

    def create_dir(self, path, recursive):
        raise NotImplementedError

    def delete_dir(self, path):
        raise NotImplementedError

    def delete_dir_contents(self, path, missing_dir_ok=False):
        raise NotImplementedError

    def delete_file(self, path):
        raise NotImplementedError

    def delete_root_dir_contents(self):
        raise NotImplementedError

    def get_file_info(self, paths):
        raise NotImplementedError

    def get_file_info_selector(self, selector):
        raise NotImplementedError

    def get_type_name(self):
        raise NotImplementedError

    def move(self, src, dest):
        raise NotImplementedError

    def normalize_path(self, path):
        return path

    def open_append_stream(self, path, metadata):
        raise NotImplementedError

    def open_input_file(self, path):
        return pa.BufferReader(self.data[path])

    def open_input_stream(self, path):
        raise NotImplementedError

    def open_output_stream(self, path, metadata):
        raise NotImplementedError

    def __init__(self, data: dict):
        self.data = data


def read_parquet_bytes_into_df_ext(bytes: list,
                         single_tag_col_name: str, tag_values: list,
                         time_col: str, time_range: tuple, sel_cols: list) -> pd.DataFrame:
    mem = {}
    for i, x in enumerate(bytes):
        mem[f"timelyre_mem://{i}"] = x

    paths = [f"timelyre_mem://{i}" for i in range(len(bytes))]

    filters = [
        (time_col, ">=", time_range[0]),
        (time_col, "<", time_range[1]),
    ]

    if single_tag_col_name is not None:
        filters.append((single_tag_col_name, "in", tag_values))

    handler = MyFileSystemHandler(mem)

    mfs = PyFileSystem(handler=handler)
    table = pq.read_table(paths, columns=sel_cols, filters=filters, use_threads=True, filesystem=mfs)
    df = table.to_pandas()
    return df


def base64url_encode(data):
    # 首先，使用标准Base64编码
    standard_b64 = base64.urlsafe_b64encode(data)

    # 然后将`+`替换为`-`，将`/`替换为`_`，移除`=`
    return standard_b64.replace(b'+', b'-').replace(b'/', b'_').replace(b'=', b'')
def base64url_decode(data):
    # 先将`-`替换为`+`，将`_`替换为`/`
    data = data.replace(b'-', b'+').replace(b'_', b'/')

    # 然后，添加适当的数量的`=`进行解码
    padding = len(data) % 4
    if padding != 0:
        data += b'=' * (4 - padding)

    # 使用标准Base64解码
    return base64.urlsafe_b64decode(data)
def anystr_encode_to_filename(s: str) -> str:
    data = s.encode('utf-8')
    return str(base64url_encode(data), 'utf-8')


def filename_decode_to_anystr(s: str) -> str:
    encode_data = s.encode('utf-8')
    decode_data = base64url_decode(encode_data)
    return str(decode_data, 'utf-8')

if __name__ == '__main__':
    data = [
        "aaa",
        "a123",
        "a 1 _ $ 23 ** ::",
        "a 1我不能",
        "a 1我不能 ((((( @@@@  ゥラメー",
        "   a 1我不能 ((((( @@@\n\n\n@  ゥラメー\t\t\t\t....   ",
    ]

    for x in data:
        y = anystr_encode_to_filename(x)
        print(y)
        assert x == filename_decode_to_anystr(y)

import datetime
import json
import time
from concurrent.futures import ThreadPoolExecutor
from itertools import repeat

import pandas as pd
import requests

from transwarp.timelyre.constants import CruxMode, type_value_to_type_int, TagType, TimestampType, CastTSType, \
    CastMinuteType, CastDateType, QuarkMode, JoinType
from transwarp.timelyre.quark import get_remote_dataframe
from transwarp.timelyre.timelyre_logger import getLogger
from transwarp.timelyre.util import get_utc_time, get_normal_time


@DeprecationWarning
def checkStreamAvailable(self):
    # 检查是否设置kafka地址
    if self.__kafka_servers is None or self.__kafka_servers == "":
        raise RuntimeError("no kafka server address was found")
    if self.__kafka_zk_address is None or self.__kafka_zk_address == "":
        raise RuntimeError("no kafka zk address was found")


@DeprecationWarning
def __create_and_use_application(self):
    self.run_simple_command(
        'create application if not exists app_kafka APPPROPERTIES("morphling.result.auto.flush"="true","morphling.metrics.enabled"="true");'
    )
    self.run_simple_command("use app app_kafka;")


@DeprecationWarning
def __create_stream_table(self, stream_table_name, schema: list, topic_name: str):
    self.run_simple_command(f"drop stream if exists {stream_table_name};")
    colWithTypes = [f"`{x[0]}` {x[1]}" for x in schema]
    props = f"'topic'='{topic_name}', " + \
            f"'kafka.zookeeper'='{self.__kafka_zk_address}'," + \
            f"'kafka.broker.list'='{self.__kafka_servers}'"
    query = f'create stream {stream_table_name}({",".join(colWithTypes)})' + \
            "ROW FORMAT DELIMITED FIELDS TERMINATED BY ','" + \
            f'tblproperties({props})'
    self.run_simple_command(query)


@DeprecationWarning
def __create_stream_job(self, stream_table_name: str, timelyre_table_name: str):
    stream_job_name = f"{timelyre_table_name}_stream_job"
    self.run_simple_command(f"drop streamjob {stream_job_name}")
    query = f'create streamjob {stream_job_name} as("insert into {self.__db}.{timelyre_table_name} select * from {self.__db}.{stream_table_name}")' + \
            "jobproperties ('morphling.job.enable.checkpoint'='true','morphling.job.checkpoint.interval'='60000','morphling.result.auto.flush'='false');"
    self.run_simple_command(query)


# timelyre表名，topic名，stream表名，stream job名一一对应
@DeprecationWarning
def create_stream_table(self, table_name: str, schema: list, **kwargs):
    self.checkStreamAvailable()
    self.__set_mode(QuarkMode)
    # 建对应的timelyre表
    self.create_table(tblName=table_name, tblType="timelyre", schema=schema, shard_group_duration="604800",
                      **kwargs)

    # topic的名字统一格式为 db.tbl_topic
    topic_name = f"{self.__db}.{table_name}_topic"

    # 建流表
    self.__create_and_use_application()
    stream_table_name = f"{table_name}_stream_table"
    self.__create_stream_table(stream_table_name, schema, topic_name)

    # 建stream job
    self.__create_stream_job(stream_table_name, table_name)
    return topic_name


@DeprecationWarning
def start_stream_job(self, table_name: str):
    # 开始stream job
    self.__set_mode(QuarkMode)
    self.run_simple_command("use app app_kafka;")
    self.run_simple_command(f"start streamjob {table_name}_stream_job")


@DeprecationWarning
def stop_stream_job(self, table_name: str):
    # 停止stream job
    self.__set_mode(QuarkMode)
    self.run_simple_command("use app app_kafka;")
    self.run_simple_command(f"stop streamjob {table_name}_stream_job")


@DeprecationWarning
def clean_up_stream_table(self, table_name: str):
    # 删除stream job
    self.__set_mode(QuarkMode)
    self.run_simple_command("use app app_kafka;")
    self.run_simple_command(f"stop streamjob {table_name}_stream_job")
    self.run_simple_command(f"drop streamjob {table_name}_stream_job")

    # 删除流表
    self.run_simple_command(f"drop stream if exists {table_name}_stream_table")


@DeprecationWarning
def count_like(self, table: str, tag_col: str, tag_like_str: str = "", base: int = 2000):
    tag_list = self.__get_like_tags(table=table, tag_col=tag_col, tag_like_str=tag_like_str)
    if tag_list is not None:
        for i in range(len(tag_list)):
            tag_list[i] = f"'{tag_list[i]}'"
        sub_lists = [tag_list[i:i + base] for i in range(0, len(tag_list), base)]
        final_sql = []
        for i in range(len(sub_lists)):
            sub_tag_in_str = ','.join(sub_lists[i])
            final_sql.append(f"select count(*) from {table} where {tag_col} in ({sub_tag_in_str})")
        query_sql = ' union all '.join(final_sql)
        res = self.query_as_df(query=query_sql)
        if res.shape[1] == 1:
            return res.sum().values[0]
        else:
            raise ValueError(f"Unexcept res {res}")
    else:
        return 0


@DeprecationWarning
def query_like(self, table: str, select_part: str, tag_col: str, tag_like_str: str = "", base: int = 2000):
    tag_list = self.__get_like_tags(table=table, tag_col=tag_col, tag_like_str=tag_like_str)
    if tag_list is not None:
        for i in range(len(tag_list)):
            tag_list[i] = f"'{tag_list[i]}'"
        sub_lists = [tag_list[i:i + base] for i in range(0, len(tag_list), base)]
        final_sql = []
        for i in range(len(sub_lists)):
            sub_tag_in_str = ','.join(sub_lists[i])
            final_sql.append(f"select {','.join(select_part)} from {table} where {tag_col} in ({sub_tag_in_str})")
        query_sql = ' union all '.join(final_sql)
        res = self.query_as_df(query=query_sql)
        return res
    else:
        return pd.DataFrame()


@DeprecationWarning
def __get_like_tags(self, table: str, tag_col: str, tag_like_str: str = ""):
    full_tbl_name = self.db() + "." + table
    url = f'http://{self.proxy()}/query'
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    data = {}
    data['db'] = full_tbl_name
    data['q'] = f"SHOW SERIES WHERE {tag_col} =~ /.*{tag_like_str}.*/"
    response = requests.post(url, headers=headers, data=data)
    if response.status_code == 200:
        resp_text = json.loads(response.text)
        tag_list = None
        if 'series' in resp_text['results'][0]:
            tag_list = [item[0].split('=')[1] for item in resp_text['results'][0]['series'][0]['values']]
        return tag_list
    else:
        raise ValueError(response.content)


@DeprecationWarning
def __run_influxql(self, table: str, influxql: str):
    full_tbl_name = self.db() + "." + table
    url = f'http://{self.proxy()}/query'
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    data = {}
    data['db'] = full_tbl_name
    data['q'] = influxql
    response = requests.post(url, headers=headers, data=data)
    if response.status_code == 200:
        return response.text
    else:
        raise ValueError(response.content)


@DeprecationWarning
def __get_all_tags(self, table: str, tag_col: str):
    full_tbl_name = self.db() + "." + table
    url = f'http://{self.proxy()}/query'
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    data = {}
    data['db'] = full_tbl_name
    data['q'] = f"SHOW SERIES"
    response = requests.post(url, headers=headers, data=data)
    if response.status_code != 200:
        raise ValueError(f"{response.content}")
    else:
        resp_text = json.loads(response.text)
        tag_list = None
        if 'series' in resp_text['results'][0]:
            tag_list = [item[0].split('=')[1] for item in resp_text['results'][0]['series'][0]['values']]
        return tag_list


@DeprecationWarning
def query_join(self, base_table: str, base_cols: list, base_table_vin: str,
               obd_table: str, obd_cols: list, obd_tag_col: str, obd_time_col: str, obd_f_tt: str, obd_f_list: str,
               data_table: str, data_cols: list, data_tag_col: str, data_time_col: str,
               filter: str, start_time: str, end_time: str,
               base: int = 2000, filter_null: bool = True, all_time: bool = True, parallelism: int = 100):
    if base_table_vin not in base_cols:
        raise ValueError("base_table_vin not in base_cols")
    if obd_tag_col not in obd_cols or obd_time_col not in obd_cols:
        raise ValueError("odb_tag_col or odb_time_col not in obd_cols")
    if len(obd_cols) <= 2:
        raise ValueError(f"odb_cols shoule contains tag,time and other colums")
    if data_tag_col not in data_cols or data_time_col not in data_cols:
        raise ValueError("data_tag_col or data_time_col not in data_cols")
    if len(data_cols) <= 2:
        raise ValueError(f"data_cols shoule contains tag,time and other colums")

    base_table_col = ','.join(base_cols)
    obd_table_col = ','.join(obd_cols)
    data_table_col = ','.join(data_cols)

    obd_all_tag = self.__get_all_tags(table=obd_table, tag_col=obd_tag_col)
    data_all_tag = self.__get_all_tags(table=data_table, tag_col=data_table_col)
    base_sql = None
    if filter is not None:
        base_sql = f"select {base_table_col} from {base_table} where {filter}"
    else:
        base_sql = f"select {base_table_col} from {base_table}"
    base_result = self.query_as_df(query=base_sql)
    base_vin_list_str = ""
    base_vin_list = None
    if base_result.empty:
        return []
    else:
        base_vin_list = base_result[base_table_vin].tolist()
        base_vin_list = list(set(obd_all_tag) & set(base_vin_list) & set(data_all_tag))

    if len(base_vin_list) == 0:
        print("tl table tag is null")

    for i in range(len(base_vin_list)):
        base_vin_list[i] = f"'{base_vin_list[i]}'"

    if all_time == False:
        data_res = self.__query_join_influxql(obd_table=obd_table, obd_cols=obd_cols, obd_last_val=obd_f_list,
                                              obd_f_tt=obd_f_tt, obd_tag=obd_tag_col, obd_time=obd_time_col,
                                              data_table=data_table, data_cols=data_cols, data_tag=data_tag_col,
                                              data_time=data_time_col,
                                              base_vin_list=base_vin_list, start_time=start_time, end_time=end_time,
                                              filter_null=filter_null, all_time=all_time, parallelism=parallelism)

        df = pd.merge(base_result, data_res, left_on=base_table_vin, right_on=obd_tag_col, how='inner')
        df = df.rename(columns={'time': obd_time_col})
        df[obd_time_col] = df[obd_time_col].apply(lambda x: get_normal_time(x))
        if base_table_vin != obd_tag_col:
            df.drop([obd_tag_col], axis=1)
        return df

    else:
        base_vin_list_str = ','.join(base_vin_list)
        obd_time_range = None
        data_time_range = None
        obd_sql = f"select {obd_table_col} from {obd_table} where {obd_tag_col} in ({base_vin_list_str}) and {obd_f_tt} > 0 "
        data_sql = f"select {data_table_col} from {data_table} where {data_tag_col} in ({base_vin_list_str})"
        if start_time is not None and end_time is not None:
            obd_time_range = f"{obd_time_col} >= '{start_time}' and {obd_time_col} <= '{end_time}'"
            obd_sql = obd_sql + f" and {obd_time_range}"
            data_time_range = f"{data_time_col} >= '{start_time}' and {data_time_col} <= '{end_time}'"
            data_sql = data_sql + f" and {data_time_range}"

        t1_select_part = []
        prefix = "t1."
        for i in range(len(base_cols)):
            t1_select_part.append(prefix + base_cols[i])

        t2_select_part = []
        prefix = "t2."
        for i in range(len(obd_cols)):
            if (obd_cols[i] != obd_tag_col):
                t2_select_part.append(prefix + obd_cols[i])

        t3_select_part = []
        prefix = "t3."
        for i in range(len(data_cols)):
            if (data_cols[i] != data_time_col and data_cols[i] != data_tag_col):
                t3_select_part.append(prefix + data_cols[i])

        sub_lists = [base_vin_list[i:i + base] for i in range(0, len(base_vin_list), base)]
        final_sql = []
        for i in range(len(sub_lists)):
            sub_tag_in_str = ','.join(sub_lists[i])
            obd_sql = f"select {obd_table_col} from {obd_table} where {obd_tag_col} in ({sub_tag_in_str})  and {obd_f_tt} > 0 "
            data_sql = f"select {data_table_col} from {data_table} where {data_tag_col} in ({sub_tag_in_str})"
            if start_time is not None and end_time is not None:
                obd_time_range = f"{obd_time_col} >= '{start_time}' and {obd_time_col} <= '{end_time}'"
                obd_sql = obd_sql + f" and {obd_time_range}"
                data_time_range = f"{data_time_col} >= '{start_time}' and {data_time_col} <= '{end_time}'"
                data_sql = data_sql + f" and {data_time_range}"
            part_sql = f"select {','.join(t1_select_part)}, {','.join(t2_select_part)}, {','.join(t3_select_part)} from ({base_sql}) as t1 " \
                       f"inner join ({obd_sql}) as t2 on  t1.{base_table_vin} = t2.{obd_tag_col} " \
                       f"inner join ({data_sql}) as t3 on t2.{obd_tag_col} = t3.{data_tag_col} and t2.{obd_time_col} = t3.{data_time_col}"
            final_sql.append(part_sql)
        final_sql_str = ' union all '.join(final_sql)
        return self.query_as_df(query=final_sql_str)


@DeprecationWarning
def __query_join_influxql(self, obd_table: str, obd_cols: list, obd_last_val: str, obd_f_tt: str, obd_tag: str,
                          obd_time: str,
                          data_table: str, base_vin_list: list, data_cols: str, data_tag: str, data_time: str,
                          start_time: str, end_time: str, filter_null: bool = True, all_time: bool = True,
                          parallelism: int = 100):
    for i in range(len(base_vin_list)):
        base_vin_list[i] = f"{obd_tag} = {base_vin_list[i]}"
    start_time = get_utc_time(start_time)
    end_time = get_utc_time(end_time)
    obd_select_part = []
    for i in range(len(obd_cols)):
        if obd_cols[i] != obd_time and obd_cols[i] != obd_last_val:
            obd_select_part.append(obd_cols[i])
    obd_influxql = ""
    if all_time:
        obd_influxql = f"select {','.join(obd_select_part)}, {obd_last_val} from M "
    else:
        obd_influxql = f"select {','.join(obd_select_part)}, last({obd_last_val}) as {obd_last_val} from M "
    if filter_null:
        obd_influxql = obd_influxql + f"where {' or '.join(base_vin_list)} and {obd_f_tt} > 0 and time >= {start_time} and time <= {end_time}"
    else:
        obd_influxql = obd_influxql + f"where {' or '.join(base_vin_list)} and time >= {start_time} and time <= {end_time}"
    full_tbl_name = self.db() + "." + obd_table
    url = f'http://{self.proxy()}/query'
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    data = {}
    data['db'] = full_tbl_name
    data['q'] = obd_influxql
    response = requests.post(url, headers=headers, data=data)
    if response.status_code != 200:
        raise ValueError(f"{response.content}")
    else:
        resp_text = json.loads(response.text)

    obd_result = []

    for series in resp_text['results'][0]['series']:
        for values in series['values']:
            record = dict(zip(series['columns'], values))
            obd_result.append(record)
    obd_df = pd.DataFrame(obd_result)
    data_last_cols = []
    for i in range(len(data_cols)):
        if data_cols[i] != data_tag and data_cols[i] != data_time:
            data_last_cols.append(data_cols[i])

    data_influxql_list = []
    for i in range(len(obd_result)):
        tag = f"'{obd_result[i][obd_tag]}'"
        time = f"'{obd_result[i]['time']}'"
        data_influxql = f"select {data_tag}, {','.join(data_last_cols)} from M where {data_tag} = {tag} and time <= {time} order by time desc limit 1"
        data_influxql_list.append(data_influxql)

    executor = ThreadPoolExecutor(max_workers=parallelism)
    data_result = []
    for res in executor.map(self.__run_influxql, repeat(data_table), data_influxql_list):
        if res != "":
            res = json.loads(res)
            for series in res['results'][0]['series']:
                for values in series['values']:
                    record = dict(zip(series['columns'], values))
                    data_result.append(record)

    data_df = pd.DataFrame(data_result)
    final_df = pd.merge(obd_df, data_df.drop(['time'], axis=1), left_on=obd_tag, right_on=data_tag, how='inner')
    return final_df


@DeprecationWarning
def common_join(self, left_table: str, right_table: str, join_type=JoinType.leftjoin, dst_table: str = "",
                join_key_list: list = None,
                time_level: str = "day", left_cols: list = None, right_cols: list = None, left_filter: str = None,
                right_filter: str = None):
    org_left_tbl_name = left_table
    org_right_tbl_name = right_table
    left_mapping_tbl_name = self.get_mapping_table(left_table)
    self.internal_set_quark_mode()
    if left_mapping_tbl_name is not None:
        left_table = left_mapping_tbl_name
    left_tag, left_time = self.get_timelyre_tag_time_col(left_table)

    right_mapping_tbl_name = self.get_mapping_table(right_table)
    if right_mapping_tbl_name is not None:
        right_table = right_mapping_tbl_name
    right_tag, right_time = self.get_timelyre_tag_time_col(right_table)

    left_schema_list = self.show_columns(left_table)
    left_schema_map = {sub_lst[0]: sub_lst[1] for sub_lst in left_schema_list}
    right_schema_list = self.show_columns(right_table)
    right_schema_map = {sub_lst[0]: sub_lst[1] for sub_lst in right_schema_list}
    if JoinType.has_key(join_type):
        join_type_list = [join_type.value for join_type in JoinType]
        raise ValueError(f"commonJoin only support {', '.join(join_type_list)}")

    join_str_list = []
    if time_level != "day":
        raise ValueError(f"commonJoin time_level only support day")
    else:
        join_str_list.append(f"to_date(t1.`{left_time}`) = to_date(t2.`{right_time}`)")

    left_join_key_list = []
    right_join_key_list = []
    for i in range(len(join_key_list)):
        join_key = join_key_list[i]
        if isinstance(join_key, list) and len(join_key) == 2:
            left_join_key_list.append('`' + join_key[0] + '`')
            right_join_key_list.append('`' + join_key[1] + '`')
        else:
            raise ValueError(f"JoinKeyList type is list, like [['t1_col1', 't2_col1'], ['t1_col2', 't2_col2']]")
    if len(left_join_key_list) < 1:
        raise ValueError(f"join key is empty")
    if f"`{left_tag}`" not in left_join_key_list:
        raise ValueError(f"left table join key should contains tag")
    if f"`{right_tag}`" not in right_join_key_list:
        raise ValueError(f"right table join key should contains tag")

    for i in range(len(left_join_key_list)):
        join_str_list.append(f"t1.{left_join_key_list[i]} = t2.{right_join_key_list[i]}")

    dst_schema = []

    left_select_part = "t1.*"
    if left_cols is not None:
        left_cols.append(left_time)
        left_cols = list(set(left_cols))

        for i in range(len(left_cols)):
            if left_cols[i] in left_schema_map:
                dst_schema.append([f"t1_{left_cols[i]}", left_schema_map[left_cols[i]]])
            else:
                raise ValueError(f"col {left_cols} does not exist in {org_left_tbl_name}")

        left_format_cols = ['`' + item for item in left_cols]
        left_format_cols = [item + '`' for item in left_format_cols]
        left_cols_list = ['t1.' + item for item in left_format_cols]
        if join_type == JoinType.fulljoin:
            if f"t1.`{left_tag}`" in left_cols_list:
                # case when tl1.`code` is null then tl2.`code` else tl1.`code` end
                index = left_cols_list.index(f"t1.`{left_tag}`")
                left_cols_list[
                    index] = f"case when t1.`{left_tag}` is null then t2.`{right_tag}` else t1.`{left_tag}` end"
            if f"t1.`{left_time}`" in left_cols_list:
                # case when tl1.`code` is null then tl2.`code` else tl1.`code` end
                index = left_cols_list.index(f"t1.`{left_time}`")
                left_cols_list[
                    index] = f"case when t1.`{left_time}` is null then t2.`{right_time}` else t1.`{left_time}` end"
        left_select_part = ','.join(left_cols_list)
        left_cols = list(set(left_format_cols + left_join_key_list))
    else:
        raise ValueError(f"left table cols is empty")
    right_select_part = "t2.*"
    if right_cols is not None:
        right_cols.append(f"{right_time}")
        right_cols = list(set(right_cols))

        for i in range(len(right_cols)):
            if right_cols[i] in right_schema_map:
                dst_schema.append([f"t2_{right_cols[i]}", right_schema_map[right_cols[i]]])
            else:
                raise ValueError(f"col {right_cols} does not exist in {org_right_tbl_name}")

        right_format_cols = ['`' + item for item in right_cols]
        right_format_cols = [item + '`' for item in right_format_cols]
        right_cols_list = ['t2.' + item for item in right_format_cols]
        right_select_part = ','.join(right_cols_list)
        right_cols = list(set(right_format_cols + right_join_key_list))
    else:
        raise ValueError(f"right table cols is empty")
    dst_schema.append(["seqno", 'bigint'])
    shard_group_duration = 5184000
    db_table = self.show_tables()
    if dst_table in db_table:
        raise ValueError("dst_table already exist")
    self.drop_table(dst_table)
    properties = '"timelyre.replica.num"="1"'

    left_tbl_properties = self.show_properties(left_table)
    right_tbl_properties = self.show_properties(right_table)
    has_seqno = False
    seq_col = ""

    if join_type == JoinType.leftjoin:
        if "shard.group.duration.seconds" in left_tbl_properties:
            shard_group_duration = left_tbl_properties['shard.group.duration.seconds']
        if "timelyre.tablet.num" in left_tbl_properties:
            properties = properties + f',"timelyre.tablet.num"="{left_tbl_properties["timelyre.tablet.num"]}"'
        if "epoch.row.key.cols" in left_tbl_properties:
            has_seqno = True
            seq_col = f"t1.`{left_tbl_properties['epoch.row.key.cols']}`"
            properties = properties + f',"epoch.row.key.cols"="{left_tbl_properties["epoch.row.key.cols"]}"'
        else:
            properties = properties + f',"epoch.auto.row.key.enabled"="true","epoch.row.key.cols"="seqno"'
        if has_seqno:
            left_cols.append(f"`{left_tbl_properties['epoch.row.key.cols']}`")
            left_cols = list(set(left_cols))
        self.create_table(tblName=dst_table, tblType="timelyre", schema=dst_schema, tags=f"t1_{left_tag}",
                          timecol=f"t1_{left_time}", shard_group_duration=shard_group_duration,
                          properties=properties)
    if join_type == JoinType.rightjoin:
        if "shard.group.duration.seconds" in right_tbl_properties:
            shard_group_duration = right_tbl_properties['shard.group.duration.seconds']
        if "timelyre.tablet.num" in right_tbl_properties:
            properties = properties + f",'timelyre.tablet.num'='{right_tbl_properties['timelyre.tablet.num']}'"
        if "epoch.row.key.cols" in right_tbl_properties:
            has_seqno = True
            seq_col = f"t2.`{right_tbl_properties['epoch.row.key.cols']}`"
            properties = properties + f',"epoch.row.key.cols"="{left_tbl_properties["epoch.row.key.cols"]}"'
        else:
            properties = properties + f',"epoch.auto.row.key.enabled"="true","epoch.row.key.cols"="seqno"'
        if has_seqno:
            right_cols.append(f"`{right_tbl_properties['epoch.row.key.cols']}`")
            right_cols = list(set(right_cols))
        self.create_table(tblName=dst_table, tblType="timelyre", schema=dst_schema, tags=f"t2_{right_tag}",
                          timecol=f"t2_{right_time}", shard_group_duration=shard_group_duration,
                          properties=properties)
    if join_type == JoinType.innerjoin:
        if "shard.group.duration.seconds" in left_tbl_properties:
            shard_group_duration = left_tbl_properties['shard.group.duration.seconds']
        if "timelyre.tablet.num" in left_tbl_properties:
            properties = properties + f",'timelyre.tablet.num'='{left_tbl_properties['timelyre.tablet.num']}'"
        if "epoch.row.key.cols" in left_tbl_properties:
            has_seqno = True
            seq_col = f"t1.`{left_tbl_properties['epoch.row.key.cols']}`"
            properties = properties + f',"epoch.row.key.cols"="{left_tbl_properties["epoch.row.key.cols"]}"'
        else:
            properties = properties + f',"epoch.auto.row.key.enabled"="true","epoch.row.key.cols"="seqno"'
        if has_seqno:
            left_cols.append(f"`{left_tbl_properties['epoch.row.key.cols']}`")
            left_cols = list(set(left_cols))
        self.create_table(tblName=dst_table, tblType="timelyre", schema=dst_schema, tags=f"t1_{left_tag}",
                          timecol=f"t1_{left_time}", shard_group_duration=shard_group_duration,
                          properties=properties)
    if join_type == JoinType.fulljoin:
        if "shard.group.duration.seconds" in left_tbl_properties:
            shard_group_duration = left_tbl_properties['shard.group.duration.seconds']
        if "timelyre.tablet.num" in left_tbl_properties:
            properties = properties + f",'timelyre.tablet.num'='{left_tbl_properties['timelyre.tablet.num']}'"
        properties = properties + f',"epoch.auto.row.key.enabled"="true","epoch.row.key.cols"="seqno"'
        self.create_table(tblName=dst_table, tblType="timelyre", schema=dst_schema, tags=f"t1_{left_tag}",
                          timecol=f"t1_{left_time}", shard_group_duration=shard_group_duration,
                          properties=properties)

    left_table_part = left_table
    if left_filter is not None:
        left_table_part = f"(select {','.join(left_cols)} from {left_table} where {left_filter})"
    right_table_part = right_table
    if right_filter is not None:
        right_table_part = f"(select {','.join(right_cols)} from {right_table} where {right_filter})"

    finalsql = f"insert into {dst_table} select {left_select_part}, {right_select_part}"
    if has_seqno:
        finalsql = finalsql + f",{seq_col} "
    else:
        finalsql = finalsql + f",0 "
    finalsql = finalsql + f"from {left_table_part} as t1 " \
                          f"{join_type.value} join " \
                          f"{right_table_part} as t2 " \
                          f"on {' and '.join(join_str_list)}"
    res = self.query_raw_data(sql=finalsql)


@DeprecationWarning
## query_as_df耦合了很多时序相关的逻辑, 抽离最核心的取数逻辑做通用的接口
def query_data(self, query: str = None,
               combine_ignore_index: bool = True,
               adjust_dt_to_lz: bool = True,
               local_dir: str = None,
               command: str = None,
               ):
    """
    从一张表里查询相应数据
    :param query: 直接查询的语句
    :param combine_ignore_index: query的结果分为多个文件，该选项决定多个文件的df合并为一个时的选项
    :param adjust_dt_to_lz: 将没有tz信息的时间戳按照utc解析并按照local timezone信息设置
    :param local_dir: 设置查询结果文件在本地存放的目录
    :return: 将数据读取为一个DataFrame返回
    """
    time1 = time.time_ns()
    self.__set_mode(QuarkMode)
    self.run_simple_command("set timelyre.skip.dfs.auth.check=true")
    self.run_simple_command("set hive.optimize.ppd = false;set character.literal.as.string=true;")
    if command is not None:
        self.run_simple_command(command)
    times = []
    times.append(time.perf_counter())
    result_table_name = "tmpresult__" + datetime.datetime.now().strftime(
        "%Y%m%d_%H%M%S%f") + "_" + self.newSymbolId()
    if query is None:
        raise RuntimeError("query can not be null")
    else:
        queryCore = query
        directQuery = f'create temporary table {result_table_name} stored as parquet as {queryCore}'
        finalQuery = directQuery

    t1 = time.time()
    finalQueryRes = self.__quark_query_raw(finalQuery)
    t2 = time.time()
    getLogger().info(f'query_data final Query {finalQuery}, cost {t2 - t1} s')

    # 获取结果表的数据位置
    try:
        hdfsloc = self.getLocation(result_table_name)
        # print(f"hdfsloc: {hdfsloc}")
    except ConnectionError as e:
        raise e

    times.append(time.perf_counter())

    (dirId, dirPath) = self.__tmp_mgr.prepareNewTempDir()

    getLogger().info(f'remote quark tmp dir id {dirId}, path {dirPath}')

    self.__quark_query_raw(f"dfs -get {hdfsloc}/* {dirPath}")
    times.append(time.perf_counter())

    df = get_remote_dataframe(self.__rest_host_port, self.__token, dirId, combine_ignore_index, local_dir)
    # 调整时区逻辑
    # 从parquet读出来的时间是没有时区的（可以认为是GMT），需要调整成本地时区
    # local_dir是把结果存为parquet的逻辑，无需考虑转换时区
    times.append(time.perf_counter())
    if adjust_dt_to_lz and local_dir is None and df is not None:
        self.__post_dataframe_process(df)

    self.__tmp_mgr.releaseTempDir(dirId)

    times.append(time.perf_counter())
    diffs = [str(times[i] - times[i - 1]) for i in range(1, len(times))]
    getLogger().info('time stat:' + ', '.join(diffs))
    time2 = time.time_ns()
    getLogger().info(f'query_data costs: {(time2 - time1) / 1000000.0} ms')
    if local_dir is not None:
        return None

    getLogger().info(f"retrieve data with shape {df.shape}")
    return df


@DeprecationWarning
def __post_dataframe_process_for_local_write(self, df):
    """
    对获取到的dataframe进行一些额外的处理，包括：
        1. 把时间列修正为local timezone的表示
    :param df:
    :return:
    """
    lz = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
    for (a, b) in df.select_dtypes('datetime64[ns, UTC]').items():
        if b.dt.tz is not None and b.dt.tz.zone == 'UTC':
            df[a] = b.dt.tz_convert(lz)


@DeprecationWarning
def __post_dataframe_process2(self, df):
    """
    把时间向前调8个小时，并且设置成UTC时区，因为parquet表不带时区，需要转成UTC
    :param df:
    :return:
    """
    lz = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
    for (a, b) in df.select_dtypes('datetime64').items():
        if b.dt.tz is None:
            df[a] = b.dt.tz_localize(lz).dt.tz_convert(datetime.timezone.utc)

import time

from .timelyre_logger import getLogger


def do_cache_control(finalQueryRes: list,
                     result_table_name: str,
                     queryRawFunc,
                     getLocationFunc,
                     dropToDeleteTableFunc,
                     ttl: int,
                     ) -> (str, bool):
    if len(finalQueryRes) > 0 and len(finalQueryRes[0]) > 0:
        getLogger().info(f"hit cache")
        # 命中cache
        singleLineResult: str = finalQueryRes[0][0]
        idx = singleLineResult.index(" DeleteTBL:")
        cacheTblMsg = singleLineResult[:idx]
        deleteTblsMsg = singleLineResult[idx:]
        deleteTblsMsg = deleteTblsMsg[len(" DeleteTBL: "):]
        deleteTbls = list(filter(lambda x: x != "", deleteTblsMsg[1:-1].split(",")))
        for dTbl in deleteTbls:
            queryRawFunc(f"drop table {dTbl}")
            res = queryRawFunc(f"config global timelyre.cache remove {dTbl}")
            getLogger().info(f"remove table cache {dTbl} result: {res}")
        # 去掉最后的逗号
        cacheTbl = cacheTblMsg[len("ReplaceTBL: "):-1]
        getLogger().info(f"try {result_table_name}, replace with cache {cacheTbl}, to_delete {deleteTbls}")
        return cacheTbl, True
    else:
        # 没命中cache，尝试添加cache
        getLogger().info(f"missed cache. try to make cache, ttl is {ttl / 1000} s")
        duData = None
        tblSize = None

        try:
            loc = getLocationFunc(tblName=result_table_name)
            duData = queryRawFunc(f"dfs -du -s {loc}")

            #当前Quark/HDFS可能会导致dfs的location信息在获取的时候为空，因此加入几次重试
            retry = 0
            while len(duData) == 0 and retry < 5:
                getLogger().warn(f"get info failed: {result_table_name} {loc}, info: {duData}, try index: {retry}")
                time.sleep(0.3)
                duData = queryRawFunc(f"dfs -du -s {loc}")
                retry += 1

            def get_tbl_size(line):
                res = line.split(" ")
                if not res[0].isdigit():
                    return None, f"{res[0]} is not digit"
                if not res[-1][:4] == "hdfs":
                    return None, f"{res[-1][:4]} is not correct info"
                else:
                    return int(res[0]), None

            if len(duData) == 1:
                getLogger().info(f"get info: {duData}")
                tblSize, err = get_tbl_size(duData[0][0])
            else:
                getLogger().warn(f"get info with warn: {duData}")   # 有时候会返回一些不影响业务的warn信息
                for l in duData:
                    tblSize, err = get_tbl_size(l[0])
                    if tblSize is not None:
                        break

            if tblSize is None:
                raise RuntimeError(f"failed to get correct table size, duData is: {duData}, err: {err}")
            
        except IndexError as ie:
            getLogger().error(f"get info failed: {result_table_name} {loc}, info: {duData}")
            raise ie
        try:
            make_cache_res = queryRawFunc(f"config global timelyre.cache make last cache {tblSize} {ttl}")
            if len(make_cache_res) > 0 and len(make_cache_res[0]) > 0 and make_cache_res[0][0] == "true":
                getLogger().info("this query make cache result: true")
            else:
                queryRawFunc(f"drop table {result_table_name}")
                getLogger().info(f"this query make cache result: false, drop cache table {result_table_name}, to drop some deleted tables")
                dropToDeleteTableFunc(3)
        except Exception as e:
            getLogger().error(f"error occured, tblSize is: {tblSize}, duData is:{duData}\nerror is: {e}")
            raise RuntimeError(f"error occured, tblSize is: {tblSize}, duData is:{duData}\nerror is: {e}")
        return result_table_name, False

from typing import List


class QuarkSchema:
    def __init__(self,
                 column_names: List[str],
                 column_types: List[str],
                 tag_cols: List[str],
                 ts_col: str):
        self.column_names = column_names
        self.column_types = column_types
        self.tag_cols = tag_cols
        self.ts_col = ts_col
        self.tag_index = list()
        self.ts_index = -1
        for i in range(0, len(self.column_names)):
            if self.column_names[i] in tag_cols:
                self.tag_index.append(i)
            elif self.column_names[i] == ts_col:
                if self.ts_index >= 0:
                    raise ValueError("Schema can not have two timestamp column")
                self.ts_index = i

    def get_tag_cols(self):
        return self.tag_cols

    def get_tag_index(self):
        return self.tag_index

    def get_column_names(self):
        return self.column_names

    def get_column_types(self):
        return self.column_types

    def get_timestamp_col(self):
        return self.ts_col

    def get_timestamp_index(self):
        return self.ts_index

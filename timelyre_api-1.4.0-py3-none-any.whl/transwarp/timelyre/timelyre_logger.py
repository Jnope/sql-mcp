import logging
import os
import uuid
from logging.handlers import RotatingFileHandler

log_file_name = "timelyre-py.log"
default_log_path = '/tmp/timelyre-py.log'
default_level = logging.INFO
default_max_bytes = 5 * 1024 * 1024
default_backup_count = 5
__logger = logging.getLogger("database")


def clear_all_handler():
    global __logger
    for handler in __logger.handlers[:]:
        __logger.removeHandler(handler)
        handler.close()


class UuidFilter(logging.Filter):
    def __init__(self, uuid):
        super().__init__()
        self.uuid = uuid

    def filter(self, record):
        record.uuid = self.uuid
        return True


class PidFilter(logging.Filter):
    def __init__(self, pid):
        super().__init__()
        self.pid = pid

    def filter(self, record):
        record.pid = self.pid
        return True


def init_logger(log_file_path, level, max_bytes, backup_count):
    global __logger
    # 清理原来的handler
    clear_all_handler()
    # 添加新的handler
    handler = RotatingFileHandler(log_file_path, maxBytes=max_bytes, backupCount=backup_count, delay=True)
    logger_uid = str(uuid.uuid4()).split('-')[0]
    pid = os.getpid()
    formatter = logging.Formatter('%(asctime)s-[id:%(uuid)s]-[pid:%(pid)s]-%(levelname)s: %(message)s')
    handler.setLevel(level)
    handler.setFormatter(formatter)
    __logger.addHandler(handler)
    __logger.setLevel(level)
    __logger.addFilter(UuidFilter(logger_uid))
    __logger.addFilter(PidFilter(pid))


init_logger(default_log_path, default_level, default_max_bytes, default_backup_count)
clear_all_handler()     # 暂时：默认不输出到文件

def getLogger():
    global __logger
    return __logger


def set_logger(logger):
    global __logger
    __logger = logger

def set_logger_file_output(open):
    if open:
        init_logger(default_log_path, default_level, default_max_bytes, default_backup_count)
    else:
        clear_all_handler()

def add_new_handler(handler):
    global __logger
    __logger.addHandler(handler)


def update_logger_settings(log_dir=default_log_path,
                           file_name=log_file_name,
                           level=default_level,
                           max_bytes=default_max_bytes,
                           backup_count=default_backup_count):
    if not os.path.isdir(log_dir):
        raise ValueError(f"{log_dir} is not a valid directory")
    log_file_path = f"{log_dir}/{file_name}"
    init_logger(log_file_path, level, max_bytes, backup_count)